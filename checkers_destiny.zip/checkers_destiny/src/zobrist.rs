use rand::rngs::StdRng;
use rand::{Rng, SeedableRng};

/// Zobrist hashing for checkers.
/// 4 piece types (white man, white king, black man, black king)
/// × 32 playable squares + side to move.

pub struct ZobristKeys {
    /// pieces[piece_index][square_index] - 4 types × 32 squares
    pub pieces: [[u64; 32]; 4],
    pub side: u64,
}

impl ZobristKeys {
    pub fn new() -> Self {
        let mut rng = StdRng::seed_from_u64(0xC4EC4E45_DE57_1234);
        let mut keys = ZobristKeys {
            pieces: [[0u64; 32]; 4],
            side: 0,
        };
        for p in 0..4 {
            for sq in 0..32 {
                keys.pieces[p][sq] = rng.gen();
            }
        }
        keys.side = rng.gen();
        keys
    }

    /// Map piece value to index: WM=0, WK=1, BM=2, BK=3
    #[inline]
    pub fn piece_index(piece: i8) -> usize {
        match piece {
            1 => 0,  // White man
            2 => 1,  // White king
            -1 => 2, // Black man
            -2 => 3, // Black king
            _ => 0,
        }
    }
}
