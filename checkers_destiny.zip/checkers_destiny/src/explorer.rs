use crate::engine::{CheckersEngine, GameResult, Move};
use crate::priority;
use crate::storage::TranspositionTable;

struct Frame {
    moves: Vec<Move>,
    move_index: usize,
    results: Vec<GameResult>,
    hash_before: u64,
}

pub struct DestinyExplorer {
    pub table: TranspositionTable,
    engine: CheckersEngine,
    stack: Vec<Frame>,
    pub games_completed: u64,
    pub positions_explored: u64,
    pub positions_cached: u64,
    pub is_exploring: bool,
    pub exploration_complete: bool,
    max_depth: usize,
}

impl DestinyExplorer {
    pub fn new(save_path: &str) -> Self {
        DestinyExplorer {
            table: TranspositionTable::new(save_path),
            engine: CheckersEngine::new(),
            stack: Vec::with_capacity(512),
            games_completed: 0,
            positions_explored: 0,
            positions_cached: 0,
            is_exploring: false,
            exploration_complete: false,
            max_depth: 500,
        }
    }

    pub fn load(&mut self) -> usize { self.table.load() }
    pub fn save(&self) -> bool { self.table.save() }

    pub fn start(&mut self, engine: CheckersEngine) {
        self.stack.clear();
        self.is_exploring = true;
        self.exploration_complete = false;
        self.engine = engine;
        self.push_level();
    }

    fn push_level(&mut self) {
        let mut moves = self.engine.generate_legal_moves();
        priority::sort_moves(&mut moves, self.engine.white_to_move);
        let hash = self.engine.current_hash;
        self.stack.push(Frame {
            moves,
            move_index: 0,
            results: Vec::new(),
            hash_before: hash,
        });
    }

    fn step(&mut self) -> bool {
        if !self.is_exploring || self.exploration_complete { return false; }
        if self.stack.is_empty() {
            self.exploration_complete = true;
            self.is_exploring = false;
            return false;
        }

        let slen = self.stack.len();
        let moves_empty = self.stack[slen - 1].moves.is_empty();
        let idx = self.stack[slen - 1].move_index;
        let moves_len = self.stack[slen - 1].moves.len();

        if moves_empty {
            let result = self.engine.get_result();
            let hash = self.engine.current_hash;
            self.table.insert(hash, result);
            if self.stack.len() > 1 {
                self.stack.pop();
                if let Some(parent) = self.stack.last_mut() {
                    parent.results.push(result);
                }
            } else {
                self.stack.pop();
            }
            self.games_completed += 1;
            return true;
        }

        if idx >= moves_len {
            let frame = self.stack.pop().unwrap();
            let best = self.best_result(&frame.results, self.engine.white_to_move);
            self.table.insert(frame.hash_before, best);
            if let Some(parent) = self.stack.last_mut() {
                parent.results.push(best);
                self.engine.unmake_move();
                parent.move_index += 1;
            }
            return true;
        }

        let m = self.stack[slen - 1].moves[idx].clone();
        self.engine.make_move(&m);
        self.positions_explored += 1;
        let hash = self.engine.current_hash;

        if let Some(cached) = self.table.get(hash) {
            self.positions_cached += 1;
            self.engine.unmake_move();
            let frame = self.stack.last_mut().unwrap();
            frame.results.push(cached);
            frame.move_index = idx + 1;
            return true;
        }

        if self.stack.len() >= self.max_depth {
            self.engine.unmake_move();
            let frame = self.stack.last_mut().unwrap();
            frame.results.push(GameResult::Draw);
            frame.move_index = idx + 1;
            return true;
        }

        let result = self.engine.get_result();
        if result != GameResult::Ongoing {
            self.table.insert(hash, result);
            self.engine.unmake_move();
            let frame = self.stack.last_mut().unwrap();
            frame.results.push(result);
            frame.move_index = idx + 1;
            self.games_completed += 1;
            return true;
        }

        self.push_level();
        true
    }

    fn best_result(&self, results: &[GameResult], white_to_move: bool) -> GameResult {
        if results.is_empty() { return GameResult::Draw; }
        let win = if white_to_move { GameResult::WhiteWins } else { GameResult::BlackWins };
        let mut has_win = false;
        let mut has_draw = false;
        for &r in results {
            if r == win { has_win = true; }
            else if r == GameResult::Draw { has_draw = true; }
        }
        if has_win { win }
        else if has_draw { GameResult::Draw }
        else if white_to_move { GameResult::BlackWins }
        else { GameResult::WhiteWins }
    }

    pub fn explore_batch(&mut self, steps: u64) -> u64 {
        let mut done = 0u64;
        for _ in 0..steps {
            if !self.step() { break; }
            done += 1;
        }
        done
    }

    pub fn get_piece_destiny(
        &self, pr: u8, pc: u8, game_engine: &CheckersEngine,
    ) -> Vec<((u8, u8), Option<GameResult>)> {
        let moves = game_engine.generate_legal_moves();
        let mut results = Vec::new();
        for m in &moves {
            let (fr, fc) = m.from_pos();
            if fr == pr && fc == pc {
                let mut test = game_engine.clone_engine();
                test.make_move(m);
                let hash = test.current_hash;
                let destiny = self.table.get(hash);
                results.push((m.to_pos(), destiny));
            }
        }
        results
    }

    pub fn stack_depth(&self) -> usize { self.stack.len() }
}

pub fn format_number(n: u64) -> String {
    if n < 1_000 { format!("{}", n) }
    else if n < 1_000_000 { format!("{:.1}K", n as f64 / 1_000.0) }
    else if n < 1_000_000_000 { format!("{:.2}M", n as f64 / 1_000_000.0) }
    else { format!("{:.2}B", n as f64 / 1_000_000_000.0) }
}
