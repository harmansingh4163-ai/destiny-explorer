use crate::engine::Move;

/// Priority ordering for checkers:
/// 1. Piece type: Regular men before kings
/// 2. Position: leftmost from player's perspective
/// 3. Captures before simple moves (enforced by rules, but within captures: longest chain first)
/// 4. Direction: forward-left, forward-right, back-left, back-right
/// 5. Distance: shortest chain first for multi-jumps

pub fn sort_moves(moves: &mut Vec<Move>, is_white: bool) {
    moves.sort_by(|a, b| {
        let ka = move_key(a, is_white);
        let kb = move_key(b, is_white);
        ka.cmp(&kb)
    });
}

fn move_key(m: &Move, is_white: bool) -> (u8, u8, u8, u8, u8) {
    let (fr, fc) = m.from_pos();
    let (tr, _tc) = m.to_pos();

    // Piece type: men (0) before kings (1)
    let piece_pri = if m.piece.unsigned_abs() == 1 { 0 } else { 1 };

    // File priority: leftmost from player's perspective
    let file_pri = if is_white { fc } else { 7 - fc };

    // Rank priority: closest to own side
    let rank_pri = if is_white { fr } else { 7 - fr };

    // Direction: forward preferred
    let forward = if is_white { tr > fr } else { tr < fr };
    let dir_pri = if forward { 0 } else { 1 };

    // Chain length: shorter captures first (simpler moves first)
    let chain_pri = m.steps.len() as u8;

    (piece_pri, file_pri, rank_pri, dir_pri, chain_pri)
}
