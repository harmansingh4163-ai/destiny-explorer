use crate::zobrist::ZobristKeys;
use std::sync::OnceLock;

pub const EMPTY: i8 = 0;
pub const W_MAN: i8 = 1;
pub const W_KING: i8 = 2;
pub const B_MAN: i8 = -1;
pub const B_KING: i8 = -2;

static ZOBRIST_KEYS: OnceLock<ZobristKeys> = OnceLock::new();
pub fn get_zobrist_keys() -> &'static ZobristKeys {
    ZOBRIST_KEYS.get_or_init(ZobristKeys::new)
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum GameResult {
    Ongoing,
    WhiteWins,
    BlackWins,
    Draw,
}

impl GameResult {
    pub fn to_u8(self) -> u8 {
        match self {
            GameResult::Ongoing => 0,
            GameResult::WhiteWins => 1,
            GameResult::BlackWins => 2,
            GameResult::Draw => 3,
        }
    }
    pub fn from_u8(v: u8) -> Self {
        match v {
            1 => GameResult::WhiteWins,
            2 => GameResult::BlackWins,
            3 => GameResult::Draw,
            _ => GameResult::Ongoing,
        }
    }
    pub fn name(&self) -> &str {
        match self {
            GameResult::Ongoing => "Ongoing",
            GameResult::WhiteWins => "White Wins",
            GameResult::BlackWins => "Black Wins",
            GameResult::Draw => "Draw",
        }
    }
}

#[derive(Debug, Clone)]
pub struct Move {
    pub steps: Vec<(u8, u8)>,  // sequence of (row, col) positions: [from, to] or [from, mid1, mid2, ..., to]
    pub captures: Vec<(u8, u8)>,  // positions of captured pieces
    pub piece: i8,
    pub promoted: bool,  // did this move result in a promotion?
}

impl Move {
    pub fn from_pos(&self) -> (u8, u8) {
        self.steps[0]
    }
    pub fn to_pos(&self) -> (u8, u8) {
        *self.steps.last().unwrap()
    }
    pub fn is_capture(&self) -> bool {
        !self.captures.is_empty()
    }
    pub fn to_notation(&self) -> String {
        let sq = |r: u8, c: u8| -> String {
            let files = ['a','b','c','d','e','f','g','h'];
            format!("{}{}", files[c as usize], r + 1)
        };
        let (fr, fc) = self.from_pos();
        let (tr, tc) = self.to_pos();
        let sep = if self.is_capture() { "x" } else { "-" };
        format!("{}{}{}", sq(fr, fc), sep, sq(tr, tc))
    }
}

/// State for unmake_move
#[derive(Debug, Clone)]
pub struct UndoInfo {
    pub moved_piece: i8,
    pub steps: Vec<(u8, u8)>,
    pub captured_pieces: Vec<((u8, u8), i8)>,  // (position, piece_type)
    pub promoted: bool,
    pub prev_no_progress: u16,
    pub prev_hash: u64,
}

pub struct CheckersEngine {
    pub board: [[i8; 8]; 8],  // board[row][col]
    pub white_to_move: bool,
    pub no_progress_count: u16,  // moves without captures or promotions (for draw rule)
    pub move_history: Vec<UndoInfo>,
    pub hash_history: Vec<u64>,
    pub zobrist: &'static ZobristKeys,
    pub current_hash: u64,
}

impl CheckersEngine {
    pub fn new() -> Self {
        let keys = get_zobrist_keys();
        let mut engine = CheckersEngine {
            board: [[EMPTY; 8]; 8],
            white_to_move: true,
            no_progress_count: 0,
            move_history: Vec::with_capacity(200),
            hash_history: Vec::with_capacity(200),
            zobrist: keys,
            current_hash: 0,
        };
        engine.setup_initial();
        engine.current_hash = engine.compute_hash();
        engine.hash_history.push(engine.current_hash);
        engine
    }

    fn setup_initial(&mut self) {
        // White pieces on rows 0-2 (dark squares)
        for r in 0..3u8 {
            for c in 0..8u8 {
                if Self::is_dark(r, c) {
                    self.board[r as usize][c as usize] = W_MAN;
                }
            }
        }
        // Black pieces on rows 5-7
        for r in 5..8u8 {
            for c in 0..8u8 {
                if Self::is_dark(r, c) {
                    self.board[r as usize][c as usize] = B_MAN;
                }
            }
        }
    }

    #[inline]
    pub fn is_dark(r: u8, c: u8) -> bool {
        (r + c) % 2 == 1
    }

    #[inline]
    fn in_bounds(r: i8, c: i8) -> bool {
        r >= 0 && r < 8 && c >= 0 && c < 8
    }

    #[inline]
    fn square_index(r: u8, c: u8) -> usize {
        (r as usize) * 4 + (c as usize) / 2
    }

    #[inline]
    fn is_own(piece: i8, white: bool) -> bool {
        (white && piece > 0) || (!white && piece < 0)
    }

    #[inline]
    fn is_enemy(piece: i8, white: bool) -> bool {
        (white && piece < 0) || (!white && piece > 0)
    }

    #[inline]
    fn is_king(piece: i8) -> bool {
        piece == W_KING || piece == B_KING
    }

    pub fn compute_hash(&self) -> u64 {
        let mut h: u64 = 0;
        for r in 0..8u8 {
            for c in 0..8u8 {
                let p = self.board[r as usize][c as usize];
                if p != EMPTY && Self::is_dark(r, c) {
                    let pi = ZobristKeys::piece_index(p);
                    let si = Self::square_index(r, c);
                    h ^= self.zobrist.pieces[pi][si];
                }
            }
        }
        if self.white_to_move {
            h ^= self.zobrist.side;
        }
        h
    }

    /// Generate all legal moves (respects mandatory capture rule)
    pub fn generate_legal_moves(&self) -> Vec<Move> {
        let white = self.white_to_move;
        let mut captures = Vec::new();
        let mut simple = Vec::new();

        for r in 0..8u8 {
            for c in 0..8u8 {
                let p = self.board[r as usize][c as usize];
                if !Self::is_own(p, white) {
                    continue;
                }
                // Generate captures for this piece
                let mut piece_captures = Vec::new();
                let mut visited = [[false; 8]; 8];
                self.gen_captures(r, c, p, &mut vec![(r, c)], &mut vec![], &mut visited, &mut piece_captures);
                captures.extend(piece_captures);

                // Generate simple moves
                if captures.is_empty() {
                    self.gen_simple_moves(r, c, p, &mut simple);
                }
            }
        }

        // Mandatory capture: if any captures exist, only captures are legal
        if !captures.is_empty() {
            captures
        } else {
            simple
        }
    }

    fn gen_simple_moves(&self, r: u8, c: u8, piece: i8, moves: &mut Vec<Move>) {
        let dirs = self.get_move_dirs(piece);
        for (dr, dc) in dirs {
            let nr = r as i8 + dr;
            let nc = c as i8 + dc;
            if !Self::in_bounds(nr, nc) {
                continue;
            }
            if self.board[nr as usize][nc as usize] != EMPTY {
                continue;
            }
            let promoted = Self::would_promote(piece, nr as u8);
            moves.push(Move {
                steps: vec![(r, c), (nr as u8, nc as u8)],
                captures: vec![],
                piece,
                promoted,
            });
        }
    }

    fn gen_captures(
        &self, r: u8, c: u8, piece: i8,
        path: &mut Vec<(u8, u8)>,
        captured: &mut Vec<(u8, u8)>,
        visited: &mut [[bool; 8]; 8],
        results: &mut Vec<Move>,
    ) {
        let dirs = self.get_move_dirs(piece);
        let white = self.white_to_move;
        let mut found_capture = false;

        for (dr, dc) in dirs {
            let mr = r as i8 + dr;  // middle (enemy) square
            let mc = c as i8 + dc;
            let lr = r as i8 + dr * 2;  // landing square
            let lc = c as i8 + dc * 2;

            if !Self::in_bounds(mr, mc) || !Self::in_bounds(lr, lc) {
                continue;
            }

            let mid_piece = self.board[mr as usize][mc as usize];
            let land_piece = self.board[lr as usize][lc as usize];

            // Must jump over enemy to empty square, and not already captured this piece
            if !Self::is_enemy(mid_piece, white) || land_piece != EMPTY {
                continue;
            }
            if visited[mr as usize][mc as usize] {
                continue;
            }

            found_capture = true;
            visited[mr as usize][mc as usize] = true;
            captured.push((mr as u8, mc as u8));
            path.push((lr as u8, lc as u8));

            // Check if piece promotes mid-chain (in standard checkers, promotion ends the turn)
            let will_promote = Self::would_promote(piece, lr as u8) && !Self::is_king(piece);

            if will_promote {
                // Promotion stops the multi-jump chain
                results.push(Move {
                    steps: path.clone(),
                    captures: captured.clone(),
                    piece,
                    promoted: true,
                });
            } else {
                // Try to continue jumping (use king dirs if the piece is already a king)
                self.gen_captures(lr as u8, lc as u8, piece, path, captured, visited, results);
            }

            path.pop();
            captured.pop();
            visited[mr as usize][mc as usize] = false;
        }

        // If no further captures found, this is a terminal position in the chain
        if !found_capture && path.len() > 1 {
            results.push(Move {
                steps: path.clone(),
                captures: captured.clone(),
                piece,
                promoted: Self::would_promote(piece, r) && !Self::is_king(piece),
            });
        }
    }

    fn get_move_dirs(&self, piece: i8) -> Vec<(i8, i8)> {
        match piece {
            W_MAN => vec![(1, -1), (1, 1)],
            B_MAN => vec![(-1, -1), (-1, 1)],
            W_KING | B_KING => vec![(1, -1), (1, 1), (-1, -1), (-1, 1)],
            _ => vec![],
        }
    }

    fn would_promote(piece: i8, dest_row: u8) -> bool {
        (piece == W_MAN && dest_row == 7) || (piece == B_MAN && dest_row == 0)
    }

    pub fn make_move(&mut self, m: &Move) {
        let (fr, fc) = m.from_pos();
        let (tr, tc) = m.to_pos();
        let piece = self.board[fr as usize][fc as usize];

        let undo = UndoInfo {
            moved_piece: piece,
            steps: m.steps.clone(),
            captured_pieces: m.captures.iter().map(|&(r, c)| {
                ((r, c), self.board[r as usize][c as usize])
            }).collect(),
            promoted: m.promoted,
            prev_no_progress: self.no_progress_count,
            prev_hash: self.current_hash,
        };

        // Remove piece from source
        let pi = ZobristKeys::piece_index(piece);
        let si = Self::square_index(fr, fc);
        self.current_hash ^= self.zobrist.pieces[pi][si];
        self.board[fr as usize][fc as usize] = EMPTY;

        // Remove captured pieces
        for &(cr, cc) in &m.captures {
            let cp = self.board[cr as usize][cc as usize];
            let cpi = ZobristKeys::piece_index(cp);
            let csi = Self::square_index(cr, cc);
            self.current_hash ^= self.zobrist.pieces[cpi][csi];
            self.board[cr as usize][cc as usize] = EMPTY;
        }

        // Place piece at destination (possibly promoted)
        let final_piece = if m.promoted {
            if piece > 0 { W_KING } else { B_KING }
        } else {
            piece
        };
        self.board[tr as usize][tc as usize] = final_piece;
        let fpi = ZobristKeys::piece_index(final_piece);
        let fsi = Self::square_index(tr, tc);
        self.current_hash ^= self.zobrist.pieces[fpi][fsi];

        // Update no-progress counter
        if m.is_capture() || m.promoted {
            self.no_progress_count = 0;
        } else {
            self.no_progress_count += 1;
        }

        // Switch side
        self.current_hash ^= self.zobrist.side;
        self.white_to_move = !self.white_to_move;

        self.move_history.push(undo);
        self.hash_history.push(self.current_hash);
    }

    pub fn unmake_move(&mut self) {
        let undo = match self.move_history.pop() {
            Some(u) => u,
            None => return,
        };
        self.hash_history.pop();

        self.white_to_move = !self.white_to_move;

        let (fr, fc) = undo.steps[0];
        let (tr, tc) = *undo.steps.last().unwrap();

        // Remove piece from destination
        self.board[tr as usize][tc as usize] = EMPTY;

        // Restore original piece at source
        self.board[fr as usize][fc as usize] = undo.moved_piece;

        // Restore captured pieces
        for &((cr, cc), cp) in &undo.captured_pieces {
            self.board[cr as usize][cc as usize] = cp;
        }

        self.no_progress_count = undo.prev_no_progress;
        self.current_hash = *self.hash_history.last().unwrap_or(&0);
    }

    pub fn is_threefold_repetition(&self) -> bool {
        if self.hash_history.len() < 5 {
            return false;
        }
        let current = self.current_hash;
        let mut count = 0u32;
        for &h in &self.hash_history {
            if h == current {
                count += 1;
                if count >= 3 {
                    return true;
                }
            }
        }
        false
    }

    pub fn get_result(&self) -> GameResult {
        let moves = self.generate_legal_moves();
        if moves.is_empty() {
            // Player with no moves loses
            return if self.white_to_move {
                GameResult::BlackWins
            } else {
                GameResult::WhiteWins
            };
        }
        // 40-move rule (80 half-moves without capture or promotion = draw)
        if self.no_progress_count >= 80 {
            return GameResult::Draw;
        }
        if self.is_threefold_repetition() {
            return GameResult::Draw;
        }
        GameResult::Ongoing
    }

    pub fn piece_count(&self) -> (u32, u32) {
        let mut white = 0u32;
        let mut black = 0u32;
        for r in 0..8 {
            for c in 0..8 {
                let p = self.board[r][c];
                if p > 0 { white += 1; }
                else if p < 0 { black += 1; }
            }
        }
        (white, black)
    }

    pub fn clone_engine(&self) -> Self {
        CheckersEngine {
            board: self.board,
            white_to_move: self.white_to_move,
            no_progress_count: self.no_progress_count,
            move_history: self.move_history.clone(),
            hash_history: self.hash_history.clone(),
            zobrist: self.zobrist,
            current_hash: self.current_hash,
        }
    }

    pub fn print_board(&self) {
        println!("  a b c d e f g h");
        for r in (0..8).rev() {
            print!("{} ", r + 1);
            for c in 0..8 {
                let ch = match self.board[r][c] {
                    W_MAN => 'w',
                    W_KING => 'W',
                    B_MAN => 'b',
                    B_KING => 'B',
                    _ => if Self::is_dark(r as u8, c as u8) { '.' } else { ' ' },
                };
                print!("{} ", ch);
            }
            println!();
        }
        println!("  a b c d e f g h");
        println!("{} to move", if self.white_to_move { "White" } else { "Black" });
    }
}
