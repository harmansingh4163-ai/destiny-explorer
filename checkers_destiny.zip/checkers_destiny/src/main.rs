mod engine;
mod explorer;
mod priority;
mod storage;
mod zobrist;

use engine::{CheckersEngine, GameResult, EMPTY, W_MAN, W_KING, B_MAN, B_KING};
use explorer::DestinyExplorer;
use macroquad::prelude::*;

const SAVE_PATH: &str = "checkers_destiny.bin";
const SQ: f32 = 75.0;
const BX: f32 = 40.0;
const BY: f32 = 40.0;
const BOARD: f32 = SQ * 8.0;
const PX: f32 = 660.0;  // Panel X
const STEPS_DEFAULT: u64 = 10_000;
const AUTO_SAVE_SECS: f64 = 30.0;

const COL_LIGHT: Color = Color::new(0.93, 0.87, 0.73, 1.0);
const COL_DARK: Color = Color::new(0.44, 0.30, 0.18, 1.0);
const COL_SELECT: Color = Color::new(0.3, 0.8, 0.3, 0.5);
const COL_LEGAL: Color = Color::new(0.3, 0.6, 0.9, 0.5);
const COL_WIN: Color = Color::new(0.2, 0.8, 0.2, 0.6);
const COL_DRAW: Color = Color::new(0.8, 0.8, 0.2, 0.6);
const COL_LOSS: Color = Color::new(0.8, 0.2, 0.2, 0.6);
const COL_UNKNOWN: Color = Color::new(0.5, 0.5, 0.5, 0.4);
const COL_LAST: Color = Color::new(0.9, 0.9, 0.3, 0.35);
const COL_BG: Color = Color::new(0.12, 0.12, 0.16, 1.0);
const COL_BTN: Color = Color::new(0.22, 0.22, 0.28, 1.0);
const COL_BTN_B: Color = Color::new(0.45, 0.45, 0.55, 1.0);

struct App {
    engine: CheckersEngine,
    explorer: DestinyExplorer,
    selected: Option<(u8, u8)>,
    legal_moves: Vec<engine::Move>,
    destiny: Vec<((u8, u8), Option<GameResult>)>,
    last_move: Option<((u8, u8), (u8, u8))>,
    move_log: Vec<String>,
    game_result: GameResult,
    auto_play: bool,
    auto_play_timer: f64,
    steps_per_frame: u64,
    last_save_time: f64,
    status_msg: String,
    status_timer: f64,
    start_time: f64,
}

impl App {
    fn new() -> Self {
        let mut explorer = DestinyExplorer::new(SAVE_PATH);
        let loaded = explorer.load();
        let status = if loaded > 0 {
            format!("Loaded {} positions from disk", loaded)
        } else {
            "Starting fresh — solving checkers from scratch!".to_string()
        };
        let engine = CheckersEngine::new();
        explorer.start(engine.clone_engine());

        App {
            engine,
            explorer,
            selected: None,
            legal_moves: Vec::new(),
            destiny: Vec::new(),
            last_move: None,
            move_log: Vec::new(),
            game_result: GameResult::Ongoing,
            auto_play: false,
            auto_play_timer: 0.0,
            steps_per_frame: STEPS_DEFAULT,
            last_save_time: get_time(),
            status_msg: status,
            status_timer: 4.0,
            start_time: get_time(),
        }
    }

    fn update(&mut self) {
        let dt = get_frame_time() as f64;

        // Always exploring
        if self.explorer.is_exploring {
            self.explorer.explore_batch(self.steps_per_frame);
        }

        // Check if solved!
        if self.explorer.exploration_complete && self.status_timer <= 0.0 {
            self.status_msg = "CHECKERS SOLVED! Exploration complete!".to_string();
            self.status_timer = 999.0;
        }

        // Auto-save
        let now = get_time();
        if now - self.last_save_time >= AUTO_SAVE_SECS && self.explorer.table.len() > 0 {
            self.explorer.save();
            self.status_msg = format!("Auto-saved {} positions", explorer::format_number(self.explorer.table.len() as u64));
            self.status_timer = 2.0;
            self.last_save_time = now;
        }

        if self.status_timer > 0.0 { self.status_timer -= dt; }

        // Auto-play
        if self.auto_play && self.game_result == GameResult::Ongoing {
            self.auto_play_timer += dt;
            if self.auto_play_timer >= 0.3 {
                self.auto_play_timer = 0.0;
                self.auto_play_one_move();
            }
        }

        // Keyboard
        if is_key_pressed(KeyCode::R) { self.reset_game(); }
        if is_key_pressed(KeyCode::A) { self.auto_play = !self.auto_play; self.auto_play_timer = 0.0; }
        if is_key_pressed(KeyCode::S) {
            self.explorer.save();
            self.status_msg = format!("Saved {} positions", explorer::format_number(self.explorer.table.len() as u64));
            self.status_timer = 3.0;
        }
        if is_key_pressed(KeyCode::U) { self.undo_move(); }
        if is_key_pressed(KeyCode::RightBracket) { self.steps_per_frame = (self.steps_per_frame * 2).min(500_000); }
        if is_key_pressed(KeyCode::LeftBracket) { self.steps_per_frame = (self.steps_per_frame / 2).max(100); }

        // Mouse
        if is_mouse_button_pressed(MouseButton::Left) {
            let (mx, my) = mouse_position();
            self.handle_board_click(mx, my);
            self.handle_button_click(mx, my);
        }
    }

    fn handle_board_click(&mut self, mx: f32, my: f32) {
        let col = ((mx - BX) / SQ) as i32;
        let vrow = ((my - BY) / SQ) as i32;
        let row = 7 - vrow;
        if col < 0 || col > 7 || row < 0 || row > 7 { return; }
        let r = row as u8;
        let c = col as u8;

        // Check if clicking a move destination
        if self.selected.is_some() {
            let found = self.legal_moves.iter()
                .find(|m| { let (tr, tc) = m.to_pos(); tr == r && tc == c })
                .cloned();
            if let Some(m) = found {
                self.execute_move(&m);
                return;
            }
        }

        // Select a piece
        let piece = self.engine.board[r as usize][c as usize];
        if piece != EMPTY && CheckersEngine::is_dark(r, c) &&
           ((self.engine.white_to_move && piece > 0) || (!self.engine.white_to_move && piece < 0)) {
            self.selected = Some((r, c));
            self.legal_moves = self.engine.generate_legal_moves();
            self.legal_moves.retain(|m| { let (fr, fc) = m.from_pos(); fr == r && fc == c });
            self.destiny = self.explorer.get_piece_destiny(r, c, &self.engine);
        } else {
            self.selected = None;
            self.legal_moves.clear();
            self.destiny.clear();
        }
    }

    fn handle_button_click(&mut self, mx: f32, my: f32) {
        let bw = 200.0f32;
        let bh = 32.0f32;
        let mut by = 520.0f32;
        if mx >= PX && mx < PX + bw && my >= by && my < by + bh { self.reset_game(); return; }
        by += 40.0;
        if mx >= PX && mx < PX + bw && my >= by && my < by + bh { self.auto_play = !self.auto_play; self.auto_play_timer = 0.0; return; }
        by += 40.0;
        if mx >= PX && mx < PX + bw && my >= by && my < by + bh {
            self.explorer.save();
            self.status_msg = format!("Saved {}", explorer::format_number(self.explorer.table.len() as u64));
            self.status_timer = 3.0;
            return;
        }
        by += 40.0;
        if mx >= PX && mx < PX + bw && my >= by && my < by + bh { self.undo_move(); return; }
        by += 40.0;
        if mx >= PX && mx < PX + bw && my >= by && my < by + bh {
            self.explorer.table.clear_file();
            self.explorer.table.table.clear();
            self.explorer.games_completed = 0;
            self.explorer.positions_explored = 0;
            self.explorer.positions_cached = 0;
            self.explorer.start(self.engine.clone_engine());
            self.status_msg = "Cleared all data, restarting...".to_string();
            self.status_timer = 3.0;
        }
    }

    fn execute_move(&mut self, m: &engine::Move) {
        let notation = m.to_notation();
        let side = if self.engine.white_to_move { "W" } else { "B" };
        self.last_move = Some((m.from_pos(), m.to_pos()));
        self.engine.make_move(m);
        self.move_log.push(format!("{}: {}", side, notation));
        self.game_result = self.engine.get_result();
        self.selected = None;
        self.legal_moves.clear();
        self.destiny.clear();
    }

    fn auto_play_one_move(&mut self) {
        let mut moves = self.engine.generate_legal_moves();
        if moves.is_empty() {
            self.game_result = self.engine.get_result();
            self.auto_play = false;
            return;
        }
        priority::sort_moves(&mut moves, self.engine.white_to_move);
        let m = moves[0].clone();
        self.execute_move(&m);
    }

    fn undo_move(&mut self) {
        if !self.engine.move_history.is_empty() {
            self.engine.unmake_move();
            self.move_log.pop();
            self.last_move = None;
            self.game_result = self.engine.get_result();
            self.selected = None;
            self.legal_moves.clear();
            self.destiny.clear();
        }
    }

    fn reset_game(&mut self) {
        if self.explorer.table.len() > 0 { self.explorer.save(); }
        self.engine = CheckersEngine::new();
        self.selected = None;
        self.legal_moves.clear();
        self.destiny.clear();
        self.auto_play = false;
        self.move_log.clear();
        self.game_result = GameResult::Ongoing;
        self.last_move = None;
        self.explorer.start(self.engine.clone_engine());
    }

    fn draw(&self) {
        clear_background(COL_BG);
        self.draw_board();
        self.draw_pieces();
        self.draw_overlays();
        self.draw_coordinates();
        self.draw_panel();
        self.draw_move_log();
    }

    fn draw_board(&self) {
        for r in 0..8u8 {
            for c in 0..8u8 {
                let vr = 7 - r;
                let x = BX + c as f32 * SQ;
                let y = BY + vr as f32 * SQ;
                let col = if CheckersEngine::is_dark(r, c) { COL_DARK } else { COL_LIGHT };
                draw_rectangle(x, y, SQ, SQ, col);
            }
        }
        // Last move highlight
        if let Some(((fr, fc), (tr, tc))) = self.last_move {
            self.hl(fr, fc, COL_LAST);
            self.hl(tr, tc, COL_LAST);
        }
    }

    fn hl(&self, r: u8, c: u8, col: Color) {
        let vr = 7 - r;
        draw_rectangle(BX + c as f32 * SQ, BY + vr as f32 * SQ, SQ, SQ, col);
    }

    fn draw_pieces(&self) {
        for r in 0..8u8 {
            for c in 0..8u8 {
                let p = self.engine.board[r as usize][c as usize];
                if p == EMPTY { continue; }
                let vr = 7 - r;
                let cx = BX + c as f32 * SQ + SQ / 2.0;
                let cy = BY + vr as f32 * SQ + SQ / 2.0;
                let radius = SQ * 0.38;

                // Piece color
                let (fill, border, is_king) = match p {
                    W_MAN => (Color::new(0.95, 0.92, 0.85, 1.0), Color::new(0.6, 0.55, 0.45, 1.0), false),
                    W_KING => (Color::new(0.95, 0.92, 0.85, 1.0), Color::new(0.85, 0.75, 0.2, 1.0), true),
                    B_MAN => (Color::new(0.15, 0.15, 0.18, 1.0), Color::new(0.35, 0.35, 0.4, 1.0), false),
                    B_KING => (Color::new(0.15, 0.15, 0.18, 1.0), Color::new(0.85, 0.75, 0.2, 1.0), true),
                    _ => continue,
                };

                // Draw piece
                draw_circle(cx, cy, radius, fill);
                draw_circle_lines(cx, cy, radius, 2.5, border);
                // Inner ring for depth
                draw_circle_lines(cx, cy, radius * 0.75, 1.5, border);

                // Crown for kings
                if is_king {
                    let crown_col = if p > 0 { Color::new(0.7, 0.6, 0.1, 1.0) } else { Color::new(0.9, 0.8, 0.2, 1.0) };
                    draw_text("K", cx - 7.0, cy + 7.0, 22.0, crown_col);
                }
            }
        }
    }

    fn draw_overlays(&self) {
        if let Some((sr, sc)) = self.selected {
            self.hl(sr, sc, COL_SELECT);
        }

        // Destiny colors or legal moves
        if !self.destiny.is_empty() {
            let white = self.engine.white_to_move;
            for &((tr, tc), ref dest) in &self.destiny {
                let col = match dest {
                    None => COL_UNKNOWN,
                    Some(GameResult::WhiteWins) => if white { COL_WIN } else { COL_LOSS },
                    Some(GameResult::BlackWins) => if white { COL_LOSS } else { COL_WIN },
                    Some(GameResult::Draw) => COL_DRAW,
                    Some(GameResult::Ongoing) => COL_UNKNOWN,
                };
                self.hl(tr, tc, col);
                let vr = 7 - tr;
                let label = match dest {
                    Some(GameResult::WhiteWins) => "W",
                    Some(GameResult::BlackWins) => "B",
                    Some(GameResult::Draw) => "D",
                    _ => "?",
                };
                draw_text(label, BX + tc as f32 * SQ + 5.0, BY + vr as f32 * SQ + 16.0, 16.0, WHITE);
            }
        } else if !self.legal_moves.is_empty() {
            for m in &self.legal_moves {
                let (tr, tc) = m.to_pos();
                let vr = 7 - tr;
                let cx = BX + tc as f32 * SQ + SQ / 2.0;
                let cy = BY + vr as f32 * SQ + SQ / 2.0;
                if m.is_capture() {
                    draw_circle_lines(cx, cy, SQ * 0.35, 3.0, COL_LEGAL);
                } else {
                    draw_circle(cx, cy, 10.0, COL_LEGAL);
                }
            }
        }
    }

    fn draw_coordinates(&self) {
        let files = ["a","b","c","d","e","f","g","h"];
        for f in 0..8 {
            draw_text(files[f], BX + f as f32 * SQ + SQ/2.0 - 4.0, BY + BOARD + 18.0, 16.0, GRAY);
        }
        for r in 0..8 {
            let vr = 7 - r;
            draw_text(&format!("{}", r+1), BX - 18.0, BY + vr as f32 * SQ + SQ/2.0 + 5.0, 16.0, GRAY);
        }
    }

    fn draw_panel(&self) {
        let x = PX;
        let mut y = BY;

        draw_text("CHECKERS DESTINY", x, y + 22.0, 22.0, Color::new(0.9, 0.8, 0.6, 1.0));
        y += 36.0;
        draw_text("SOLVER", x, y, 22.0, Color::new(0.9, 0.8, 0.6, 1.0));

        y += 30.0;
        let turn = match self.game_result {
            GameResult::WhiteWins => "White Wins!",
            GameResult::BlackWins => "Black Wins!",
            GameResult::Draw => "Draw!",
            GameResult::Ongoing => if self.engine.white_to_move { "White to move" } else { "Black to move" },
        };
        draw_text(turn, x, y, 18.0, WHITE);

        let (wc, bc) = self.engine.piece_count();
        y += 22.0;
        draw_text(&format!("Pieces: White {} | Black {}", wc, bc), x, y, 14.0, GRAY);

        // Explorer stats
        y += 30.0;
        draw_text("--- Explorer (always running) ---", x, y, 15.0, Color::new(0.6, 0.8, 0.6, 1.0));

        y += 22.0;
        let (status_text, status_col) = if self.explorer.exploration_complete {
            ("SOLVED!", Color::new(1.0, 0.85, 0.0, 1.0))
        } else if self.explorer.is_exploring {
            ("COMPUTING...", Color::new(0.2, 1.0, 0.2, 1.0))
        } else {
            ("STOPPED", Color::new(0.5, 0.8, 1.0, 1.0))
        };
        draw_text(&format!("Status: {}", status_text), x, y, 14.0, status_col);

        let elapsed = get_time() - self.start_time;
        let rate = if elapsed > 0.0 { self.explorer.positions_explored as f64 / elapsed } else { 0.0 };

        y += 18.0; draw_text(&format!("Speed: {}/sec", explorer::format_number(rate as u64)), x, y, 14.0, GRAY);
        y += 18.0; draw_text(&format!("Games: {}", explorer::format_number(self.explorer.games_completed)), x, y, 14.0, GRAY);
        y += 18.0; draw_text(&format!("Explored: {}", explorer::format_number(self.explorer.positions_explored)), x, y, 14.0, GRAY);
        y += 18.0; draw_text(&format!("Duplicates: {}", explorer::format_number(self.explorer.positions_cached)), x, y, 14.0, GRAY);

        let hit_rate = if self.explorer.positions_explored > 0 {
            (self.explorer.positions_cached as f64 / self.explorer.positions_explored as f64) * 100.0
        } else { 0.0 };
        y += 18.0; draw_text(&format!("Hit rate: {:.1}%", hit_rate), x, y, 14.0, GRAY);
        y += 18.0; draw_text(&format!("Stored: {}", explorer::format_number(self.explorer.table.len() as u64)), x, y, 14.0, GRAY);
        y += 18.0; draw_text(&format!("Depth: {}", self.explorer.stack_depth()), x, y, 14.0, GRAY);
        y += 18.0; draw_text(&format!("Steps/frame: {}", explorer::format_number(self.steps_per_frame)), x, y, 14.0, GRAY);
        y += 18.0; draw_text(&format!("Disk: {}", self.explorer.table.file_size_string()), x, y, 14.0, GRAY);

        if self.status_timer > 0.0 {
            y += 22.0;
            let alpha = self.status_timer.min(1.0) as f32;
            draw_text(&self.status_msg, x, y, 13.0, Color::new(0.3, 1.0, 0.5, alpha));
        }

        // Destiny info
        if let Some((sr, sc)) = self.selected {
            if !self.destiny.is_empty() {
                y += 28.0;
                let p = self.engine.board[sr as usize][sc as usize];
                let name = match p { W_MAN => "Man", W_KING => "King", B_MAN => "Man", B_KING => "King", _ => "?" };
                let files = ["a","b","c","d","e","f","g","h"];
                draw_text(&format!("{} on {}{}:", name, files[sc as usize], sr+1), x, y, 15.0, WHITE);
                for &((tr, tc), ref dest) in &self.destiny {
                    y += 16.0;
                    if y > 750.0 { break; }
                    let result_str = match dest {
                        Some(r) => r.name(),
                        None => "Unknown",
                    };
                    let col = match dest {
                        Some(GameResult::WhiteWins) => if self.engine.white_to_move { Color::new(0.4,1.0,0.4,1.0) } else { Color::new(1.0,0.4,0.4,1.0) },
                        Some(GameResult::BlackWins) => if self.engine.white_to_move { Color::new(1.0,0.4,0.4,1.0) } else { Color::new(0.4,1.0,0.4,1.0) },
                        Some(GameResult::Draw) => Color::new(1.0,1.0,0.4,1.0),
                        _ => GRAY,
                    };
                    draw_text(&format!("  -> {}{}: {}", files[tc as usize], tr+1, result_str), x, y, 13.0, col);
                }
            }
        }

        // Buttons
        let mut by = 520.0f32;
        self.draw_button(x, by, "[R] Reset");
        by += 40.0;
        self.draw_button(x, by, &format!("[A] Auto-Play: {}", if self.auto_play { "ON" } else { "OFF" }));
        by += 40.0;
        self.draw_button(x, by, "[S] Save to Disk");
        by += 40.0;
        self.draw_button(x, by, "[U] Undo");
        by += 40.0;
        self.draw_button(x, by, "Clear All Data");

        by += 45.0;
        draw_text("[ ] = Speed -/+", x, by, 13.0, Color::new(0.5, 0.5, 0.5, 1.0));
        by += 16.0;
        draw_text("Click any piece to see destiny", x, by, 13.0, Color::new(0.5, 0.5, 0.5, 1.0));
    }

    fn draw_button(&self, x: f32, y: f32, text: &str) {
        draw_rectangle(x, y, 200.0, 32.0, COL_BTN);
        draw_rectangle_lines(x, y, 200.0, 32.0, 1.0, COL_BTN_B);
        draw_text(text, x + 10.0, y + 22.0, 15.0, WHITE);
    }

    fn draw_move_log(&self) {
        let x = BX;
        let mut y = BY + BOARD + 35.0;
        draw_text("Move Log:", x, y, 14.0, GRAY);
        let start = if self.move_log.len() > 14 { self.move_log.len() - 14 } else { 0 };
        let mut lx = x;
        y += 18.0;
        for i in start..self.move_log.len() {
            draw_text(&self.move_log[i], lx, y, 13.0, Color::new(0.5, 0.5, 0.5, 1.0));
            lx += 85.0;
            if lx > PX - 40.0 { lx = x; y += 16.0; }
        }
    }
}

fn window_conf() -> Conf {
    Conf {
        window_title: "Checkers Destiny Solver".to_owned(),
        window_width: 1280,
        window_height: 800,
        window_resizable: false,
        ..Default::default()
    }
}

#[macroquad::main(window_conf)]
async fn main() {
    let mut app = App::new();
    loop {
        app.update();
        app.draw();
        next_frame().await;
    }
}
