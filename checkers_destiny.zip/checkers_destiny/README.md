# Checkers Destiny Solver

Exhaustively solves American Checkers (8x8) from the opening position using forward game tree exploration with Zobrist hashing and transposition tables for duplicate board elimination.

Checkers has ~5 × 10²⁰ unique positions — large but solvable. Jonathan Schaeffer proved checkers is a draw in 2007 after 18 years of computation. Your M4 Mac Mini can verify this independently.

## Setup

```bash
# Install Rust (one-time)
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh

# Build and run
cd checkers_destiny
cargo run --release
```

## How It Works

Identical algorithm to the Chess Destiny Explorer. The explorer plays every possible game using priority-ordered moves, stores every board position's result, and skips duplicates. The key difference: checkers is small enough that this computation can actually finish.

## Controls

| Key | Action |
|-----|--------|
| R | Reset game |
| A | Toggle auto-play |
| S | Save to disk |
| U | Undo |
| ] | Speed up |
| [ | Slow down |

Click any piece to see destiny colors (green=win, yellow=draw, red=loss).

## Rules Implemented

- 8×8 board, dark squares only (32 playable squares)
- 12 pieces per side
- Men move diagonally forward
- Kings move diagonally in all directions
- Mandatory captures (must jump if possible)
- Multi-jump chains (must continue jumping)
- Promotion on reaching back rank (ends multi-jump)
- Threefold repetition = draw
- 40-move rule (80 half-moves without capture/promotion = draw)
