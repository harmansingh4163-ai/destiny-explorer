use macroquad::prelude::*;
use std::collections::HashMap;

// =====================================================
// DOTS AND BOXES ENGINE (4x4 dots = 3x3 boxes)
// =====================================================
//
// Line indexing:
//   Horizontal 0-11:  h(row, col) = row * 3 + col    (row=0..3, col=0..2)
//   Vertical  12-23:  v(row, col) = 12 + row * 4 + col (row=0..2, col=0..3)
//
// Box (r, c) for r=0..2, c=0..2 has sides:
//   Top:    r * 3 + c
//   Bottom: (r+1) * 3 + c
//   Left:   12 + r * 4 + c
//   Right:  12 + r * 4 + (c + 1)

const TOTAL_LINES: usize = 24;
const TOTAL_BOXES: usize = 9;

fn box_sides(r: usize, c: usize) -> [usize; 4] {
    [
        r * 3 + c,              // top
        (r + 1) * 3 + c,        // bottom
        12 + r * 4 + c,         // left
        12 + r * 4 + (c + 1),   // right
    ]
}

/// How many NEW boxes does drawing line `line_idx` complete?
fn boxes_completed_by(lines: u32, line_idx: usize) -> u8 {
    let new_lines = lines | (1u32 << line_idx);
    let mut count = 0u8;
    for r in 0..3 {
        for c in 0..3 {
            let sides = box_sides(r, c);
            // Was not complete before, is complete now
            let was_complete = sides.iter().all(|&s| lines & (1u32 << s) != 0);
            let now_complete = sides.iter().all(|&s| new_lines & (1u32 << s) != 0);
            if !was_complete && now_complete {
                count += 1;
            }
        }
    }
    count
}

/// Check which player owns each box (returns 0=none, 1=P1, 2=P2)
/// This requires replaying the move history
fn box_owners_from_history(history: &[(usize, bool)]) -> [u8; TOTAL_BOXES] {
    let mut owners = [0u8; TOTAL_BOXES];
    let mut lines = 0u32;
    for &(line_idx, is_p1) in history {
        let new_lines = lines | (1u32 << line_idx);
        for r in 0..3 {
            for c in 0..3 {
                let box_idx = r * 3 + c;
                if owners[box_idx] != 0 {
                    continue;
                }
                let sides = box_sides(r, c);
                let was_complete = sides.iter().all(|&s| lines & (1u32 << s) != 0);
                let now_complete = sides.iter().all(|&s| new_lines & (1u32 << s) != 0);
                if !was_complete && now_complete {
                    owners[box_idx] = if is_p1 { 1 } else { 2 };
                }
            }
        }
        lines = new_lines;
    }
    owners
}

#[derive(Clone)]
struct DotsBoxes {
    lines: u32,           // bitmask of drawn lines
    p1_score: u8,
    p2_score: u8,
    p1_turn: bool,
    history: Vec<(usize, bool)>,  // (line_index, was_p1_turn)
}

impl DotsBoxes {
    fn new() -> Self {
        DotsBoxes {
            lines: 0,
            p1_score: 0,
            p2_score: 0,
            p1_turn: true,
            history: Vec::with_capacity(24),
        }
    }

    fn is_line_drawn(&self, idx: usize) -> bool {
        self.lines & (1u32 << idx) != 0
    }

    fn available_lines(&self) -> Vec<usize> {
        (0..TOTAL_LINES)
            .filter(|&i| !self.is_line_drawn(i))
            .collect()
    }

    fn is_game_over(&self) -> bool {
        self.lines == (1u32 << TOTAL_LINES) - 1
    }

    fn make_move(&mut self, line_idx: usize) {
        let captured = boxes_completed_by(self.lines, line_idx);
        self.history.push((line_idx, self.p1_turn));
        self.lines |= 1u32 << line_idx;

        if captured > 0 {
            if self.p1_turn {
                self.p1_score += captured;
            } else {
                self.p2_score += captured;
            }
            // Same player goes again!
        } else {
            self.p1_turn = !self.p1_turn;
        }
    }

    fn unmake_move(&mut self) {
        if let Some((line_idx, was_p1)) = self.history.pop() {
            let captured = boxes_completed_by(
                self.lines & !(1u32 << line_idx),
                line_idx,
            );
            self.lines &= !(1u32 << line_idx);
            if captured > 0 {
                if was_p1 {
                    self.p1_score -= captured;
                } else {
                    self.p2_score -= captured;
                }
            }
            self.p1_turn = was_p1;
        }
    }

    fn result_name(&self) -> &str {
        if self.p1_score > self.p2_score {
            "Blue Wins"
        } else if self.p2_score > self.p1_score {
            "Red Wins"
        } else {
            "Draw"
        }
    }

    /// Compact hash for transposition table
    fn hash(&self) -> u64 {
        (self.lines as u64)
            | ((self.p1_turn as u64) << 24)
            | ((self.p1_score as u64) << 25)
            | ((self.p2_score as u64) << 29)
    }
}

// =====================================================
// SOLVER
// =====================================================

struct Solver {
    /// Maps hash -> optimal score difference (p1_score - p2_score) at end of game
    table: HashMap<u64, i8>,
    positions_explored: u64,
    positions_cached: u64,
}

impl Solver {
    fn new() -> Self {
        Solver {
            table: HashMap::with_capacity(2_000_000),
            positions_explored: 0,
            positions_cached: 0,
        }
    }

    /// Solve completely. Returns optimal (p1_final - p2_final) from this position.
    fn solve(&mut self, game: &mut DotsBoxes) -> i8 {
        self.positions_explored += 1;

        let hash = game.hash();
        if let Some(&cached) = self.table.get(&hash) {
            self.positions_cached += 1;
            return cached;
        }

        // Game over
        if game.is_game_over() {
            let diff = game.p1_score as i8 - game.p2_score as i8;
            self.table.insert(hash, diff);
            return diff;
        }

        let moves = game.available_lines();
        let is_p1 = game.p1_turn;
        let mut best = if is_p1 { i8::MIN } else { i8::MAX };

        for m in moves {
            game.make_move(m);
            let result = self.solve(game);
            game.unmake_move();

            if is_p1 {
                best = best.max(result);
            } else {
                best = best.min(result);
            }
        }

        self.table.insert(hash, best);
        best
    }

    /// Get destiny of a specific move: returns optimal final score diff
    fn get_move_destiny(&self, game: &DotsBoxes, line_idx: usize) -> Option<i8> {
        let mut test = game.clone();
        test.make_move(line_idx);
        let hash = test.hash();
        self.table.get(&hash).copied()
    }
}

// =====================================================
// GUI
// =====================================================

const DOT_SPACING: f32 = 140.0;
const BOARD_OFF_X: f32 = 80.0;
const BOARD_OFF_Y: f32 = 80.0;
const DOT_RADIUS: f32 = 8.0;
const LINE_THICKNESS: f32 = 6.0;
const LINE_HIT_DIST: f32 = 18.0;
const PANEL_X: f32 = 580.0;

const BG: Color = Color::new(0.10, 0.10, 0.14, 1.0);
const P1_COL: Color = Color::new(0.30, 0.55, 1.0, 1.0);     // Blue
const P2_COL: Color = Color::new(1.0, 0.40, 0.35, 1.0);      // Red
const P1_FILL: Color = Color::new(0.20, 0.35, 0.65, 0.35);
const P2_FILL: Color = Color::new(0.65, 0.25, 0.20, 0.35);
const LINE_UNDRAWN: Color = Color::new(0.25, 0.25, 0.30, 1.0);
const LINE_HOVER: Color = Color::new(0.50, 0.50, 0.55, 1.0);
const DOT_COL: Color = Color::new(0.75, 0.75, 0.80, 1.0);
const WIN_COL: Color = Color::new(0.15, 0.85, 0.30, 0.9);
const DRAW_COL: Color = Color::new(0.90, 0.85, 0.15, 0.9);
const LOSS_COL: Color = Color::new(0.90, 0.25, 0.20, 0.9);

/// Get screen position of a dot
fn dot_pos(row: usize, col: usize) -> (f32, f32) {
    (
        BOARD_OFF_X + col as f32 * DOT_SPACING,
        BOARD_OFF_Y + row as f32 * DOT_SPACING,
    )
}

/// Get endpoints of a line on screen
fn line_endpoints(idx: usize) -> ((f32, f32), (f32, f32)) {
    if idx < 12 {
        // Horizontal: h(row, col) = row * 3 + col
        let row = idx / 3;
        let col = idx % 3;
        (dot_pos(row, col), dot_pos(row, col + 1))
    } else {
        // Vertical: v(row, col) = 12 + row * 4 + col
        let vi = idx - 12;
        let row = vi / 4;
        let col = vi % 4;
        (dot_pos(row, col), dot_pos(row + 1, col))
    }
}

/// Get midpoint of a line
fn line_midpoint(idx: usize) -> (f32, f32) {
    let (a, b) = line_endpoints(idx);
    ((a.0 + b.0) / 2.0, (a.1 + b.1) / 2.0)
}

/// Distance from point to line segment
fn point_to_line_dist(px: f32, py: f32, x1: f32, y1: f32, x2: f32, y2: f32) -> f32 {
    let dx = x2 - x1;
    let dy = y2 - y1;
    let len_sq = dx * dx + dy * dy;
    if len_sq < 0.001 {
        return ((px - x1).powi(2) + (py - y1).powi(2)).sqrt();
    }
    let t = ((px - x1) * dx + (py - y1) * dy) / len_sq;
    let t = t.clamp(0.0, 1.0);
    let proj_x = x1 + t * dx;
    let proj_y = y1 + t * dy;
    ((px - proj_x).powi(2) + (py - proj_y).powi(2)).sqrt()
}

struct App {
    game: DotsBoxes,
    solver: Solver,
    hover_line: Option<usize>,
    game_count: u32,
    opening_diff: i8,
}

impl App {
    fn new() -> Self {
        let mut solver = Solver::new();
        let mut game = DotsBoxes::new();
        let opening_diff = solver.solve(&mut game);
        println!(
            "Solved! {} positions, {} cached, {} unique. Opening: {}",
            solver.positions_explored,
            solver.positions_cached,
            solver.table.len(),
            if opening_diff > 0 {
                "Blue wins"
            } else if opening_diff < 0 {
                "Red wins"
            } else {
                "Draw"
            }
        );

        App {
            game: DotsBoxes::new(),
            solver,
            hover_line: None,
            game_count: 1,
            opening_diff,
        }
    }

    fn update(&mut self) {
        let (mx, my) = mouse_position();

        // Find closest undrawn line to mouse
        self.hover_line = None;
        let mut best_dist = LINE_HIT_DIST;
        for idx in 0..TOTAL_LINES {
            if self.game.is_line_drawn(idx) {
                continue;
            }
            let ((x1, y1), (x2, y2)) = line_endpoints(idx);
            let d = point_to_line_dist(mx, my, x1, y1, x2, y2);
            if d < best_dist {
                best_dist = d;
                self.hover_line = Some(idx);
            }
        }

        // Click to draw a line
        if is_mouse_button_pressed(MouseButton::Left) && !self.game.is_game_over() {
            if let Some(line_idx) = self.hover_line {
                self.game.make_move(line_idx);
            }
        }

        if is_key_pressed(KeyCode::R) {
            self.game = DotsBoxes::new();
            self.game_count += 1;
        }
        if is_key_pressed(KeyCode::U) {
            self.game.unmake_move();
        }
    }

    fn draw(&self) {
        clear_background(BG);
        self.draw_box_fills();
        self.draw_lines();
        self.draw_destiny_indicators();
        self.draw_dots();
        self.draw_scores();
        self.draw_panel();
    }

    fn draw_box_fills(&self) {
        let owners = box_owners_from_history(&self.game.history);
        for r in 0..3 {
            for c in 0..3 {
                let box_idx = r * 3 + c;
                let owner = owners[box_idx];
                if owner == 0 {
                    continue;
                }
                let (x, y) = dot_pos(r, c);
                let fill = if owner == 1 { P1_FILL } else { P2_FILL };
                draw_rectangle(x, y, DOT_SPACING, DOT_SPACING, fill);
                // Owner initial
                let label = if owner == 1 { "B" } else { "R" };
                let col = if owner == 1 { P1_COL } else { P2_COL };
                let dim = measure_text(label, None, 28, 1.0);
                draw_text(
                    label,
                    x + DOT_SPACING / 2.0 - dim.width / 2.0,
                    y + DOT_SPACING / 2.0 + dim.height / 2.0,
                    28.0,
                    Color::new(col.r, col.g, col.b, 0.5),
                );
            }
        }
    }

    fn draw_lines(&self) {
        let game_over = self.game.is_game_over();
        // Draw undrawn lines first (faint)
        for idx in 0..TOTAL_LINES {
            let ((x1, y1), (x2, y2)) = line_endpoints(idx);
            if !self.game.is_line_drawn(idx) {
                let col = if !game_over && self.hover_line == Some(idx) {
                    LINE_HOVER
                } else {
                    LINE_UNDRAWN
                };
                draw_line(x1, y1, x2, y2, 3.0, col);
            }
        }
        // Draw drawn lines (thick, colored by who drew them)
        for &(line_idx, was_p1) in &self.game.history {
            let ((x1, y1), (x2, y2)) = line_endpoints(line_idx);
            let col = if was_p1 { P1_COL } else { P2_COL };
            draw_line(x1, y1, x2, y2, LINE_THICKNESS, col);
        }
    }

    fn draw_destiny_indicators(&self) {
        if self.game.is_game_over() {
            return;
        }
        let is_p1 = self.game.p1_turn;

        for idx in 0..TOTAL_LINES {
            if self.game.is_line_drawn(idx) {
                continue;
            }
            if let Some(diff) = self.solver.get_move_destiny(&self.game, idx) {
                // diff is p1_final - p2_final
                // For current player: positive diff is good for P1, negative for P2
                let col = if is_p1 {
                    if diff > 0 {
                        WIN_COL
                    } else if diff == 0 {
                        DRAW_COL
                    } else {
                        LOSS_COL
                    }
                } else {
                    if diff < 0 {
                        WIN_COL
                    } else if diff == 0 {
                        DRAW_COL
                    } else {
                        LOSS_COL
                    }
                };

                let (mx, my) = line_midpoint(idx);
                draw_circle(mx, my, 12.0, col);

                // Show score difference
                let label = if diff > 0 {
                    format!("+{}", diff)
                } else {
                    format!("{}", diff)
                };
                let dim = measure_text(&label, None, 11, 1.0);
                draw_text(
                    &label,
                    mx - dim.width / 2.0,
                    my + 4.0,
                    11.0,
                    Color::new(0.0, 0.0, 0.0, 0.9),
                );
            }
        }
    }

    fn draw_dots(&self) {
        for r in 0..4 {
            for c in 0..4 {
                let (x, y) = dot_pos(r, c);
                draw_circle(x, y, DOT_RADIUS, DOT_COL);
            }
        }
    }

    fn draw_scores(&self) {
        let y = BOARD_OFF_Y + 3.0 * DOT_SPACING + 40.0;
        let p1_text = format!("Blue: {}", self.game.p1_score);
        let p2_text = format!("Red: {}", self.game.p2_score);
        draw_text(&p1_text, BOARD_OFF_X, y, 24.0, P1_COL);
        draw_text(&p2_text, BOARD_OFF_X + 180.0, y, 24.0, P2_COL);

        if self.game.is_game_over() {
            let result = self.game.result_name();
            let col = if self.game.p1_score > self.game.p2_score {
                P1_COL
            } else if self.game.p2_score > self.game.p1_score {
                P2_COL
            } else {
                DRAW_COL
            };
            draw_text(result, BOARD_OFF_X + 120.0, y + 35.0, 28.0, col);
        }
    }

    fn draw_panel(&self) {
        let x = PANEL_X;
        let mut y = BOARD_OFF_Y;

        draw_text("DOTS & BOXES", x, y + 22.0, 24.0, Color::new(0.9, 0.85, 0.7, 1.0));
        y += 28.0;
        draw_text("DESTINY EXPLORER", x, y, 24.0, Color::new(0.9, 0.85, 0.7, 1.0));

        y += 35.0;
        let turn = if self.game.is_game_over() {
            "Game Over"
        } else if self.game.p1_turn {
            "Blue's turn"
        } else {
            "Red's turn"
        };
        let turn_col = if self.game.is_game_over() {
            WHITE
        } else if self.game.p1_turn {
            P1_COL
        } else {
            P2_COL
        };
        draw_text(turn, x, y, 20.0, turn_col);

        y += 22.0;
        draw_text(&format!("Game #{}", self.game_count), x, y, 14.0, GRAY);

        // Solver stats
        y += 35.0;
        draw_text("--- Solver Stats ---", x, y, 16.0, Color::new(0.5, 0.85, 0.5, 1.0));

        y += 25.0;
        draw_text("Status: SOLVED!", x, y, 15.0, Color::new(1.0, 0.85, 0.0, 1.0));
        y += 20.0;
        draw_text(
            &format!("Positions explored: {}", format_num(self.solver.positions_explored)),
            x, y, 14.0, GRAY,
        );
        y += 20.0;
        draw_text(
            &format!("Duplicates skipped: {}", format_num(self.solver.positions_cached)),
            x, y, 14.0, GRAY,
        );
        y += 20.0;
        draw_text(
            &format!("Unique positions: {}", format_num(self.solver.table.len() as u64)),
            x, y, 14.0, GRAY,
        );
        y += 20.0;
        let hit_rate = if self.solver.positions_explored > 0 {
            (self.solver.positions_cached as f64 / self.solver.positions_explored as f64) * 100.0
        } else {
            0.0
        };
        draw_text(&format!("Cache hit rate: {:.1}%", hit_rate), x, y, 14.0, GRAY);

        // Opening verdict
        y += 35.0;
        draw_text("--- Opening Verdict ---", x, y, 16.0, Color::new(0.5, 0.85, 0.5, 1.0));
        y += 25.0;
        let (verdict, vcol) = if self.opening_diff > 0 {
            (format!("Blue wins by {} (perfect play)", self.opening_diff), P1_COL)
        } else if self.opening_diff < 0 {
            (format!("Red wins by {} (perfect play)", -self.opening_diff), P2_COL)
        } else {
            ("Draw (perfect play)".to_string(), DRAW_COL)
        };
        draw_text(&verdict, x, y, 16.0, vcol);

        // Current position destiny
        if !self.game.is_game_over() {
            let current_hash = self.game.hash();
            if let Some(&diff) = self.solver.table.get(&current_hash) {
                y += 30.0;
                let status = if self.game.p1_turn {
                    if diff > 0 { format!("Blue ahead by {}", diff) }
                    else if diff < 0 { format!("Blue behind by {}", -diff) }
                    else { "Even position".to_string() }
                } else {
                    if diff < 0 { format!("Red ahead by {}", -diff) }
                    else if diff > 0 { format!("Red behind by {}", diff) }
                    else { "Even position".to_string() }
                };
                draw_text(&format!("Optimal outcome: {}", status), x, y, 14.0, GRAY);
            }
        }

        // Legend
        y += 35.0;
        draw_text("--- Destiny Colors ---", x, y, 16.0, Color::new(0.5, 0.85, 0.5, 1.0));
        y += 25.0;
        draw_circle(x + 8.0, y - 4.0, 8.0, WIN_COL);
        draw_text("Win for current player", x + 25.0, y + 2.0, 14.0, GRAY);
        y += 22.0;
        draw_circle(x + 8.0, y - 4.0, 8.0, DRAW_COL);
        draw_text("Draw", x + 25.0, y + 2.0, 14.0, GRAY);
        y += 22.0;
        draw_circle(x + 8.0, y - 4.0, 8.0, LOSS_COL);
        draw_text("Loss for current player", x + 25.0, y + 2.0, 14.0, GRAY);
        y += 22.0;
        draw_text("Number = final score difference", x, y, 12.0, Color::new(0.45, 0.45, 0.5, 1.0));

        // Controls
        y += 30.0;
        draw_text("--- Controls ---", x, y, 16.0, Color::new(0.5, 0.85, 0.5, 1.0));
        y += 25.0;
        draw_text("Click a line to draw it", x, y, 14.0, GRAY);
        y += 20.0;
        draw_text("[R] New game", x, y, 14.0, GRAY);
        y += 20.0;
        draw_text("[U] Undo", x, y, 14.0, GRAY);
    }
}

fn format_num(n: u64) -> String {
    if n < 1_000 {
        format!("{}", n)
    } else if n < 1_000_000 {
        format!("{:.1}K", n as f64 / 1_000.0)
    } else {
        format!("{:.2}M", n as f64 / 1_000_000.0)
    }
}

fn window_conf() -> Conf {
    Conf {
        window_title: "Dots & Boxes Destiny Explorer".to_owned(),
        window_width: 1000,
        window_height: 620,
        window_resizable: false,
        ..Default::default()
    }
}

#[macroquad::main(window_conf)]
async fn main() {
    let mut app = App::new();
    loop {
        app.update();
        app.draw();
        next_frame().await;
    }
}
