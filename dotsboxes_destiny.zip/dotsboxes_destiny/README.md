# Dots & Boxes Destiny Explorer

Exhaustively solves the classic Dots & Boxes game (4×4 dots, 3×3 boxes) at startup, then lets you play with perfect information. Every possible line you can draw shows its destiny — whether it leads to a win, draw, or loss with optimal play.

## Run It

```bash
cd dotsboxes_destiny
cargo run --release
```

The solver runs at startup and completes in seconds. Then the game window opens.

## How To Play

- **Click** on the faint lines between dots to draw them
- If you complete a box (all 4 sides), you score a point and go again
- The player with more boxes at the end wins
- Blue (P1) goes first, Red (P2) goes second

## What The Colors Mean

Every undrawn line has a colored circle showing its destiny:

- **Green** with a positive number = this move leads to a WIN (number shows final score advantage)
- **Yellow** with 0 = this move leads to a DRAW
- **Red** with a negative number = this move leads to a LOSS

The numbers show the exact final score difference with perfect play from both sides.

## Controls

- Click a line to draw it
- **R** = New game
- **U** = Undo

## Why This Matters

Dots & Boxes has ~millions of unique positions — enough to be interesting but small enough to solve completely on a Mac Mini M4. This proves the same algorithm used for chess and checkers destiny works correctly and produces perfect results.

The solver shows the exact same stats: positions explored, duplicates skipped (your shortcut!), cache hit rate, and unique positions stored.
