use macroquad::prelude::*;
use std::collections::HashMap;
use std::fs::File;
use std::io::{BufReader, BufWriter, Read, Write};
use std::path::Path;

// =====================================================
// DOTS AND BOXES ENGINE (5x5 dots = 4x4 boxes)
// =====================================================

const TOTAL_LINES: usize = 40;
const TOTAL_BOXES: usize = 16;
const ROWS: usize = 4;
const COLS: usize = 4;
const DOT_ROWS: usize = 5;
const DOT_COLS: usize = 5;
const SAVE_PATH: &str = "dotsboxes5x5_destiny.bin";
const AUTO_SAVE_SECS: f64 = 30.0;

fn box_sides(r: usize, c: usize) -> [usize; 4] {
    [
        r * COLS + c,
        (r + 1) * COLS + c,
        20 + r * DOT_COLS + c,
        20 + r * DOT_COLS + (c + 1),
    ]
}

fn boxes_completed_by(lines: u64, line_idx: usize) -> u8 {
    let new_lines = lines | (1u64 << line_idx);
    let mut count = 0u8;
    for r in 0..ROWS {
        for c in 0..COLS {
            let sides = box_sides(r, c);
            let was = sides.iter().all(|&s| lines & (1u64 << s) != 0);
            let now = sides.iter().all(|&s| new_lines & (1u64 << s) != 0);
            if !was && now {
                count += 1;
            }
        }
    }
    count
}

fn box_owners_from_history(history: &[(usize, bool)]) -> [u8; TOTAL_BOXES] {
    let mut owners = [0u8; TOTAL_BOXES];
    let mut lines = 0u64;
    for &(line_idx, is_p1) in history {
        let new_lines = lines | (1u64 << line_idx);
        for r in 0..ROWS {
            for c in 0..COLS {
                let box_idx = r * COLS + c;
                if owners[box_idx] != 0 {
                    continue;
                }
                let sides = box_sides(r, c);
                let was = sides.iter().all(|&s| lines & (1u64 << s) != 0);
                let now = sides.iter().all(|&s| new_lines & (1u64 << s) != 0);
                if !was && now {
                    owners[box_idx] = if is_p1 { 1 } else { 2 };
                }
            }
        }
        lines = new_lines;
    }
    owners
}

#[derive(Clone)]
struct DotsBoxes {
    lines: u64,
    p1_score: u8,
    p2_score: u8,
    p1_turn: bool,
    history: Vec<(usize, bool)>,
}

impl DotsBoxes {
    fn new() -> Self {
        DotsBoxes {
            lines: 0,
            p1_score: 0,
            p2_score: 0,
            p1_turn: true,
            history: Vec::with_capacity(40),
        }
    }

    fn is_line_drawn(&self, idx: usize) -> bool {
        self.lines & (1u64 << idx) != 0
    }

    fn available_lines(&self) -> Vec<usize> {
        (0..TOTAL_LINES)
            .filter(|&i| !self.is_line_drawn(i))
            .collect()
    }

    fn is_game_over(&self) -> bool {
        self.p1_score + self.p2_score == TOTAL_BOXES as u8
    }

    fn make_move(&mut self, line_idx: usize) {
        let captured = boxes_completed_by(self.lines, line_idx);
        self.history.push((line_idx, self.p1_turn));
        self.lines |= 1u64 << line_idx;
        if captured > 0 {
            if self.p1_turn {
                self.p1_score += captured;
            } else {
                self.p2_score += captured;
            }
            // Same player goes again — don't switch turn
        } else {
            self.p1_turn = !self.p1_turn;
        }
    }

    fn unmake_move(&mut self) {
        if let Some((line_idx, was_p1)) = self.history.pop() {
            let captured = boxes_completed_by(
                self.lines & !(1u64 << line_idx),
                line_idx,
            );
            self.lines &= !(1u64 << line_idx);
            if captured > 0 {
                if was_p1 {
                    self.p1_score -= captured;
                } else {
                    self.p2_score -= captured;
                }
            }
            self.p1_turn = was_p1;
        }
    }

    fn hash(&self) -> u64 {
        self.lines
            | ((self.p1_turn as u64) << 40)
            | ((self.p1_score as u64) << 41)
            | ((self.p2_score as u64) << 46)
    }

    fn result_name(&self) -> &str {
        if self.p1_score > self.p2_score { "Blue Wins" }
        else if self.p2_score > self.p1_score { "Red Wins" }
        else { "Draw" }
    }
}

// =====================================================
// PRIORITY ORDERING
// =====================================================
// Lines that complete boxes first, then leftmost, then topmost

fn sort_lines_by_priority(lines_available: &mut Vec<usize>, current_lines: u64) {
    lines_available.sort_by(|&a, &b| {
        let cap_a = boxes_completed_by(current_lines, a);
        let cap_b = boxes_completed_by(current_lines, b);
        // Captures first (higher priority)
        cap_b.cmp(&cap_a).then(a.cmp(&b))
    });
}

// =====================================================
// TRANSPOSITION TABLE WITH DISK PERSISTENCE
// =====================================================

struct TransTable {
    table: HashMap<u64, i8>,  // hash -> (p1_score - p2_score) at end of game
}

impl TransTable {
    fn new() -> Self {
        TransTable {
            table: HashMap::with_capacity(10_000_000),
        }
    }

    fn get(&self, hash: u64) -> Option<i8> {
        self.table.get(&hash).copied()
    }

    fn insert(&mut self, hash: u64, result: i8) {
        self.table.insert(hash, result);
    }

    fn len(&self) -> usize {
        self.table.len()
    }

    fn save(&self) -> bool {
        let file = match File::create(SAVE_PATH) {
            Ok(f) => f,
            Err(_) => return false,
        };
        let mut w = BufWriter::with_capacity(1024 * 1024, file);
        let count = self.table.len() as u64;
        if w.write_all(&count.to_le_bytes()).is_err() { return false; }
        for (&hash, &result) in &self.table {
            if w.write_all(&hash.to_le_bytes()).is_err() { return false; }
            if w.write_all(&[result as u8]).is_err() { return false; }
        }
        w.flush().is_ok()
    }

    fn load(&mut self) -> usize {
        let path = Path::new(SAVE_PATH);
        if !path.exists() { return 0; }
        let file = match File::open(path) {
            Ok(f) => f,
            Err(_) => return 0,
        };
        let mut r = BufReader::with_capacity(1024 * 1024, file);
        let mut buf8 = [0u8; 8];
        let mut buf1 = [0u8; 1];
        if r.read_exact(&mut buf8).is_err() { return 0; }
        let count = u64::from_le_bytes(buf8) as usize;
        self.table.reserve(count);
        for _ in 0..count {
            if r.read_exact(&mut buf8).is_err() { break; }
            if r.read_exact(&mut buf1).is_err() { break; }
            self.table.insert(u64::from_le_bytes(buf8), buf1[0] as i8);
        }
        self.table.len()
    }

    fn file_size_string(&self) -> String {
        let path = Path::new(SAVE_PATH);
        if !path.exists() { return "No save".to_string(); }
        match std::fs::metadata(path) {
            Ok(m) => {
                let s = m.len();
                if s < 1024 { format!("{} B", s) }
                else if s < 1_048_576 { format!("{:.1} KB", s as f64 / 1024.0) }
                else if s < 1_073_741_824 { format!("{:.1} MB", s as f64 / 1_048_576.0) }
                else { format!("{:.2} GB", s as f64 / 1_073_741_824.0) }
            }
            Err(_) => "Error".to_string(),
        }
    }

    fn clear(&mut self) {
        self.table.clear();
        let path = Path::new(SAVE_PATH);
        if path.exists() { let _ = std::fs::remove_file(path); }
    }
}

// =====================================================
// DESTINY EXPLORER - YOUR PURE ALGORITHM
// No pruning. Exhaustive DFS with backtracking.
// Only optimization: duplicate elimination via hash table.
// =====================================================

struct Frame {
    moves: Vec<usize>,  // available lines, sorted by priority
    move_index: usize,
    results: Vec<i8>,    // final score diffs from each child
    hash_before: u64,
}

struct Explorer {
    table: TransTable,
    engine: DotsBoxes,
    stack: Vec<Frame>,
    pub games_completed: u64,
    pub positions_explored: u64,
    pub positions_cached: u64,
    pub is_exploring: bool,
    pub exploration_complete: bool,
}

impl Explorer {
    fn new() -> Self {
        Explorer {
            table: TransTable::new(),
            engine: DotsBoxes::new(),
            stack: Vec::with_capacity(64),
            games_completed: 0,
            positions_explored: 0,
            positions_cached: 0,
            is_exploring: false,
            exploration_complete: false,
        }
    }

    fn start(&mut self, engine: DotsBoxes) {
        self.stack.clear();
        self.is_exploring = true;
        self.exploration_complete = false;
        self.engine = engine;
        self.push_level();
    }

    fn push_level(&mut self) {
        let mut moves = self.engine.available_lines();
        sort_lines_by_priority(&mut moves, self.engine.lines);
        let hash = self.engine.hash();
        self.stack.push(Frame {
            moves,
            move_index: 0,
            results: Vec::new(),
            hash_before: hash,
        });
    }

    fn step(&mut self) -> bool {
        if !self.is_exploring || self.exploration_complete { return false; }
        if self.stack.is_empty() {
            self.exploration_complete = true;
            self.is_exploring = false;
            return false;
        }

        let slen = self.stack.len();
        let moves_empty = self.stack[slen - 1].moves.is_empty();
        let idx = self.stack[slen - 1].move_index;
        let moves_len = self.stack[slen - 1].moves.len();

        // Terminal: game over (all lines drawn or no moves)
        if moves_empty {
            let diff = self.engine.p1_score as i8 - self.engine.p2_score as i8;
            let hash = self.engine.hash();
            self.table.insert(hash, diff);
            if self.stack.len() > 1 {
                self.stack.pop();
                if let Some(parent) = self.stack.last_mut() {
                    parent.results.push(diff);
                }
            } else {
                self.stack.pop();
            }
            self.games_completed += 1;
            return true;
        }

        // All moves tried — propagate best result
        if idx >= moves_len {
            let frame = self.stack.pop().unwrap();
            let is_p1 = self.engine.p1_turn;
            let best = if is_p1 {
                *frame.results.iter().max().unwrap_or(&0)
            } else {
                *frame.results.iter().min().unwrap_or(&0)
            };
            self.table.insert(frame.hash_before, best);
            if let Some(parent) = self.stack.last_mut() {
                parent.results.push(best);
                self.engine.unmake_move();
                parent.move_index += 1;
            }
            return true;
        }

        // Try next move
        let line_idx = self.stack[slen - 1].moves[idx];
        self.engine.make_move(line_idx);
        self.positions_explored += 1;
        let hash = self.engine.hash();

        // DUPLICATE ELIMINATION — your shortcut
        if let Some(cached) = self.table.get(hash) {
            self.positions_cached += 1;
            self.engine.unmake_move();
            let frame = self.stack.last_mut().unwrap();
            frame.results.push(cached);
            frame.move_index = idx + 1;
            return true;
        }

        // Check if game over
        if self.engine.is_game_over() {
            let diff = self.engine.p1_score as i8 - self.engine.p2_score as i8;
            self.table.insert(hash, diff);
            self.engine.unmake_move();
            let frame = self.stack.last_mut().unwrap();
            frame.results.push(diff);
            frame.move_index = idx + 1;
            self.games_completed += 1;
            return true;
        }

        // Go deeper
        self.push_level();
        true
    }

    fn explore_batch(&mut self, steps: u64) -> u64 {
        let mut done = 0u64;
        for _ in 0..steps {
            if !self.step() { break; }
            done += 1;
        }
        done
    }

    fn get_move_destiny(&self, game: &DotsBoxes, line_idx: usize) -> Option<i8> {
        let mut test = game.clone();
        test.make_move(line_idx);
        self.table.get(test.hash())
    }

    fn stack_depth(&self) -> usize {
        self.stack.len()
    }
}

// =====================================================
// GUI
// =====================================================

const DOT_SPACING: f32 = 110.0;
const BOARD_OFF_X: f32 = 60.0;
const BOARD_OFF_Y: f32 = 60.0;
const DOT_RADIUS: f32 = 7.0;
const LINE_THICKNESS: f32 = 5.0;
const LINE_HIT_DIST: f32 = 16.0;
const PANEL_X: f32 = 570.0;

const BG: Color = Color::new(0.10, 0.10, 0.14, 1.0);
const P1_COL: Color = Color::new(0.30, 0.55, 1.0, 1.0);
const P2_COL: Color = Color::new(1.0, 0.40, 0.35, 1.0);
const P1_FILL: Color = Color::new(0.20, 0.35, 0.65, 0.35);
const P2_FILL: Color = Color::new(0.65, 0.25, 0.20, 0.35);
const LINE_UNDRAWN: Color = Color::new(0.25, 0.25, 0.30, 1.0);
const LINE_HOVER: Color = Color::new(0.50, 0.50, 0.55, 1.0);
const DOT_COL: Color = Color::new(0.75, 0.75, 0.80, 1.0);
const WIN_COL: Color = Color::new(0.15, 0.85, 0.30, 0.9);
const DRAW_COL: Color = Color::new(0.90, 0.85, 0.15, 0.9);
const LOSS_COL: Color = Color::new(0.90, 0.25, 0.20, 0.9);

fn dot_pos(row: usize, col: usize) -> (f32, f32) {
    (
        BOARD_OFF_X + col as f32 * DOT_SPACING,
        BOARD_OFF_Y + row as f32 * DOT_SPACING,
    )
}

fn line_endpoints(idx: usize) -> ((f32, f32), (f32, f32)) {
    if idx < 20 {
        let row = idx / COLS;
        let col = idx % COLS;
        (dot_pos(row, col), dot_pos(row, col + 1))
    } else {
        let vi = idx - 20;
        let row = vi / DOT_COLS;
        let col = vi % DOT_COLS;
        (dot_pos(row, col), dot_pos(row + 1, col))
    }
}

fn line_midpoint(idx: usize) -> (f32, f32) {
    let (a, b) = line_endpoints(idx);
    ((a.0 + b.0) / 2.0, (a.1 + b.1) / 2.0)
}

fn point_to_line_dist(px: f32, py: f32, x1: f32, y1: f32, x2: f32, y2: f32) -> f32 {
    let dx = x2 - x1;
    let dy = y2 - y1;
    let len_sq = dx * dx + dy * dy;
    if len_sq < 0.001 {
        return ((px - x1).powi(2) + (py - y1).powi(2)).sqrt();
    }
    let t = ((px - x1) * dx + (py - y1) * dy) / len_sq;
    let t = t.clamp(0.0, 1.0);
    let proj_x = x1 + t * dx;
    let proj_y = y1 + t * dy;
    ((px - proj_x).powi(2) + (py - proj_y).powi(2)).sqrt()
}

struct App {
    game: DotsBoxes,
    explorer: Explorer,
    hover_line: Option<usize>,
    game_count: u32,
    last_save_time: f64,
    start_time: f64,
    status_msg: String,
    status_timer: f64,
    steps_per_frame: u64,
}

impl App {
    fn new() -> Self {
        let mut explorer = Explorer::new();
        let loaded = explorer.table.load();
        let status = if loaded > 0 {
            format!("Loaded {} positions from disk", format_num(loaded as u64))
        } else {
            "Starting exploration — your algorithm, no pruning!".to_string()
        };

        let engine = DotsBoxes::new();
        explorer.start(engine.clone());

        App {
            game: DotsBoxes::new(),
            explorer,
            hover_line: None,
            game_count: 1,
            last_save_time: get_time(),
            start_time: get_time(),
            status_msg: status,
            status_timer: 4.0,
            steps_per_frame: 50_000,
        }
    }

    fn update(&mut self) {
        let dt = get_frame_time() as f64;

        // Always exploring in background
        if self.explorer.is_exploring {
            self.explorer.explore_batch(self.steps_per_frame);
        }

        // Check if solved
        if self.explorer.exploration_complete && self.status_timer <= 0.0 {
            self.status_msg = "FULLY SOLVED! Your algorithm did it!".to_string();
            self.status_timer = 999.0;
        }

        // Auto-save
        let now = get_time();
        if now - self.last_save_time >= AUTO_SAVE_SECS && self.explorer.table.len() > 0 {
            self.explorer.table.save();
            self.status_msg = format!(
                "Auto-saved {} positions",
                format_num(self.explorer.table.len() as u64)
            );
            self.status_timer = 2.0;
            self.last_save_time = now;
        }

        if self.status_timer > 0.0 { self.status_timer -= dt; }

        // Keyboard
        if is_key_pressed(KeyCode::R) { self.reset_game(); }
        if is_key_pressed(KeyCode::U) { self.game.unmake_move(); }
        if is_key_pressed(KeyCode::S) {
            self.explorer.table.save();
            self.status_msg = format!("Saved {}", format_num(self.explorer.table.len() as u64));
            self.status_timer = 3.0;
        }
        if is_key_pressed(KeyCode::RightBracket) {
            self.steps_per_frame = (self.steps_per_frame * 2).min(1_000_000);
        }
        if is_key_pressed(KeyCode::LeftBracket) {
            self.steps_per_frame = (self.steps_per_frame / 2).max(1_000);
        }

        // Mouse hover
        let (mx, my) = mouse_position();
        self.hover_line = None;
        if !self.game.is_game_over() {
            let mut best_dist = LINE_HIT_DIST;
            for idx in 0..TOTAL_LINES {
                if self.game.is_line_drawn(idx) { continue; }
                let ((x1, y1), (x2, y2)) = line_endpoints(idx);
                let d = point_to_line_dist(mx, my, x1, y1, x2, y2);
                if d < best_dist {
                    best_dist = d;
                    self.hover_line = Some(idx);
                }
            }
        }

        // Mouse click
        if is_mouse_button_pressed(MouseButton::Left) {
            if !self.game.is_game_over() {
                if let Some(line_idx) = self.hover_line {
                    self.game.make_move(line_idx);
                }
            }
            self.handle_button_click(mx, my);
        }
    }

    fn handle_button_click(&mut self, mx: f32, my: f32) {
        let bw = 200.0f32;
        let bh = 30.0f32;
        let mut by = 530.0f32;
        let bx = PANEL_X;

        if mx >= bx && mx < bx + bw && my >= by && my < by + bh { self.reset_game(); return; }
        by += 35.0;
        if mx >= bx && mx < bx + bw && my >= by && my < by + bh {
            self.explorer.table.save();
            self.status_msg = format!("Saved {}", format_num(self.explorer.table.len() as u64));
            self.status_timer = 3.0;
            return;
        }
        by += 35.0;
        if mx >= bx && mx < bx + bw && my >= by && my < by + bh {
            self.explorer.table.clear();
            self.explorer.games_completed = 0;
            self.explorer.positions_explored = 0;
            self.explorer.positions_cached = 0;
            self.explorer.start(self.game.clone());
            self.status_msg = "Cleared all data, restarting...".to_string();
            self.status_timer = 3.0;
        }
    }

    fn reset_game(&mut self) {
        if self.explorer.table.len() > 0 { self.explorer.table.save(); }
        self.game = DotsBoxes::new();
        self.game_count += 1;
        self.explorer.start(self.game.clone());
    }

    fn draw(&self) {
        clear_background(BG);
        self.draw_box_fills();
        self.draw_lines();
        self.draw_destiny_indicators();
        self.draw_dots();
        self.draw_scores();
        self.draw_panel();
    }

    fn draw_box_fills(&self) {
        let owners = box_owners_from_history(&self.game.history);
        for r in 0..ROWS {
            for c in 0..COLS {
                let box_idx = r * COLS + c;
                if owners[box_idx] == 0 { continue; }
                let (x, y) = dot_pos(r, c);
                let fill = if owners[box_idx] == 1 { P1_FILL } else { P2_FILL };
                draw_rectangle(x, y, DOT_SPACING, DOT_SPACING, fill);
                let label = if owners[box_idx] == 1 { "B" } else { "R" };
                let col = if owners[box_idx] == 1 { P1_COL } else { P2_COL };
                let dim = measure_text(label, None, 22, 1.0);
                draw_text(label, x + DOT_SPACING/2.0 - dim.width/2.0, y + DOT_SPACING/2.0 + dim.height/2.0, 22.0, Color::new(col.r, col.g, col.b, 0.5));
            }
        }
    }

    fn draw_lines(&self) {
        for idx in 0..TOTAL_LINES {
            let ((x1, y1), (x2, y2)) = line_endpoints(idx);
            if !self.game.is_line_drawn(idx) {
                let col = if !self.game.is_game_over() && self.hover_line == Some(idx) { LINE_HOVER } else { LINE_UNDRAWN };
                draw_line(x1, y1, x2, y2, 2.5, col);
            }
        }
        for &(line_idx, was_p1) in &self.game.history {
            let ((x1, y1), (x2, y2)) = line_endpoints(line_idx);
            draw_line(x1, y1, x2, y2, LINE_THICKNESS, if was_p1 { P1_COL } else { P2_COL });
        }
    }

    fn draw_destiny_indicators(&self) {
        if self.game.is_game_over() { return; }
        let is_p1 = self.game.p1_turn;

        for idx in 0..TOTAL_LINES {
            if self.game.is_line_drawn(idx) { continue; }
            if let Some(diff) = self.explorer.get_move_destiny(&self.game, idx) {
                let col = if is_p1 {
                    if diff > 0 { WIN_COL } else if diff == 0 { DRAW_COL } else { LOSS_COL }
                } else {
                    if diff < 0 { WIN_COL } else if diff == 0 { DRAW_COL } else { LOSS_COL }
                };

                let (mx, my) = line_midpoint(idx);
                draw_circle(mx, my, 11.0, col);
                let label = if diff > 0 { format!("+{}", diff) } else { format!("{}", diff) };
                let dim = measure_text(&label, None, 10, 1.0);
                draw_text(&label, mx - dim.width/2.0, my + 3.5, 10.0, Color::new(0.0, 0.0, 0.0, 0.9));
            }
        }
    }

    fn draw_dots(&self) {
        for r in 0..DOT_ROWS {
            for c in 0..DOT_COLS {
                let (x, y) = dot_pos(r, c);
                draw_circle(x, y, DOT_RADIUS, DOT_COL);
            }
        }
    }

    fn draw_scores(&self) {
        let y = BOARD_OFF_Y + (DOT_ROWS - 1) as f32 * DOT_SPACING + 35.0;
        draw_text(&format!("Blue: {}", self.game.p1_score), BOARD_OFF_X, y, 22.0, P1_COL);
        draw_text(&format!("Red: {}", self.game.p2_score), BOARD_OFF_X + 160.0, y, 22.0, P2_COL);
        if self.game.is_game_over() {
            let col = if self.game.p1_score > self.game.p2_score { P1_COL }
                else if self.game.p2_score > self.game.p1_score { P2_COL }
                else { DRAW_COL };
            draw_text(self.game.result_name(), BOARD_OFF_X + 100.0, y + 30.0, 26.0, col);
        }
    }

    fn draw_panel(&self) {
        let x = PANEL_X;
        let mut y = BOARD_OFF_Y;

        draw_text("DOTS & BOXES 5×5", x, y + 20.0, 20.0, Color::new(0.9, 0.85, 0.7, 1.0));
        y += 24.0;
        draw_text("DESTINY EXPLORER", x, y, 20.0, Color::new(0.9, 0.85, 0.7, 1.0));

        y += 28.0;
        let turn = if self.game.is_game_over() { "Game Over" }
            else if self.game.p1_turn { "Blue's turn" }
            else { "Red's turn" };
        let turn_col = if self.game.is_game_over() { WHITE }
            else if self.game.p1_turn { P1_COL }
            else { P2_COL };
        draw_text(turn, x, y, 18.0, turn_col);

        y += 20.0;
        draw_text(&format!("Game #{}", self.game_count), x, y, 13.0, GRAY);

        // Explorer stats
        y += 28.0;
        draw_text("--- Explorer (your algorithm) ---", x, y, 14.0, Color::new(0.5, 0.85, 0.5, 1.0));

        y += 20.0;
        let (status_text, status_col) = if self.explorer.exploration_complete {
            ("SOLVED!", Color::new(1.0, 0.85, 0.0, 1.0))
        } else if self.explorer.is_exploring {
            ("COMPUTING...", Color::new(0.2, 1.0, 0.2, 1.0))
        } else {
            ("STOPPED", Color::new(0.5, 0.8, 1.0, 1.0))
        };
        draw_text(&format!("Status: {}", status_text), x, y, 13.0, status_col);

        let elapsed = get_time() - self.start_time;
        let rate = if elapsed > 0.0 { self.explorer.positions_explored as f64 / elapsed } else { 0.0 };

        y += 17.0; draw_text(&format!("Speed: {}/sec", format_num(rate as u64)), x, y, 13.0, GRAY);
        y += 17.0; draw_text(&format!("Games: {}", format_num(self.explorer.games_completed)), x, y, 13.0, GRAY);
        y += 17.0; draw_text(&format!("Explored: {}", format_num(self.explorer.positions_explored)), x, y, 13.0, GRAY);
        y += 17.0; draw_text(&format!("Duplicates: {}", format_num(self.explorer.positions_cached)), x, y, 13.0, GRAY);

        let hit_rate = if self.explorer.positions_explored > 0 {
            (self.explorer.positions_cached as f64 / self.explorer.positions_explored as f64) * 100.0
        } else { 0.0 };
        y += 17.0; draw_text(&format!("Hit rate: {:.1}%", hit_rate), x, y, 13.0, GRAY);
        y += 17.0; draw_text(&format!("Stored: {}", format_num(self.explorer.table.len() as u64)), x, y, 13.0, GRAY);
        y += 17.0; draw_text(&format!("Depth: {}", self.explorer.stack_depth()), x, y, 13.0, GRAY);
        y += 17.0; draw_text(&format!("Steps/frame: {}", format_num(self.steps_per_frame)), x, y, 13.0, GRAY);
        y += 17.0; draw_text(&format!("Disk: {}", self.explorer.table.file_size_string()), x, y, 13.0, GRAY);
        y += 17.0; draw_text("Pruning: NONE (pure exhaustive)", x, y, 13.0, Color::new(0.9, 0.7, 0.2, 1.0));

        // Status
        if self.status_timer > 0.0 {
            y += 20.0;
            let alpha = self.status_timer.min(1.0) as f32;
            draw_text(&self.status_msg, x, y, 12.0, Color::new(0.3, 1.0, 0.5, alpha));
        }

        // Destiny legend
        y += 25.0;
        draw_text("--- Destiny ---", x, y, 14.0, Color::new(0.5, 0.85, 0.5, 1.0));
        y += 20.0;
        draw_circle(x + 7.0, y - 3.0, 7.0, WIN_COL);
        draw_text("Win", x + 20.0, y + 2.0, 12.0, GRAY);
        draw_circle(x + 70.0, y - 3.0, 7.0, DRAW_COL);
        draw_text("Draw", x + 83.0, y + 2.0, 12.0, GRAY);
        draw_circle(x + 140.0, y - 3.0, 7.0, LOSS_COL);
        draw_text("Loss", x + 153.0, y + 2.0, 12.0, GRAY);
        y += 16.0;
        draw_text("? = not yet computed", x, y, 11.0, Color::new(0.4, 0.4, 0.45, 1.0));

        // Buttons
        let mut by = 530.0f32;
        self.draw_btn(x, by, "[R] Reset");
        by += 35.0;
        self.draw_btn(x, by, "[S] Save to Disk");
        by += 35.0;
        self.draw_btn(x, by, "Clear All Data");

        by += 40.0;
        draw_text("[U] Undo  [ ] Speed -/+", x, by, 12.0, Color::new(0.4, 0.4, 0.45, 1.0));
    }

    fn draw_btn(&self, x: f32, y: f32, text: &str) {
        draw_rectangle(x, y, 200.0, 28.0, Color::new(0.22, 0.22, 0.28, 1.0));
        draw_rectangle_lines(x, y, 200.0, 28.0, 1.0, Color::new(0.45, 0.45, 0.55, 1.0));
        draw_text(text, x + 8.0, y + 19.0, 14.0, WHITE);
    }
}

fn format_num(n: u64) -> String {
    if n < 1_000 { format!("{}", n) }
    else if n < 1_000_000 { format!("{:.1}K", n as f64 / 1_000.0) }
    else if n < 1_000_000_000 { format!("{:.2}M", n as f64 / 1_000_000.0) }
    else { format!("{:.2}B", n as f64 / 1_000_000_000.0) }
}

fn window_conf() -> Conf {
    Conf {
        window_title: "Dots & Boxes 5x5 — Pure Destiny Explorer".to_owned(),
        window_width: 1000,
        window_height: 640,
        window_resizable: false,
        ..Default::default()
    }
}

#[macroquad::main(window_conf)]
async fn main() {
    let mut app = App::new();
    loop {
        app.update();
        app.draw();
        next_frame().await;
    }
}
