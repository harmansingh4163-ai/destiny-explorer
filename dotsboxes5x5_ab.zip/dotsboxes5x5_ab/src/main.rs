use macroquad::prelude::*;
use std::collections::HashMap;

// =====================================================
// DOTS AND BOXES ENGINE (5x5 dots = 4x4 boxes)
// =====================================================

const TOTAL_LINES: usize = 40;
const TOTAL_BOXES: usize = 16;
const ROWS: usize = 4;
const COLS: usize = 4;
const DOT_ROWS: usize = 5;
const DOT_COLS: usize = 5;

fn box_sides(r: usize, c: usize) -> [usize; 4] {
    [
        r * COLS + c,
        (r + 1) * COLS + c,
        20 + r * DOT_COLS + c,
        20 + r * DOT_COLS + (c + 1),
    ]
}

fn boxes_completed_by(lines: u64, line_idx: usize) -> u8 {
    let new_lines = lines | (1u64 << line_idx);
    let mut count = 0u8;
    for r in 0..ROWS {
        for c in 0..COLS {
            let sides = box_sides(r, c);
            let was = sides.iter().all(|&s| lines & (1u64 << s) != 0);
            let now = sides.iter().all(|&s| new_lines & (1u64 << s) != 0);
            if !was && now {
                count += 1;
            }
        }
    }
    count
}

fn box_owners_from_history(history: &[(usize, bool)]) -> [u8; TOTAL_BOXES] {
    let mut owners = [0u8; TOTAL_BOXES];
    let mut lines = 0u64;
    for &(line_idx, is_p1) in history {
        let new_lines = lines | (1u64 << line_idx);
        for r in 0..ROWS {
            for c in 0..COLS {
                let box_idx = r * COLS + c;
                if owners[box_idx] != 0 {
                    continue;
                }
                let sides = box_sides(r, c);
                let was = sides.iter().all(|&s| lines & (1u64 << s) != 0);
                let now = sides.iter().all(|&s| new_lines & (1u64 << s) != 0);
                if !was && now {
                    owners[box_idx] = if is_p1 { 1 } else { 2 };
                }
            }
        }
        lines = new_lines;
    }
    owners
}

#[derive(Clone)]
struct DotsBoxes {
    lines: u64,
    p1_score: u8,
    p2_score: u8,
    p1_turn: bool,
    history: Vec<(usize, bool)>,
}

impl DotsBoxes {
    fn new() -> Self {
        DotsBoxes {
            lines: 0,
            p1_score: 0,
            p2_score: 0,
            p1_turn: true,
            history: Vec::with_capacity(40),
        }
    }

    fn is_line_drawn(&self, idx: usize) -> bool {
        self.lines & (1u64 << idx) != 0
    }

    /// Get available lines sorted by smart priority:
    /// 1. Lines that complete a box (immediate score + extra turn)
    /// 2. Safe lines (don't create 3-sided boxes for opponent)
    /// 3. Dangerous lines (give opponent a capture opportunity)
    fn available_lines_ordered(&self) -> Vec<usize> {
        let mut captures = Vec::new();
        let mut safe = Vec::new();
        let mut dangerous = Vec::new();

        for idx in 0..TOTAL_LINES {
            if self.is_line_drawn(idx) {
                continue;
            }
            let completed = boxes_completed_by(self.lines, idx);
            if completed > 0 {
                captures.push(idx);
            } else {
                let new_lines = self.lines | (1u64 << idx);
                let mut gives_capture = false;
                for r in 0..ROWS {
                    for c in 0..COLS {
                        let sides = box_sides(r, c);
                        let old_count = sides.iter().filter(|&&s| self.lines & (1u64 << s) != 0).count();
                        let new_count = sides.iter().filter(|&&s| new_lines & (1u64 << s) != 0).count();
                        if old_count < 3 && new_count == 3 {
                            gives_capture = true;
                            break;
                        }
                    }
                    if gives_capture {
                        break;
                    }
                }
                if gives_capture {
                    dangerous.push(idx);
                } else {
                    safe.push(idx);
                }
            }
        }

        let mut result = Vec::with_capacity(captures.len() + safe.len() + dangerous.len());
        result.extend(captures);
        result.extend(safe);
        result.extend(dangerous);
        result
    }

    fn is_game_over(&self) -> bool {
        self.p1_score + self.p2_score == TOTAL_BOXES as u8
    }

    fn make_move(&mut self, line_idx: usize) {
        let captured = boxes_completed_by(self.lines, line_idx);
        self.history.push((line_idx, self.p1_turn));
        self.lines |= 1u64 << line_idx;
        if captured > 0 {
            if self.p1_turn {
                self.p1_score += captured;
            } else {
                self.p2_score += captured;
            }
            // Same player goes again!
        } else {
            self.p1_turn = !self.p1_turn;
        }
    }

    fn unmake_move(&mut self) {
        if let Some((line_idx, was_p1)) = self.history.pop() {
            let captured = boxes_completed_by(
                self.lines & !(1u64 << line_idx),
                line_idx,
            );
            self.lines &= !(1u64 << line_idx);
            if captured > 0 {
                if was_p1 {
                    self.p1_score -= captured;
                } else {
                    self.p2_score -= captured;
                }
            }
            self.p1_turn = was_p1;
        }
    }

    fn hash(&self) -> u64 {
        self.lines
            | ((self.p1_turn as u64) << 40)
            | ((self.p1_score as u64) << 41)
            | ((self.p2_score as u64) << 46)
    }

    fn result_name(&self) -> &str {
        if self.p1_score > self.p2_score { "Blue Wins" }
        else if self.p2_score > self.p1_score { "Red Wins" }
        else { "Draw" }
    }
}

// =====================================================
// SOLVER — Alpha-Beta + Transposition Table
// =====================================================

struct Solver {
    table: HashMap<u64, i8>,
    positions_explored: u64,
    positions_cached: u64,
}

impl Solver {
    fn new() -> Self {
        Solver {
            table: HashMap::with_capacity(50_000_000),
            positions_explored: 0,
            positions_cached: 0,
        }
    }

    fn solve(&mut self, game: &mut DotsBoxes, mut alpha: i8, mut beta: i8) -> i8 {
        self.positions_explored += 1;

        // Duplicate elimination — your shortcut
        let hash = game.hash();
        if let Some(&cached) = self.table.get(&hash) {
            self.positions_cached += 1;
            return cached;
        }

        // Game over — record final score difference
        if game.is_game_over() {
            let diff = game.p1_score as i8 - game.p2_score as i8;
            self.table.insert(hash, diff);
            return diff;
        }

        let moves = game.available_lines_ordered();
        let is_p1 = game.p1_turn;

        let best;
        if is_p1 {
            // Blue maximizes
            let mut val = i8::MIN;
            for m in moves {
                game.make_move(m);
                let child = self.solve(game, alpha, beta);
                game.unmake_move();
                val = val.max(child);
                alpha = alpha.max(val);
                if alpha >= beta {
                    break; // Red already has a better option elsewhere — skip
                }
            }
            best = val;
        } else {
            // Red minimizes
            let mut val = i8::MAX;
            for m in moves {
                game.make_move(m);
                let child = self.solve(game, alpha, beta);
                game.unmake_move();
                val = val.min(child);
                beta = beta.min(val);
                if alpha >= beta {
                    break; // Blue already has a better option elsewhere — skip
                }
            }
            best = val;
        }

        self.table.insert(hash, best);
        best
    }

    fn get_move_destiny(&self, game: &DotsBoxes, line_idx: usize) -> Option<i8> {
        let mut test = game.clone();
        test.make_move(line_idx);
        self.table.get(&test.hash()).copied()
    }
}

// =====================================================
// GUI
// =====================================================

const DOT_SPACING: f32 = 110.0;
const BOARD_OFF_X: f32 = 60.0;
const BOARD_OFF_Y: f32 = 60.0;
const DOT_RADIUS: f32 = 7.0;
const LINE_THICKNESS: f32 = 5.0;
const LINE_HIT_DIST: f32 = 16.0;
const PANEL_X: f32 = 570.0;

const BG: Color = Color::new(0.10, 0.10, 0.14, 1.0);
const P1_COL: Color = Color::new(0.30, 0.55, 1.0, 1.0);
const P2_COL: Color = Color::new(1.0, 0.40, 0.35, 1.0);
const P1_FILL: Color = Color::new(0.20, 0.35, 0.65, 0.35);
const P2_FILL: Color = Color::new(0.65, 0.25, 0.20, 0.35);
const LINE_UNDRAWN: Color = Color::new(0.25, 0.25, 0.30, 1.0);
const LINE_HOVER: Color = Color::new(0.50, 0.50, 0.55, 1.0);
const DOT_COL: Color = Color::new(0.75, 0.75, 0.80, 1.0);
const WIN_COL: Color = Color::new(0.15, 0.85, 0.30, 0.9);
const DRAW_COL: Color = Color::new(0.90, 0.85, 0.15, 0.9);
const LOSS_COL: Color = Color::new(0.90, 0.25, 0.20, 0.9);

fn dot_pos(row: usize, col: usize) -> (f32, f32) {
    (
        BOARD_OFF_X + col as f32 * DOT_SPACING,
        BOARD_OFF_Y + row as f32 * DOT_SPACING,
    )
}

fn line_endpoints(idx: usize) -> ((f32, f32), (f32, f32)) {
    if idx < 20 {
        let row = idx / COLS;
        let col = idx % COLS;
        (dot_pos(row, col), dot_pos(row, col + 1))
    } else {
        let vi = idx - 20;
        let row = vi / DOT_COLS;
        let col = vi % DOT_COLS;
        (dot_pos(row, col), dot_pos(row + 1, col))
    }
}

fn line_midpoint(idx: usize) -> (f32, f32) {
    let (a, b) = line_endpoints(idx);
    ((a.0 + b.0) / 2.0, (a.1 + b.1) / 2.0)
}

fn point_to_line_dist(px: f32, py: f32, x1: f32, y1: f32, x2: f32, y2: f32) -> f32 {
    let dx = x2 - x1;
    let dy = y2 - y1;
    let len_sq = dx * dx + dy * dy;
    if len_sq < 0.001 {
        return ((px - x1).powi(2) + (py - y1).powi(2)).sqrt();
    }
    let t = ((px - x1) * dx + (py - y1) * dy) / len_sq;
    let t = t.clamp(0.0, 1.0);
    let proj_x = x1 + t * dx;
    let proj_y = y1 + t * dy;
    ((px - proj_x).powi(2) + (py - proj_y).powi(2)).sqrt()
}

struct App {
    game: DotsBoxes,
    solver: Solver,
    hover_line: Option<usize>,
    game_count: u32,
    opening_diff: i8,
    solve_time_secs: f64,
}

impl App {
    fn new() -> Self {
        let mut solver = Solver::new();

        println!("===========================================");
        println!("  Dots & Boxes 5x5 — Alpha-Beta Solver");
        println!("===========================================");
        println!("Solving... (this may take a few minutes)");

        let start = std::time::Instant::now();
        let mut game = DotsBoxes::new();
        let opening_diff = solver.solve(&mut game, i8::MIN, i8::MAX);
        let elapsed = start.elapsed().as_secs_f64();

        println!("SOLVED in {:.1}s!", elapsed);
        println!(
            "Positions explored: {}",
            format_num(solver.positions_explored)
        );
        println!(
            "Duplicates skipped: {}",
            format_num(solver.positions_cached)
        );
        println!(
            "Unique stored: {}",
            format_num(solver.table.len() as u64)
        );
        let hit_rate = if solver.positions_explored > 0 {
            (solver.positions_cached as f64 / solver.positions_explored as f64) * 100.0
        } else { 0.0 };
        println!("Cache hit rate: {:.1}%", hit_rate);
        println!(
            "Opening verdict: {} (diff: {}{}) ",
            if opening_diff > 0 { "Blue wins" }
            else if opening_diff < 0 { "Red wins" }
            else { "Draw" },
            if opening_diff > 0 { "+" } else { "" },
            opening_diff
        );
        println!("===========================================");

        App {
            game: DotsBoxes::new(),
            solver,
            hover_line: None,
            game_count: 1,
            opening_diff,
            solve_time_secs: elapsed,
        }
    }

    fn update(&mut self) {
        let (mx, my) = mouse_position();

        self.hover_line = None;
        if !self.game.is_game_over() {
            let mut best_dist = LINE_HIT_DIST;
            for idx in 0..TOTAL_LINES {
                if self.game.is_line_drawn(idx) {
                    continue;
                }
                let ((x1, y1), (x2, y2)) = line_endpoints(idx);
                let d = point_to_line_dist(mx, my, x1, y1, x2, y2);
                if d < best_dist {
                    best_dist = d;
                    self.hover_line = Some(idx);
                }
            }
        }

        if is_mouse_button_pressed(MouseButton::Left) && !self.game.is_game_over() {
            if let Some(line_idx) = self.hover_line {
                self.game.make_move(line_idx);
            }
        }

        if is_key_pressed(KeyCode::R) {
            self.game = DotsBoxes::new();
            self.game_count += 1;
        }
        if is_key_pressed(KeyCode::U) {
            self.game.unmake_move();
        }
    }

    fn draw(&self) {
        clear_background(BG);
        self.draw_box_fills();
        self.draw_lines();
        self.draw_destiny_indicators();
        self.draw_dots();
        self.draw_scores();
        self.draw_panel();
    }

    fn draw_box_fills(&self) {
        let owners = box_owners_from_history(&self.game.history);
        for r in 0..ROWS {
            for c in 0..COLS {
                let box_idx = r * COLS + c;
                if owners[box_idx] == 0 {
                    continue;
                }
                let (x, y) = dot_pos(r, c);
                let fill = if owners[box_idx] == 1 { P1_FILL } else { P2_FILL };
                draw_rectangle(x, y, DOT_SPACING, DOT_SPACING, fill);
                let label = if owners[box_idx] == 1 { "B" } else { "R" };
                let col = if owners[box_idx] == 1 { P1_COL } else { P2_COL };
                let dim = measure_text(label, None, 22, 1.0);
                draw_text(
                    label,
                    x + DOT_SPACING / 2.0 - dim.width / 2.0,
                    y + DOT_SPACING / 2.0 + dim.height / 2.0,
                    22.0,
                    Color::new(col.r, col.g, col.b, 0.5),
                );
            }
        }
    }

    fn draw_lines(&self) {
        for idx in 0..TOTAL_LINES {
            let ((x1, y1), (x2, y2)) = line_endpoints(idx);
            if !self.game.is_line_drawn(idx) {
                let col = if !self.game.is_game_over() && self.hover_line == Some(idx) {
                    LINE_HOVER
                } else {
                    LINE_UNDRAWN
                };
                draw_line(x1, y1, x2, y2, 2.5, col);
            }
        }
        for &(line_idx, was_p1) in &self.game.history {
            let ((x1, y1), (x2, y2)) = line_endpoints(line_idx);
            draw_line(x1, y1, x2, y2, LINE_THICKNESS, if was_p1 { P1_COL } else { P2_COL });
        }
    }

    fn draw_destiny_indicators(&self) {
        if self.game.is_game_over() {
            return;
        }
        let is_p1 = self.game.p1_turn;

        for idx in 0..TOTAL_LINES {
            if self.game.is_line_drawn(idx) {
                continue;
            }
            if let Some(diff) = self.solver.get_move_destiny(&self.game, idx) {
                let col = if is_p1 {
                    if diff > 0 { WIN_COL } else if diff == 0 { DRAW_COL } else { LOSS_COL }
                } else {
                    if diff < 0 { WIN_COL } else if diff == 0 { DRAW_COL } else { LOSS_COL }
                };

                let (mx, my) = line_midpoint(idx);
                draw_circle(mx, my, 11.0, col);
                let label = if diff > 0 { format!("+{}", diff) } else { format!("{}", diff) };
                let dim = measure_text(&label, None, 10, 1.0);
                draw_text(
                    &label,
                    mx - dim.width / 2.0,
                    my + 3.5,
                    10.0,
                    Color::new(0.0, 0.0, 0.0, 0.9),
                );
            }
        }
    }

    fn draw_dots(&self) {
        for r in 0..DOT_ROWS {
            for c in 0..DOT_COLS {
                let (x, y) = dot_pos(r, c);
                draw_circle(x, y, DOT_RADIUS, DOT_COL);
            }
        }
    }

    fn draw_scores(&self) {
        let y = BOARD_OFF_Y + (DOT_ROWS - 1) as f32 * DOT_SPACING + 35.0;
        draw_text(&format!("Blue: {}", self.game.p1_score), BOARD_OFF_X, y, 22.0, P1_COL);
        draw_text(&format!("Red: {}", self.game.p2_score), BOARD_OFF_X + 160.0, y, 22.0, P2_COL);
        if self.game.is_game_over() {
            let col = if self.game.p1_score > self.game.p2_score { P1_COL }
                else if self.game.p2_score > self.game.p1_score { P2_COL }
                else { DRAW_COL };
            draw_text(self.game.result_name(), BOARD_OFF_X + 100.0, y + 30.0, 26.0, col);
        }
    }

    fn draw_panel(&self) {
        let x = PANEL_X;
        let mut y = BOARD_OFF_Y;

        draw_text("DOTS & BOXES 5×5", x, y + 20.0, 22.0, Color::new(0.9, 0.85, 0.7, 1.0));
        y += 26.0;
        draw_text("ALPHA-BETA SOLVER", x, y, 22.0, Color::new(0.9, 0.85, 0.7, 1.0));

        y += 32.0;
        let turn = if self.game.is_game_over() { "Game Over" }
            else if self.game.p1_turn { "Blue's turn" }
            else { "Red's turn" };
        let turn_col = if self.game.is_game_over() { WHITE }
            else if self.game.p1_turn { P1_COL }
            else { P2_COL };
        draw_text(turn, x, y, 18.0, turn_col);
        y += 20.0;
        draw_text(&format!("Game #{}", self.game_count), x, y, 14.0, GRAY);

        // Stats
        y += 30.0;
        draw_text("--- Solver Stats ---", x, y, 15.0, Color::new(0.5, 0.85, 0.5, 1.0));
        y += 24.0;
        draw_text("Status: SOLVED!", x, y, 15.0, Color::new(1.0, 0.85, 0.0, 1.0));
        y += 20.0;
        draw_text(&format!("Solve time: {:.1}s", self.solve_time_secs), x, y, 14.0, GRAY);
        y += 20.0;
        draw_text(
            &format!("Explored: {}", format_num(self.solver.positions_explored)),
            x, y, 14.0, GRAY,
        );
        y += 20.0;
        draw_text(
            &format!("Duplicates skipped: {}", format_num(self.solver.positions_cached)),
            x, y, 14.0, GRAY,
        );
        y += 20.0;
        draw_text(
            &format!("Unique stored: {}", format_num(self.solver.table.len() as u64)),
            x, y, 14.0, GRAY,
        );
        y += 20.0;
        let hit_rate = if self.solver.positions_explored > 0 {
            (self.solver.positions_cached as f64 / self.solver.positions_explored as f64) * 100.0
        } else { 0.0 };
        draw_text(&format!("Cache hit rate: {:.1}%", hit_rate), x, y, 14.0, GRAY);
        y += 20.0;
        draw_text("Pruning: Alpha-Beta", x, y, 14.0, Color::new(0.5, 0.85, 0.5, 1.0));

        // Verdict
        y += 30.0;
        draw_text("--- Opening Verdict ---", x, y, 15.0, Color::new(0.5, 0.85, 0.5, 1.0));
        y += 24.0;
        let (verdict, vcol) = if self.opening_diff > 0 {
            (format!("Blue wins by {} pts", self.opening_diff), P1_COL)
        } else if self.opening_diff < 0 {
            (format!("Red wins by {} pts", -self.opening_diff), P2_COL)
        } else {
            ("Draw (perfect play)".to_string(), DRAW_COL)
        };
        draw_text(&verdict, x, y, 16.0, vcol);

        // Current position
        if !self.game.is_game_over() {
            let hash = self.game.hash();
            if let Some(&diff) = self.solver.table.get(&hash) {
                y += 24.0;
                let status = if diff > 0 {
                    format!("Optimal: Blue +{}", diff)
                } else if diff < 0 {
                    format!("Optimal: Red +{}", -diff)
                } else {
                    "Optimal: Even".to_string()
                };
                draw_text(&status, x, y, 14.0, GRAY);
            }
        }

        // Legend
        y += 30.0;
        draw_text("--- Destiny Colors ---", x, y, 15.0, Color::new(0.5, 0.85, 0.5, 1.0));
        y += 22.0;
        draw_circle(x + 7.0, y - 3.0, 7.0, WIN_COL);
        draw_text("Win for current player", x + 22.0, y + 2.0, 13.0, GRAY);
        y += 20.0;
        draw_circle(x + 7.0, y - 3.0, 7.0, DRAW_COL);
        draw_text("Draw", x + 22.0, y + 2.0, 13.0, GRAY);
        y += 20.0;
        draw_circle(x + 7.0, y - 3.0, 7.0, LOSS_COL);
        draw_text("Loss for current player", x + 22.0, y + 2.0, 13.0, GRAY);
        y += 18.0;
        draw_text("Number = final score difference", x, y, 11.0, Color::new(0.4, 0.4, 0.45, 1.0));

        // Controls
        y += 28.0;
        draw_text("--- Controls ---", x, y, 15.0, Color::new(0.5, 0.85, 0.5, 1.0));
        y += 22.0;
        draw_text("Click a line to draw it", x, y, 14.0, GRAY);
        y += 18.0;
        draw_text("[R] New game   [U] Undo", x, y, 14.0, GRAY);
    }
}

fn format_num(n: u64) -> String {
    if n < 1_000 { format!("{}", n) }
    else if n < 1_000_000 { format!("{:.1}K", n as f64 / 1_000.0) }
    else if n < 1_000_000_000 { format!("{:.2}M", n as f64 / 1_000_000.0) }
    else { format!("{:.2}B", n as f64 / 1_000_000_000.0) }
}

fn window_conf() -> Conf {
    Conf {
        window_title: "Dots & Boxes 5x5 — Alpha-Beta Solver".to_owned(),
        window_width: 1000,
        window_height: 620,
        window_resizable: false,
        ..Default::default()
    }
}

#[macroquad::main(window_conf)]
async fn main() {
    let mut app = App::new();
    loop {
        app.update();
        app.draw();
        next_frame().await;
    }
}
