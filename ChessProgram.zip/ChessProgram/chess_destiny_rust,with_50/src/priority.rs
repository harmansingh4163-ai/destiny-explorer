use crate::engine::Move;

/// Priority ordering for moves:
/// 1. Piece type: Pawns highest priority
/// 2. File: leftmost from player's perspective
/// 3. Rank: closest to own side first
/// 4. Distance: smallest step first
/// 5. Direction: forward first, then clockwise
/// 6. Promotion: non-promotion first, then Q > R > B > N

#[derive(Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub struct MoveKey {
    pub piece_type: u8,
    pub file_pri: u8,
    pub rank_pri: u8,
    pub distance: u8,
    pub direction: u8,
    pub promo_pri: u8,
}

impl MoveKey {
    pub fn from_move(m: &Move, is_white: bool) -> Self {
        let piece_type = match m.piece.unsigned_abs() {
            1 => 0, // Pawn highest priority
            2 => 1, // Knight
            3 => 2, // Bishop
            4 => 3, // Rook
            5 => 4, // Queen
            6 => 5, // King
            _ => 99,
        };

        // File priority: leftmost from player's view
        let file_pri = if is_white {
            m.from_file
        } else {
            7 - m.from_file
        };

        // Rank priority: own side first
        let rank_pri = if is_white {
            m.from_rank
        } else {
            7 - m.from_rank
        };

        // Distance (Chebyshev)
        let df = (m.to_file as i8 - m.from_file as i8).unsigned_abs();
        let dr = (m.to_rank as i8 - m.from_rank as i8).unsigned_abs();
        let distance = df.max(dr);

        // Direction from player's perspective
        let raw_df = m.to_file as i8 - m.from_file as i8;
        let raw_dr = m.to_rank as i8 - m.from_rank as i8;
        let (fwd, rgt) = if is_white {
            (raw_dr, raw_df)
        } else {
            (-raw_dr, -raw_df)
        };
        let nf = fwd.signum();
        let nr = rgt.signum();
        let direction = match (nf, nr) {
            (1, 0) => 0,   // Forward
            (1, 1) => 1,   // Forward-Right
            (0, 1) => 2,   // Right
            (-1, 1) => 3,  // Back-Right
            (-1, 0) => 4,  // Back
            (-1, -1) => 5, // Back-Left
            (0, -1) => 6,  // Left
            (1, -1) => 7,  // Forward-Left
            _ => 8,
        };

        // Promotion priority
        let promo_pri = if m.promotion == 0 {
            0
        } else {
            match m.promotion.unsigned_abs() {
                5 => 1, // Queen
                4 => 2, // Rook
                3 => 3, // Bishop
                2 => 4, // Knight
                _ => 5,
            }
        };

        MoveKey {
            piece_type,
            file_pri,
            rank_pri,
            distance,
            direction,
            promo_pri,
        }
    }
}

/// Sort moves by priority. Returns a new sorted Vec.
pub fn sort_moves(moves: &mut Vec<Move>, is_white: bool) {
    moves.sort_by(|a, b| {
        let ka = MoveKey::from_move(a, is_white);
        let kb = MoveKey::from_move(b, is_white);
        ka.cmp(&kb)
    });
}
