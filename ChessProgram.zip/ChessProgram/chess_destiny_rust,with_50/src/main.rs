mod engine;
mod explorer;
mod priority;
mod storage;
mod zobrist;

use engine::{ChessEngine, GameResult, EMPTY};
use explorer::DestinyExplorer;
use macroquad::prelude::*;

const SAVE_PATH: &str = "destiny_table.bin";
const SQUARE: f32 = 70.0;
const BOARD_X: f32 = 40.0;
const BOARD_Y: f32 = 40.0;
const BOARD_SIZE: f32 = SQUARE * 8.0;
const PANEL_X: f32 = 640.0;
const STEPS_PER_FRAME_DEFAULT: u64 = 5_000;
const AUTO_SAVE_SECS: f64 = 30.0;

// Colors
const COL_LIGHT: Color = Color::new(0.94, 0.85, 0.71, 1.0);
const COL_DARK: Color = Color::new(0.71, 0.53, 0.39, 1.0);
const COL_SELECT: Color = Color::new(0.4, 0.7, 0.4, 0.6);
const COL_LEGAL: Color = Color::new(0.3, 0.6, 0.9, 0.5);
const COL_WIN: Color = Color::new(0.2, 0.8, 0.2, 0.6);
const COL_DRAW: Color = Color::new(0.8, 0.8, 0.2, 0.6);
const COL_LOSS: Color = Color::new(0.8, 0.2, 0.2, 0.6);
const COL_UNKNOWN: Color = Color::new(0.5, 0.5, 0.5, 0.4);
const COL_LAST: Color = Color::new(0.9, 0.9, 0.3, 0.3);
const COL_CHECK: Color = Color::new(0.9, 0.2, 0.2, 0.4);
const COL_BG: Color = Color::new(0.15, 0.15, 0.20, 1.0);
const COL_BTN: Color = Color::new(0.25, 0.25, 0.30, 1.0);
const COL_BTN_BORDER: Color = Color::new(0.5, 0.5, 0.6, 1.0);

fn piece_letter(p: i8) -> &'static str {
    match p {
        6 => "K",
        5 => "Q",
        4 => "R",
        3 => "B",
        2 => "N",
        1 => "P",
        -6 => "K",
        -5 => "Q",
        -4 => "R",
        -3 => "B",
        -2 => "N",
        -1 => "P",
        _ => "",
    }
}

fn piece_name(p: i8) -> &'static str {
    match p.unsigned_abs() {
        1 => "Pawn",
        2 => "Knight",
        3 => "Bishop",
        4 => "Rook",
        5 => "Queen",
        6 => "King",
        _ => "?",
    }
}

struct App {
    engine: ChessEngine,
    explorer: DestinyExplorer,
    selected: Option<(u8, u8)>, // (file, rank)
    legal_moves: Vec<engine::Move>,
    destiny: Vec<(u8, u8, Option<GameResult>)>,
    last_move: Option<(u8, u8, u8, u8)>, // from_f, from_r, to_f, to_r
    move_log: Vec<String>,
    game_result: GameResult,
    auto_play: bool,
    auto_play_timer: f64,
    steps_per_frame: u64,
    last_save_time: f64,
    status_msg: String,
    status_timer: f64,
    start_time: f64,
    promo_pending: bool,
    promo_moves: Vec<engine::Move>,
}

impl App {
    fn new() -> Self {
        let mut explorer = DestinyExplorer::new(SAVE_PATH);
        let loaded = explorer.load();
        let status = if loaded > 0 {
            format!("Loaded {} positions from disk", loaded)
        } else {
            "Starting fresh exploration...".to_string()
        };

        let engine = ChessEngine::new();
        explorer.start(engine.clone_engine());

        App {
            engine,
            explorer,
            selected: None,
            legal_moves: Vec::new(),
            destiny: Vec::new(),
            last_move: None,
            move_log: Vec::new(),
            game_result: GameResult::Ongoing,
            auto_play: false,
            auto_play_timer: 0.0,
            steps_per_frame: STEPS_PER_FRAME_DEFAULT,
            last_save_time: get_time(),
            status_msg: status,
            status_timer: 4.0,
            start_time: get_time(),
            promo_pending: false,
            promo_moves: Vec::new(),
        }
    }

    fn update(&mut self) {
        let dt = get_frame_time() as f64;

        // Always run exploration
        if self.explorer.is_exploring {
            self.explorer.explore_batch(self.steps_per_frame);
        }

        // Auto-save
        let now = get_time();
        if now - self.last_save_time >= AUTO_SAVE_SECS && self.explorer.table.len() > 0 {
            self.explorer.save();
            self.status_msg = format!(
                "Auto-saved {} positions",
                explorer::format_number(self.explorer.table.len() as u64)
            );
            self.status_timer = 2.0;
            self.last_save_time = now;
        }

        // Status timer
        if self.status_timer > 0.0 {
            self.status_timer -= dt;
        }

        // Auto-play
        if self.auto_play && self.game_result == GameResult::Ongoing {
            self.auto_play_timer += dt;
            if self.auto_play_timer >= 0.3 {
                self.auto_play_timer = 0.0;
                self.auto_play_one_move();
            }
        }

        // Keyboard
        if is_key_pressed(KeyCode::R) {
            self.reset_game();
        }
        if is_key_pressed(KeyCode::A) {
            self.auto_play = !self.auto_play;
            self.auto_play_timer = 0.0;
        }
        if is_key_pressed(KeyCode::S) {
            self.explorer.save();
            self.status_msg = format!(
                "Saved {} positions",
                explorer::format_number(self.explorer.table.len() as u64)
            );
            self.status_timer = 3.0;
        }
        if is_key_pressed(KeyCode::U) {
            self.undo_move();
        }
        if is_key_pressed(KeyCode::RightBracket) {
            self.steps_per_frame = (self.steps_per_frame * 2).min(500_000);
        }
        if is_key_pressed(KeyCode::LeftBracket) {
            self.steps_per_frame = (self.steps_per_frame / 2).max(100);
        }

        // Mouse click
        if is_mouse_button_pressed(MouseButton::Left) {
            let (mx, my) = mouse_position();
            if self.promo_pending {
                self.handle_promo_click(mx, my);
            } else {
                self.handle_board_click(mx, my);
                self.handle_button_click(mx, my);
            }
        }
    }

    fn handle_board_click(&mut self, mx: f32, my: f32) {
        let file = ((mx - BOARD_X) / SQUARE) as i32;
        let visual_rank = ((my - BOARD_Y) / SQUARE) as i32;
        let rank = 7 - visual_rank;

        if file < 0 || file > 7 || rank < 0 || rank > 7 {
            return;
        }
        let f = file as u8;
        let r = rank as u8;

        // Check if clicking a legal move destination
        if self.selected.is_some() {
            // Copy the move out to avoid borrow conflict
            let found = self.legal_moves.iter()
                .find(|m| m.to_file == f && m.to_rank == r)
                .copied();

            if let Some(m) = found {
                // Check promotion
                if m.piece.unsigned_abs() == 1 && (r == 7 || r == 0) {
                    self.promo_moves = self.legal_moves.iter()
                        .filter(|pm| pm.to_file == f && pm.to_rank == r && pm.promotion != 0)
                        .copied()
                        .collect();
                    if !self.promo_moves.is_empty() {
                        self.promo_pending = true;
                        return;
                    }
                }
                self.execute_move(&m);
                return;
            }
        }

        // Select a piece
        let piece = self.engine.board[r as usize][f as usize];
        if piece != EMPTY && ChessEngine::is_own_piece_static(piece, self.engine.white_to_move) {
            self.selected = Some((f, r));
            self.legal_moves = self.engine.generate_legal_moves();
            self.legal_moves.retain(|m| m.from_file == f && m.from_rank == r);
            self.destiny = self.explorer.get_piece_destiny(f, r, &mut self.engine);
        } else {
            self.selected = None;
            self.legal_moves.clear();
            self.destiny.clear();
        }
    }

    fn handle_promo_click(&mut self, mx: f32, my: f32) {
        let cx = BOARD_X + BOARD_SIZE / 2.0;
        let cy = BOARD_Y + BOARD_SIZE / 2.0;
        let bw = 70.0f32;
        let start_x = cx - 2.0 * bw;
        let start_y = cy - 10.0;

        // Find which promo was clicked
        let mut found_idx: Option<usize> = None;
        for (i, _pm) in self.promo_moves.iter().enumerate() {
            let bx = start_x + i as f32 * bw;
            if mx >= bx && mx < bx + bw && my >= start_y && my < start_y + 50.0 {
                found_idx = Some(i);
                break;
            }
        }

        if let Some(idx) = found_idx {
            let m = self.promo_moves[idx];
            self.execute_move(&m);
        }
        self.promo_pending = false;
        self.promo_moves.clear();
    }

    fn handle_button_click(&mut self, mx: f32, my: f32) {
        let bx = PANEL_X;
        let bw = 200.0f32;
        let bh = 32.0f32;
        let mut by = 520.0f32;

        // Reset
        if mx >= bx && mx < bx + bw && my >= by && my < by + bh {
            self.reset_game();
            return;
        }
        by += 40.0;
        // Auto-play
        if mx >= bx && mx < bx + bw && my >= by && my < by + bh {
            self.auto_play = !self.auto_play;
            self.auto_play_timer = 0.0;
            return;
        }
        by += 40.0;
        // Save
        if mx >= bx && mx < bx + bw && my >= by && my < by + bh {
            self.explorer.save();
            self.status_msg = format!(
                "Saved {} positions",
                explorer::format_number(self.explorer.table.len() as u64)
            );
            self.status_timer = 3.0;
            return;
        }
        by += 40.0;
        // Undo
        if mx >= bx && mx < bx + bw && my >= by && my < by + bh {
            self.undo_move();
            return;
        }
        by += 40.0;
        // Clear data
        if mx >= bx && mx < bx + bw && my >= by && my < by + bh {
            self.explorer.table.clear_file();
            self.explorer.table.table.clear();
            self.explorer.games_completed = 0;
            self.explorer.positions_explored = 0;
            self.explorer.positions_cached = 0;
            self.explorer.start(self.engine.clone_engine());
            self.status_msg = "Cleared all data, restarting...".to_string();
            self.status_timer = 3.0;
        }
    }

    fn execute_move(&mut self, m: &engine::Move) {
        let alg = m.to_algebraic();
        let side = if self.engine.white_to_move { "W" } else { "B" };
        self.last_move = Some((m.from_file, m.from_rank, m.to_file, m.to_rank));
        self.engine.make_move(m);
        self.move_log.push(format!("{}: {}", side, alg));
        self.game_result = self.engine.get_result();
        self.selected = None;
        self.legal_moves.clear();
        self.destiny.clear();
    }

    fn auto_play_one_move(&mut self) {
        let mut moves = self.engine.generate_legal_moves();
        if moves.is_empty() {
            self.game_result = self.engine.get_result();
            self.auto_play = false;
            return;
        }
        priority::sort_moves(&mut moves, self.engine.white_to_move);
        let m = moves[0];
        self.execute_move(&m);
    }

    fn undo_move(&mut self) {
        if !self.engine.move_history.is_empty() {
            self.engine.unmake_move();
            self.move_log.pop();
            self.last_move = if let Some(m) = self.engine.move_history.last() {
                Some((m.from_file, m.from_rank, m.to_file, m.to_rank))
            } else {
                None
            };
            self.game_result = self.engine.get_result();
            self.selected = None;
            self.legal_moves.clear();
            self.destiny.clear();
        }
    }

    fn reset_game(&mut self) {
        if self.explorer.table.len() > 0 {
            self.explorer.save();
        }
        self.engine = ChessEngine::new();
        self.selected = None;
        self.legal_moves.clear();
        self.destiny.clear();
        self.auto_play = false;
        self.move_log.clear();
        self.game_result = GameResult::Ongoing;
        self.last_move = None;
        self.promo_pending = false;
        self.explorer.start(self.engine.clone_engine());
    }

    fn draw(&self) {
        clear_background(COL_BG);
        self.draw_board();
        self.draw_pieces();
        self.draw_overlays();
        self.draw_coordinates();
        self.draw_panel();
        self.draw_move_log();
        if self.promo_pending {
            self.draw_promo_dialog();
        }
    }

    fn draw_board(&self) {
        for r in 0..8u8 {
            for f in 0..8u8 {
                let vr = 7 - r;
                let x = BOARD_X + f as f32 * SQUARE;
                let y = BOARD_Y + vr as f32 * SQUARE;
                let col = if (f + r) % 2 == 0 { COL_LIGHT } else { COL_DARK };
                draw_rectangle(x, y, SQUARE, SQUARE, col);
            }
        }

        // Last move highlight
        if let Some((ff, fr, tf, tr)) = self.last_move {
            self.highlight_sq(ff, fr, COL_LAST);
            self.highlight_sq(tf, tr, COL_LAST);
        }

        // Check highlight
        if self.engine.is_in_check(self.engine.white_to_move) {
            let (kf, kr) = self.engine.find_king(self.engine.white_to_move);
            self.highlight_sq(kf, kr, COL_CHECK);
        }
    }

    fn highlight_sq(&self, file: u8, rank: u8, col: Color) {
        let vr = 7 - rank;
        draw_rectangle(
            BOARD_X + file as f32 * SQUARE,
            BOARD_Y + vr as f32 * SQUARE,
            SQUARE,
            SQUARE,
            col,
        );
    }

    fn draw_pieces(&self) {
        for r in 0..8u8 {
            for f in 0..8u8 {
                let p = self.engine.board[r as usize][f as usize];
                if p == EMPTY {
                    continue;
                }
                let vr = 7 - r;
                let cx = BOARD_X + f as f32 * SQUARE + SQUARE / 2.0;
                let cy = BOARD_Y + vr as f32 * SQUARE + SQUARE / 2.0;
                let letter = piece_letter(p);

                // Draw piece background circle
                let (bg_col, text_col) = if p > 0 {
                    (Color::new(1.0, 1.0, 0.95, 0.95), Color::new(0.1, 0.1, 0.15, 1.0))
                } else {
                    (Color::new(0.15, 0.15, 0.2, 0.95), Color::new(0.95, 0.95, 0.9, 1.0))
                };
                draw_circle(cx, cy, SQUARE * 0.38, bg_col);
                // Piece border
                let border_col = if p > 0 {
                    Color::new(0.3, 0.3, 0.3, 0.5)
                } else {
                    Color::new(0.6, 0.6, 0.6, 0.5)
                };
                draw_circle_lines(cx, cy, SQUARE * 0.38, 2.0, border_col);

                // Draw letter
                let font_size = 32.0;
                let text_dim = measure_text(letter, None, font_size as u16, 1.0);
                draw_text(
                    letter,
                    cx - text_dim.width / 2.0,
                    cy + text_dim.height / 2.0 - 2.0,
                    font_size,
                    text_col,
                );
            }
        }
    }

    fn draw_overlays(&self) {
        // Selected square
        if let Some((sf, sr)) = self.selected {
            self.highlight_sq(sf, sr, COL_SELECT);
        }

        // Destiny or legal move highlights
        if !self.destiny.is_empty() {
            let white = self.engine.white_to_move;
            for &(tf, tr, ref dest) in &self.destiny {
                let col = match dest {
                    None => COL_UNKNOWN,
                    Some(GameResult::WhiteWins) => {
                        if white { COL_WIN } else { COL_LOSS }
                    }
                    Some(GameResult::BlackWins) => {
                        if white { COL_LOSS } else { COL_WIN }
                    }
                    Some(GameResult::Draw) => COL_DRAW,
                    Some(GameResult::Ongoing) => COL_UNKNOWN,
                };
                self.highlight_sq(tf, tr, col);

                // Draw result label
                let vr = 7 - tr;
                let label = match dest {
                    Some(GameResult::WhiteWins) => "W",
                    Some(GameResult::BlackWins) => "B",
                    Some(GameResult::Draw) => "D",
                    _ => "?",
                };
                draw_text(
                    label,
                    BOARD_X + tf as f32 * SQUARE + 4.0,
                    BOARD_Y + vr as f32 * SQUARE + 16.0,
                    16.0,
                    WHITE,
                );
            }
        } else if !self.legal_moves.is_empty() {
            for m in &self.legal_moves {
                let vr = 7 - m.to_rank;
                let cx = BOARD_X + m.to_file as f32 * SQUARE + SQUARE / 2.0;
                let cy = BOARD_Y + vr as f32 * SQUARE + SQUARE / 2.0;
                if m.captured != EMPTY || m.is_en_passant {
                    draw_circle_lines(cx, cy, SQUARE * 0.38, 3.0, COL_LEGAL);
                } else {
                    draw_circle(cx, cy, 10.0, COL_LEGAL);
                }
            }
        }
    }

    fn draw_coordinates(&self) {
        let files = ["a", "b", "c", "d", "e", "f", "g", "h"];
        for f in 0..8 {
            let x = BOARD_X + f as f32 * SQUARE + SQUARE / 2.0 - 4.0;
            draw_text(files[f], x, BOARD_Y + BOARD_SIZE + 18.0, 16.0, GRAY);
        }
        for r in 0..8 {
            let vr = 7 - r;
            let y = BOARD_Y + vr as f32 * SQUARE + SQUARE / 2.0 + 5.0;
            draw_text(&format!("{}", r + 1), BOARD_X - 18.0, y, 16.0, GRAY);
        }
    }

    fn draw_panel(&self) {
        let x = PANEL_X;
        let mut y = BOARD_Y;

        // Title
        draw_text("CHESS DESTINY EXPLORER", x, y + 22.0, 22.0, Color::new(0.9, 0.85, 0.7, 1.0));

        // Subtitle
        y += 38.0;
        draw_text("Rust Edition - M4 Powered", x, y, 14.0, Color::new(0.5, 0.5, 0.6, 1.0));

        // Game state
        y += 30.0;
        let turn = if self.game_result != GameResult::Ongoing {
            match self.game_result {
                GameResult::WhiteWins => "White Wins!",
                GameResult::BlackWins => "Black Wins!",
                GameResult::Draw => "Draw!",
                _ => "",
            }
        } else if self.engine.white_to_move {
            "White to move"
        } else {
            "Black to move"
        };
        draw_text(turn, x, y, 18.0, WHITE);

        if self.engine.is_in_check(self.engine.white_to_move) && self.game_result == GameResult::Ongoing {
            y += 20.0;
            draw_text("CHECK!", x, y, 18.0, Color::new(1.0, 0.3, 0.3, 1.0));
        }

        y += 22.0;
        draw_text(
            &format!("Move: {}", self.engine.fullmove_number),
            x, y, 15.0, GRAY,
        );

        // Explorer stats
        y += 30.0;
        draw_text("--- Explorer (always running) ---", x, y, 15.0, Color::new(0.6, 0.8, 0.6, 1.0));

        y += 22.0;
        let status = if self.explorer.is_exploring {
            "COMPUTING..."
        } else if self.explorer.exploration_complete {
            "COMPLETE"
        } else {
            "STOPPED"
        };
        let status_col = if self.explorer.is_exploring {
            Color::new(0.2, 1.0, 0.2, 1.0)
        } else {
            Color::new(0.5, 0.8, 1.0, 1.0)
        };
        draw_text(&format!("Status: {}", status), x, y, 14.0, status_col);

        let elapsed = get_time() - self.start_time;
        let rate = if elapsed > 0.0 {
            self.explorer.positions_explored as f64 / elapsed
        } else {
            0.0
        };

        y += 18.0;
        draw_text(
            &format!("Speed: {}/sec", explorer::format_number(rate as u64)),
            x, y, 14.0, GRAY,
        );
        y += 18.0;
        draw_text(
            &format!(
                "Games: {}",
                explorer::format_number(self.explorer.games_completed)
            ),
            x, y, 14.0, GRAY,
        );
        y += 18.0;
        draw_text(
            &format!(
                "Explored: {}",
                explorer::format_number(self.explorer.positions_explored)
            ),
            x, y, 14.0, GRAY,
        );
        y += 18.0;
        draw_text(
            &format!(
                "Duplicates skipped: {}",
                explorer::format_number(self.explorer.positions_cached)
            ),
            x, y, 14.0, GRAY,
        );
        y += 18.0;
        let hit_rate = if self.explorer.positions_explored > 0 {
            (self.explorer.positions_cached as f64 / self.explorer.positions_explored as f64) * 100.0
        } else {
            0.0
        };
        draw_text(&format!("Cache hit rate: {:.1}%", hit_rate), x, y, 14.0, GRAY);
        y += 18.0;
        draw_text(
            &format!(
                "Stored: {}",
                explorer::format_number(self.explorer.table.len() as u64)
            ),
            x, y, 14.0, GRAY,
        );
        y += 18.0;
        draw_text(
            &format!("Depth: {}", self.explorer.stack_depth()),
            x, y, 14.0, GRAY,
        );
        y += 18.0;
        draw_text(
            &format!("Steps/frame: {}", explorer::format_number(self.steps_per_frame)),
            x, y, 14.0, GRAY,
        );
        y += 18.0;
        draw_text(
            &format!("Disk: {}", self.explorer.table.file_size_string()),
            x, y, 14.0, GRAY,
        );

        // Status message
        if self.status_timer > 0.0 {
            y += 22.0;
            let alpha = self.status_timer.min(1.0) as f32;
            draw_text(
                &self.status_msg,
                x, y, 13.0,
                Color::new(0.3, 1.0, 0.5, alpha),
            );
        }

        // Selected piece destiny
        if let Some((sf, sr)) = self.selected {
            if !self.destiny.is_empty() {
                y += 28.0;
                let p = self.engine.board[sr as usize][sf as usize];
                let name = piece_name(p);
                let files = ["a", "b", "c", "d", "e", "f", "g", "h"];
                draw_text(
                    &format!("{} on {}{}:", name, files[sf as usize], sr + 1),
                    x, y, 15.0, WHITE,
                );
                for &(tf, tr, ref dest) in &self.destiny {
                    y += 16.0;
                    if y > 750.0 {
                        break;
                    }
                    let result_str = match dest {
                        Some(r) => match r {
                            GameResult::WhiteWins => "White Wins",
                            GameResult::BlackWins => "Black Wins",
                            GameResult::Draw => "Draw",
                            _ => "?",
                        },
                        None => "Unknown",
                    };
                    let col = match dest {
                        Some(GameResult::WhiteWins) => {
                            if self.engine.white_to_move {
                                Color::new(0.4, 1.0, 0.4, 1.0)
                            } else {
                                Color::new(1.0, 0.4, 0.4, 1.0)
                            }
                        }
                        Some(GameResult::BlackWins) => {
                            if self.engine.white_to_move {
                                Color::new(1.0, 0.4, 0.4, 1.0)
                            } else {
                                Color::new(0.4, 1.0, 0.4, 1.0)
                            }
                        }
                        Some(GameResult::Draw) => Color::new(1.0, 1.0, 0.4, 1.0),
                        _ => GRAY,
                    };
                    draw_text(
                        &format!("  -> {}{}: {}", files[tf as usize], tr + 1, result_str),
                        x, y, 13.0, col,
                    );
                }
            }
        }

        // Buttons
        let mut by = 520.0f32;
        self.draw_button(x, by, "[R] Reset");
        by += 40.0;
        self.draw_button(
            x,
            by,
            &format!("[A] Auto-Play: {}", if self.auto_play { "ON" } else { "OFF" }),
        );
        by += 40.0;
        self.draw_button(x, by, "[S] Save to Disk");
        by += 40.0;
        self.draw_button(x, by, "[U] Undo");
        by += 40.0;
        self.draw_button(x, by, "Clear All Data");

        by += 45.0;
        draw_text("[ ] = Speed -/+", x, by, 13.0, Color::new(0.5, 0.5, 0.5, 1.0));
        by += 16.0;
        draw_text(
            "Click any piece to see its destiny",
            x, by, 13.0,
            Color::new(0.5, 0.5, 0.5, 1.0),
        );
    }

    fn draw_button(&self, x: f32, y: f32, text: &str) {
        let w = 200.0f32;
        let h = 32.0f32;
        draw_rectangle(x, y, w, h, COL_BTN);
        draw_rectangle_lines(x, y, w, h, 1.0, COL_BTN_BORDER);
        draw_text(text, x + 10.0, y + 22.0, 15.0, WHITE);
    }

    fn draw_move_log(&self) {
        let x = BOARD_X;
        let mut y = BOARD_Y + BOARD_SIZE + 35.0;
        draw_text("Move Log:", x, y, 14.0, GRAY);

        let start = if self.move_log.len() > 14 {
            self.move_log.len() - 14
        } else {
            0
        };
        let mut lx = x;
        y += 18.0;
        for i in start..self.move_log.len() {
            draw_text(&self.move_log[i], lx, y, 13.0, Color::new(0.5, 0.5, 0.5, 1.0));
            lx += 75.0;
            if lx > PANEL_X - 40.0 {
                lx = x;
                y += 16.0;
            }
        }
    }

    fn draw_promo_dialog(&self) {
        // Overlay
        draw_rectangle(0.0, 0.0, screen_width(), screen_height(), Color::new(0.0, 0.0, 0.0, 0.5));

        let cx = BOARD_X + BOARD_SIZE / 2.0;
        let cy = BOARD_Y + BOARD_SIZE / 2.0;
        let bw = 70.0f32;

        // Background
        draw_rectangle(cx - 150.0, cy - 55.0, 300.0, 110.0, Color::new(0.2, 0.2, 0.25, 1.0));
        draw_rectangle_lines(cx - 150.0, cy - 55.0, 300.0, 110.0, 2.0, COL_BTN_BORDER);
        draw_text("Promote to:", cx - 55.0, cy - 18.0, 18.0, WHITE);

        let start_x = cx - 2.0 * bw;
        let by = cy - 10.0;
        let promos = ["Q", "R", "B", "N"];
        for (i, label) in promos.iter().enumerate() {
            let bx = start_x + i as f32 * bw;
            draw_rectangle(bx, by, bw - 8.0, 50.0, Color::new(0.3, 0.3, 0.35, 1.0));
            draw_rectangle_lines(bx, by, bw - 8.0, 50.0, 1.0, COL_BTN_BORDER);
            let tdim = measure_text(label, None, 30, 1.0);
            draw_text(
                label,
                bx + (bw - 8.0) / 2.0 - tdim.width / 2.0,
                by + 35.0,
                30.0,
                WHITE,
            );
        }
    }
}

fn window_conf() -> Conf {
    Conf {
        window_title: "Chess Destiny Explorer".to_owned(),
        window_width: 1280,
        window_height: 800,
        window_resizable: false,
        ..Default::default()
    }
}

#[macroquad::main(window_conf)]
async fn main() {
    let mut app = App::new();

    loop {
        app.update();
        app.draw();
        next_frame().await;
    }
}
