use std::collections::HashMap;
use std::fs::File;
use std::io::{BufReader, BufWriter, Read, Write};
use std::path::Path;

use crate::engine::GameResult;

/// Disk-backed transposition table.
/// Binary format: [count:u64] then per entry [hash:u64][result:u8]
/// 9 bytes per entry. 10 million entries ~ 90 MB on disk.

pub struct TranspositionTable {
    pub table: HashMap<u64, GameResult>,
    file_path: String,
}

impl TranspositionTable {
    pub fn new(file_path: &str) -> Self {
        TranspositionTable {
            table: HashMap::with_capacity(1_000_000),
            file_path: file_path.to_string(),
        }
    }

    #[inline]
    pub fn get(&self, hash: u64) -> Option<GameResult> {
        self.table.get(&hash).copied()
    }

    #[inline]
    pub fn insert(&mut self, hash: u64, result: GameResult) {
        self.table.insert(hash, result);
    }

    #[inline]
    pub fn contains(&self, hash: u64) -> bool {
        self.table.contains_key(&hash)
    }

    #[inline]
    pub fn len(&self) -> usize {
        self.table.len()
    }

    pub fn save(&self) -> bool {
        let file = match File::create(&self.file_path) {
            Ok(f) => f,
            Err(_) => return false,
        };
        let mut w = BufWriter::with_capacity(1024 * 1024, file);
        let count = self.table.len() as u64;
        if w.write_all(&count.to_le_bytes()).is_err() {
            return false;
        }
        for (&hash, &result) in &self.table {
            if w.write_all(&hash.to_le_bytes()).is_err() {
                return false;
            }
            if w.write_all(&[result.to_u8()]).is_err() {
                return false;
            }
        }
        w.flush().is_ok()
    }

    pub fn load(&mut self) -> usize {
        let path = Path::new(&self.file_path);
        if !path.exists() {
            return 0;
        }
        let file = match File::open(path) {
            Ok(f) => f,
            Err(_) => return 0,
        };
        let mut r = BufReader::with_capacity(1024 * 1024, file);
        let mut buf8 = [0u8; 8];
        let mut buf1 = [0u8; 1];
        if r.read_exact(&mut buf8).is_err() {
            return 0;
        }
        let count = u64::from_le_bytes(buf8) as usize;
        self.table.reserve(count);
        for _ in 0..count {
            if r.read_exact(&mut buf8).is_err() {
                break;
            }
            if r.read_exact(&mut buf1).is_err() {
                break;
            }
            self.table
                .insert(u64::from_le_bytes(buf8), GameResult::from_u8(buf1[0]));
        }
        self.table.len()
    }

    pub fn file_size_string(&self) -> String {
        let path = Path::new(&self.file_path);
        if !path.exists() {
            return "No save".to_string();
        }
        match std::fs::metadata(path) {
            Ok(m) => {
                let s = m.len();
                if s < 1024 {
                    format!("{} B", s)
                } else if s < 1_048_576 {
                    format!("{:.1} KB", s as f64 / 1024.0)
                } else if s < 1_073_741_824 {
                    format!("{:.1} MB", s as f64 / 1_048_576.0)
                } else {
                    format!("{:.2} GB", s as f64 / 1_073_741_824.0)
                }
            }
            Err(_) => "Error".to_string(),
        }
    }

    pub fn clear_file(&self) {
        let path = Path::new(&self.file_path);
        if path.exists() {
            let _ = std::fs::remove_file(path);
        }
    }
}
