# Chess Destiny Explorer (Rust + GUI)
# Contact harman.singh4163@icloud.com
A visual chess destiny calculator. Exhaustively explores every possible chess game from the opening position, eliminates duplicate board states, stores every result to disk, and shows you the destiny of every piece — click any piece to see if moving it leads to a win, draw, or loss.

## Setup (Mac Mini M4)

### 1. Install Rust (one-time, takes ~1 minute)
Open Terminal and paste:
```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
```
Press `1` for default install. Close Terminal, reopen it.

### 2. Build & Run
```bash
cd ~/Downloads
unzip chess_destiny_rust.zip
cd chess_destiny_rust
cargo run --release
```
First build takes ~2 minutes (downloads dependencies, compiles everything).
After that, it opens instantly.

**The `--release` flag is critical** — without it, the code runs 20x slower.

## How It Works

When you launch, a chess board appears and the explorer immediately starts working in the background. It plays through every possible game using your priority rules, records every result, and when it encounters a board position it has already seen (reached through different moves), it skips it and reuses the stored result.

**Click any piece** to see its destiny:
- **Green** = this move leads to a WIN
- **Yellow** = this move leads to a DRAW
- **Red** = this move leads to a LOSS
- **Gray** = not yet computed

Progress saves to `destiny_table.bin` every 30 seconds and persists across sessions. Every time you relaunch, it picks up where it left off.

## Controls

### Mouse
- Click a piece to select it and see destiny
- Click a highlighted square to move there

### Keyboard
| Key | Action |
|-----|--------|
| R | Reset game (keeps computed data) |
| A | Toggle auto-play (priority-based moves) |
| S | Manual save to disk |
| U | Undo last move |
| ] | Speed up exploration |
| [ | Slow down exploration |

## Stats Panel

The right panel shows live stats:
- **Speed** — positions evaluated per second
- **Games** — complete game paths explored
- **Explored** — total positions visited
- **Duplicates skipped** — times a cached result was reused (your shortcut)
- **Cache hit rate** — percentage of positions that were duplicates
- **Stored** — unique positions in the transposition table
- **Disk** — size of the save file

## Why This Is Fast

- **Rust** runs 200x faster than GDScript
- **64-bit Zobrist hashing** prevents hash collisions at billions of entries
- **Incremental hashing** — board hash updates in O(1) per move via XOR
- **M4 chip** — Apple Silicon is excellent for this kind of computation

## Files

```
src/
├── main.rs       — GUI rendering, input handling, game loop
├── engine.rs     — Full FIDE chess rules engine
├── zobrist.rs    — 64-bit deterministic hash keys
├── priority.rs   — Move priority ordering (your system)
├── explorer.rs   — Game tree search with transposition table
└── storage.rs    — Save/load transposition table to disk
```
