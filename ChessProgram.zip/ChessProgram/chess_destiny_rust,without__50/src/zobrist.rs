use rand::rngs::StdRng;
use rand::{Rng, SeedableRng};

/// 64-bit Zobrist hashing for chess positions.
/// At 10^10 entries, 64-bit gives ~1 in 10^9 collision probability.
/// Deterministic: same seed always produces same keys.

pub struct ZobristKeys {
    /// pieces[piece_index][rank][file] - 12 piece types x 8 ranks x 8 files
    pub pieces: [[[u64; 8]; 8]; 12],
    /// castling[0..4] = wk, wq, bk, bq
    pub castling: [u64; 4],
    /// en_passant[file] for each possible ep file
    pub en_passant: [u64; 8],
    /// XOR when it's white's turn
    pub side: u64,
}

impl ZobristKeys {
    pub fn new() -> Self {
        // Fixed seed for deterministic hashing across runs
        let mut rng = StdRng::seed_from_u64(0x12345678_ABCDEF00);
        let mut keys = ZobristKeys {
            pieces: [[[0u64; 8]; 8]; 12],
            castling: [0u64; 4],
            en_passant: [0u64; 8],
            side: 0,
        };

        for piece in 0..12 {
            for rank in 0..8 {
                for file in 0..8 {
                    keys.pieces[piece][rank][file] = rng.gen();
                }
            }
        }
        for i in 0..4 {
            keys.castling[i] = rng.gen();
        }
        for i in 0..8 {
            keys.en_passant[i] = rng.gen();
        }
        keys.side = rng.gen();
        keys
    }

    /// Map piece value to zobrist index (0..11)
    /// White: Pawn=0, Knight=1, Bishop=2, Rook=3, Queen=4, King=5
    /// Black: Pawn=6, Knight=7, Bishop=8, Rook=9, Queen=10, King=11
    #[inline]
    pub fn piece_index(piece: i8) -> usize {
        if piece > 0 {
            (piece - 1) as usize
        } else {
            ((-piece) + 5) as usize
        }
    }
}
