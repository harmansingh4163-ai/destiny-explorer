use crate::zobrist::ZobristKeys;

// Piece encoding: positive = white, negative = black
pub const EMPTY: i8 = 0;
pub const W_PAWN: i8 = 1;
pub const W_KNIGHT: i8 = 2;
pub const W_BISHOP: i8 = 3;
pub const W_ROOK: i8 = 4;
pub const W_QUEEN: i8 = 5;
pub const W_KING: i8 = 6;
pub const B_PAWN: i8 = -1;
pub const B_KNIGHT: i8 = -2;
pub const B_BISHOP: i8 = -3;
pub const B_ROOK: i8 = -4;
pub const B_QUEEN: i8 = -5;
pub const B_KING: i8 = -6;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum GameResult {
    Ongoing,
    WhiteWins,
    BlackWins,
    Draw,
}

impl GameResult {
    pub fn to_u8(self) -> u8 {
        match self {
            GameResult::Ongoing => 0,
            GameResult::WhiteWins => 1,
            GameResult::BlackWins => 2,
            GameResult::Draw => 3,
        }
    }

    pub fn from_u8(v: u8) -> Self {
        match v {
            1 => GameResult::WhiteWins,
            2 => GameResult::BlackWins,
            3 => GameResult::Draw,
            _ => GameResult::Ongoing,
        }
    }

    pub fn name(&self) -> &str {
        match self {
            GameResult::Ongoing => "Ongoing",
            GameResult::WhiteWins => "White Wins",
            GameResult::BlackWins => "Black Wins",
            GameResult::Draw => "Draw",
        }
    }
}

#[derive(Debug, Clone, Copy)]
pub struct CastlingRights {
    pub white_king: bool,
    pub white_queen: bool,
    pub black_king: bool,
    pub black_queen: bool,
}

impl CastlingRights {
    pub fn new() -> Self {
        CastlingRights {
            white_king: true,
            white_queen: true,
            black_king: true,
            black_queen: true,
        }
    }

    pub fn none() -> Self {
        CastlingRights {
            white_king: false,
            white_queen: false,
            black_king: false,
            black_queen: false,
        }
    }
}

#[derive(Debug, Clone, Copy)]
pub struct Move {
    pub from_file: u8,
    pub from_rank: u8,
    pub to_file: u8,
    pub to_rank: u8,
    pub piece: i8,
    pub captured: i8,
    pub promotion: i8,
    pub is_castling: bool,
    pub is_en_passant: bool,
    // State to restore on unmake
    pub prev_castling: CastlingRights,
    pub prev_ep_file: i8,  // -1 = none
    pub prev_ep_rank: i8,  // -1 = none
    pub prev_halfmove: u16,
}

impl Move {
    pub fn to_algebraic(&self) -> String {
        let files = b"abcdefgh";
        if self.is_castling {
            return if self.to_file == 6 {
                "O-O".to_string()
            } else {
                "O-O-O".to_string()
            };
        }
        let mut s = String::new();
        let abs_p = self.piece.unsigned_abs();
        // Piece letter
        if abs_p != 1 {
            s.push(match abs_p {
                2 => 'N',
                3 => 'B',
                4 => 'R',
                5 => 'Q',
                6 => 'K',
                _ => '?',
            });
        }
        // Capture
        if self.captured != EMPTY || self.is_en_passant {
            if abs_p == 1 {
                s.push(files[self.from_file as usize] as char);
            }
            s.push('x');
        }
        // Destination
        s.push(files[self.to_file as usize] as char);
        s.push((b'1' + self.to_rank) as char);
        // Promotion
        if self.promotion != 0 {
            s.push('=');
            s.push(match self.promotion.unsigned_abs() {
                5 => 'Q',
                4 => 'R',
                3 => 'B',
                2 => 'N',
                _ => '?',
            });
        }
        s
    }
}

pub struct ChessEngine {
    pub board: [[i8; 8]; 8],  // board[rank][file]
    pub white_to_move: bool,
    pub castling: CastlingRights,
    pub ep_file: i8,  // en passant target file, -1 = none
    pub ep_rank: i8,  // en passant target rank
    pub halfmove_clock: u16,
    pub fullmove_number: u16,
    pub move_history: Vec<Move>,
    pub hash_history: Vec<u64>,
    pub zobrist: &'static ZobristKeys,
    pub current_hash: u64,
}

// Global zobrist keys (initialized once)
use std::sync::OnceLock;
static ZOBRIST_KEYS: OnceLock<ZobristKeys> = OnceLock::new();

pub fn get_zobrist_keys() -> &'static ZobristKeys {
    ZOBRIST_KEYS.get_or_init(ZobristKeys::new)
}

impl ChessEngine {
    pub fn new() -> Self {
        let keys = get_zobrist_keys();
        let mut engine = ChessEngine {
            board: [[EMPTY; 8]; 8],
            white_to_move: true,
            castling: CastlingRights::new(),
            ep_file: -1,
            ep_rank: -1,
            halfmove_clock: 0,
            fullmove_number: 1,
            move_history: Vec::with_capacity(256),
            hash_history: Vec::with_capacity(256),
            zobrist: keys,
            current_hash: 0,
        };
        engine.setup_initial();
        engine.current_hash = engine.compute_hash();
        engine.hash_history.push(engine.current_hash);
        engine
    }

    /// Create an engine with a custom position (for endgame solving)
    pub fn empty() -> Self {
        let keys = get_zobrist_keys();
        ChessEngine {
            board: [[EMPTY; 8]; 8],
            white_to_move: true,
            castling: CastlingRights::none(),
            ep_file: -1,
            ep_rank: -1,
            halfmove_clock: 0,
            fullmove_number: 1,
            move_history: Vec::with_capacity(256),
            hash_history: Vec::with_capacity(256),
            zobrist: keys,
            current_hash: 0,
        }
    }

    pub fn set_piece(&mut self, file: u8, rank: u8, piece: i8) {
        self.board[rank as usize][file as usize] = piece;
    }

    pub fn finalize_setup(&mut self) {
        self.current_hash = self.compute_hash();
        self.hash_history.clear();
        self.hash_history.push(self.current_hash);
    }

    fn setup_initial(&mut self) {
        // White pieces - rank 0
        self.board[0] = [W_ROOK, W_KNIGHT, W_BISHOP, W_QUEEN, W_KING, W_BISHOP, W_KNIGHT, W_ROOK];
        // White pawns - rank 1
        for f in 0..8 {
            self.board[1][f] = W_PAWN;
        }
        // Black pawns - rank 6
        for f in 0..8 {
            self.board[6][f] = B_PAWN;
        }
        // Black pieces - rank 7
        self.board[7] = [B_ROOK, B_KNIGHT, B_BISHOP, B_QUEEN, B_KING, B_BISHOP, B_KNIGHT, B_ROOK];
    }

    pub fn compute_hash(&self) -> u64 {
        let mut h: u64 = 0;
        for r in 0..8 {
            for f in 0..8 {
                let p = self.board[r][f];
                if p != EMPTY {
                    let idx = ZobristKeys::piece_index(p);
                    h ^= self.zobrist.pieces[idx][r][f];
                }
            }
        }
        if self.castling.white_king {
            h ^= self.zobrist.castling[0];
        }
        if self.castling.white_queen {
            h ^= self.zobrist.castling[1];
        }
        if self.castling.black_king {
            h ^= self.zobrist.castling[2];
        }
        if self.castling.black_queen {
            h ^= self.zobrist.castling[3];
        }
        if self.ep_file >= 0 {
            h ^= self.zobrist.en_passant[self.ep_file as usize];
        }
        if self.white_to_move {
            h ^= self.zobrist.side;
        }
        h
    }

    #[inline]
    fn in_bounds(f: i8, r: i8) -> bool {
        f >= 0 && f < 8 && r >= 0 && r < 8
    }

    #[inline]
    fn is_own_piece(piece: i8, white: bool) -> bool {
        (white && piece > 0) || (!white && piece < 0)
    }

    #[inline]
    pub fn is_own_piece_static(piece: i8, white: bool) -> bool {
        (white && piece > 0) || (!white && piece < 0)
    }

    #[inline]
    fn is_enemy_piece(piece: i8, white: bool) -> bool {
        (white && piece < 0) || (!white && piece > 0)
    }

    pub fn find_king(&self, white: bool) -> (u8, u8) {
        let target = if white { W_KING } else { B_KING };
        for r in 0..8u8 {
            for f in 0..8u8 {
                if self.board[r as usize][f as usize] == target {
                    return (f, r);
                }
            }
        }
        (0, 0) // Should never happen
    }

    pub fn is_square_attacked(&self, sf: u8, sr: u8, by_white: bool) -> bool {
        let sf_i = sf as i8;
        let sr_i = sr as i8;

        // Pawn attacks
        if by_white {
            if sf_i > 0 && sr_i > 0 && self.board[(sr - 1) as usize][(sf - 1) as usize] == W_PAWN {
                return true;
            }
            if sf_i < 7 && sr_i > 0 && self.board[(sr - 1) as usize][(sf + 1) as usize] == W_PAWN {
                return true;
            }
        } else {
            if sf_i > 0 && sr_i < 7 && self.board[(sr + 1) as usize][(sf - 1) as usize] == B_PAWN {
                return true;
            }
            if sf_i < 7 && sr_i < 7 && self.board[(sr + 1) as usize][(sf + 1) as usize] == B_PAWN {
                return true;
            }
        }

        // Knight attacks
        let knight = if by_white { W_KNIGHT } else { B_KNIGHT };
        const KNIGHT_OFFSETS: [(i8, i8); 8] = [
            (-2, -1), (-2, 1), (-1, -2), (-1, 2),
            (1, -2), (1, 2), (2, -1), (2, 1),
        ];
        for &(df, dr) in &KNIGHT_OFFSETS {
            let nf = sf_i + df;
            let nr = sr_i + dr;
            if Self::in_bounds(nf, nr) && self.board[nr as usize][nf as usize] == knight {
                return true;
            }
        }

        // King attacks
        let king = if by_white { W_KING } else { B_KING };
        for dr in -1..=1i8 {
            for df in -1..=1i8 {
                if dr == 0 && df == 0 {
                    continue;
                }
                let kf = sf_i + df;
                let kr = sr_i + dr;
                if Self::in_bounds(kf, kr) && self.board[kr as usize][kf as usize] == king {
                    return true;
                }
            }
        }

        // Sliding pieces
        let bishop = if by_white { W_BISHOP } else { B_BISHOP };
        let rook = if by_white { W_ROOK } else { B_ROOK };
        let queen = if by_white { W_QUEEN } else { B_QUEEN };

        // Diagonals (bishop + queen)
        const DIAG_DIRS: [(i8, i8); 4] = [(-1, -1), (-1, 1), (1, -1), (1, 1)];
        for &(df, dr) in &DIAG_DIRS {
            for dist in 1..8i8 {
                let tf = sf_i + df * dist;
                let tr = sr_i + dr * dist;
                if !Self::in_bounds(tf, tr) {
                    break;
                }
                let p = self.board[tr as usize][tf as usize];
                if p != EMPTY {
                    if p == bishop || p == queen {
                        return true;
                    }
                    break;
                }
            }
        }

        // Straights (rook + queen)
        const STRAIGHT_DIRS: [(i8, i8); 4] = [(0, -1), (0, 1), (-1, 0), (1, 0)];
        for &(df, dr) in &STRAIGHT_DIRS {
            for dist in 1..8i8 {
                let tf = sf_i + df * dist;
                let tr = sr_i + dr * dist;
                if !Self::in_bounds(tf, tr) {
                    break;
                }
                let p = self.board[tr as usize][tf as usize];
                if p != EMPTY {
                    if p == rook || p == queen {
                        return true;
                    }
                    break;
                }
            }
        }

        false
    }

    pub fn is_in_check(&self, white: bool) -> bool {
        let (kf, kr) = self.find_king(white);
        self.is_square_attacked(kf, kr, !white)
    }

    /// Generate all pseudo-legal moves
    pub fn generate_pseudo_legal_moves(&self, moves: &mut Vec<Move>) {
        moves.clear();
        let white = self.white_to_move;
        for r in 0..8u8 {
            for f in 0..8u8 {
                let p = self.board[r as usize][f as usize];
                if !Self::is_own_piece(p, white) {
                    continue;
                }
                match p.unsigned_abs() {
                    1 => self.gen_pawn_moves(f, r, white, moves),
                    2 => self.gen_knight_moves(f, r, white, moves),
                    3 => self.gen_bishop_moves(f, r, white, moves),
                    4 => self.gen_rook_moves(f, r, white, moves),
                    5 => self.gen_queen_moves(f, r, white, moves),
                    6 => self.gen_king_moves(f, r, white, moves),
                    _ => {}
                }
            }
        }
    }

    fn make_move_struct(&self, ff: u8, fr: u8, tf: u8, tr: u8, promo: i8) -> Move {
        Move {
            from_file: ff,
            from_rank: fr,
            to_file: tf,
            to_rank: tr,
            piece: self.board[fr as usize][ff as usize],
            captured: self.board[tr as usize][tf as usize],
            promotion: promo,
            is_castling: false,
            is_en_passant: false,
            prev_castling: self.castling,
            prev_ep_file: self.ep_file,
            prev_ep_rank: self.ep_rank,
            prev_halfmove: self.halfmove_clock,
        }
    }

    fn gen_pawn_moves(&self, f: u8, r: u8, white: bool, moves: &mut Vec<Move>) {
        let dir: i8 = if white { 1 } else { -1 };
        let start_rank: u8 = if white { 1 } else { 6 };
        let promo_rank: u8 = if white { 7 } else { 0 };
        let nr = (r as i8 + dir) as u8;

        // Forward 1
        if nr < 8 && self.board[nr as usize][f as usize] == EMPTY {
            if nr == promo_rank {
                let promos = if white {
                    [W_QUEEN, W_ROOK, W_BISHOP, W_KNIGHT]
                } else {
                    [B_QUEEN, B_ROOK, B_BISHOP, B_KNIGHT]
                };
                for promo in promos {
                    moves.push(self.make_move_struct(f, r, f, nr, promo));
                }
            } else {
                moves.push(self.make_move_struct(f, r, f, nr, 0));
                // Forward 2
                if r == start_rank {
                    let nr2 = (r as i8 + dir * 2) as u8;
                    if self.board[nr2 as usize][f as usize] == EMPTY {
                        moves.push(self.make_move_struct(f, r, f, nr2, 0));
                    }
                }
            }
        }

        // Captures
        for df in [-1i8, 1i8] {
            let cf = f as i8 + df;
            if cf < 0 || cf >= 8 || nr > 7 {
                continue;
            }
            let cf = cf as u8;
            let target = self.board[nr as usize][cf as usize];

            if nr == promo_rank {
                if Self::is_enemy_piece(target, white) {
                    let promos = if white {
                        [W_QUEEN, W_ROOK, W_BISHOP, W_KNIGHT]
                    } else {
                        [B_QUEEN, B_ROOK, B_BISHOP, B_KNIGHT]
                    };
                    for promo in promos {
                        moves.push(self.make_move_struct(f, r, cf, nr, promo));
                    }
                }
            } else if Self::is_enemy_piece(target, white) {
                moves.push(self.make_move_struct(f, r, cf, nr, 0));
            } else if self.ep_file >= 0 && cf == self.ep_file as u8 && nr == self.ep_rank as u8 {
                // En passant
                let mut m = self.make_move_struct(f, r, cf, nr, 0);
                m.is_en_passant = true;
                m.captured = self.board[r as usize][cf as usize]; // Captured pawn beside us
                moves.push(m);
            }
        }
    }

    fn gen_knight_moves(&self, f: u8, r: u8, white: bool, moves: &mut Vec<Move>) {
        const OFFSETS: [(i8, i8); 8] = [
            (-2, -1), (-2, 1), (-1, -2), (-1, 2),
            (1, -2), (1, 2), (2, -1), (2, 1),
        ];
        for &(df, dr) in &OFFSETS {
            let tf = f as i8 + df;
            let tr = r as i8 + dr;
            if !Self::in_bounds(tf, tr) {
                continue;
            }
            let target = self.board[tr as usize][tf as usize];
            if Self::is_own_piece(target, white) {
                continue;
            }
            moves.push(self.make_move_struct(f, r, tf as u8, tr as u8, 0));
        }
    }

    fn gen_sliding_moves(
        &self, f: u8, r: u8, white: bool,
        dirs: &[(i8, i8)], moves: &mut Vec<Move>,
    ) {
        for &(df, dr) in dirs {
            for dist in 1..8i8 {
                let tf = f as i8 + df * dist;
                let tr = r as i8 + dr * dist;
                if !Self::in_bounds(tf, tr) {
                    break;
                }
                let target = self.board[tr as usize][tf as usize];
                if Self::is_own_piece(target, white) {
                    break;
                }
                moves.push(self.make_move_struct(f, r, tf as u8, tr as u8, 0));
                if target != EMPTY {
                    break; // Capture stops sliding
                }
            }
        }
    }

    fn gen_bishop_moves(&self, f: u8, r: u8, white: bool, moves: &mut Vec<Move>) {
        const DIRS: [(i8, i8); 4] = [(-1, -1), (-1, 1), (1, -1), (1, 1)];
        self.gen_sliding_moves(f, r, white, &DIRS, moves);
    }

    fn gen_rook_moves(&self, f: u8, r: u8, white: bool, moves: &mut Vec<Move>) {
        const DIRS: [(i8, i8); 4] = [(0, -1), (0, 1), (-1, 0), (1, 0)];
        self.gen_sliding_moves(f, r, white, &DIRS, moves);
    }

    fn gen_queen_moves(&self, f: u8, r: u8, white: bool, moves: &mut Vec<Move>) {
        const DIRS: [(i8, i8); 8] = [
            (0, -1), (0, 1), (-1, 0), (1, 0),
            (-1, -1), (-1, 1), (1, -1), (1, 1),
        ];
        self.gen_sliding_moves(f, r, white, &DIRS, moves);
    }

    fn gen_king_moves(&self, f: u8, r: u8, white: bool, moves: &mut Vec<Move>) {
        for dr in -1..=1i8 {
            for df in -1..=1i8 {
                if dr == 0 && df == 0 {
                    continue;
                }
                let tf = f as i8 + df;
                let tr = r as i8 + dr;
                if !Self::in_bounds(tf, tr) {
                    continue;
                }
                if Self::is_own_piece(self.board[tr as usize][tf as usize], white) {
                    continue;
                }
                moves.push(self.make_move_struct(f, r, tf as u8, tr as u8, 0));
            }
        }

        // Castling
        let rank: u8 = if white { 0 } else { 7 };
        if r != rank || f != 4 {
            return;
        }

        // Kingside
        let can_ks = if white {
            self.castling.white_king
        } else {
            self.castling.black_king
        };
        if can_ks
            && self.board[rank as usize][5] == EMPTY
            && self.board[rank as usize][6] == EMPTY
            && !self.is_square_attacked(4, rank, !white)
            && !self.is_square_attacked(5, rank, !white)
            && !self.is_square_attacked(6, rank, !white)
        {
            let mut m = self.make_move_struct(4, rank, 6, rank, 0);
            m.is_castling = true;
            moves.push(m);
        }

        // Queenside
        let can_qs = if white {
            self.castling.white_queen
        } else {
            self.castling.black_queen
        };
        if can_qs
            && self.board[rank as usize][3] == EMPTY
            && self.board[rank as usize][2] == EMPTY
            && self.board[rank as usize][1] == EMPTY
            && !self.is_square_attacked(4, rank, !white)
            && !self.is_square_attacked(3, rank, !white)
            && !self.is_square_attacked(2, rank, !white)
        {
            let mut m = self.make_move_struct(4, rank, 2, rank, 0);
            m.is_castling = true;
            moves.push(m);
        }
    }

    /// Generate all legal moves
    pub fn generate_legal_moves(&mut self) -> Vec<Move> {
        let mut pseudo = Vec::with_capacity(64);
        self.generate_pseudo_legal_moves(&mut pseudo);
        let mut legal = Vec::with_capacity(pseudo.len());
        for m in pseudo {
            self.make_move(&m);
            // After making the move, white_to_move has flipped,
            // so check if the side that just moved is in check
            if !self.is_in_check(!self.white_to_move) {
                legal.push(m);
            }
            self.unmake_move();
        }
        legal
    }

    pub fn make_move(&mut self, m: &Move) {
        let ff = m.from_file as usize;
        let fr = m.from_rank as usize;
        let tf = m.to_file as usize;
        let tr = m.to_rank as usize;

        // Update hash - remove piece from source
        let piece_idx = ZobristKeys::piece_index(m.piece);
        self.current_hash ^= self.zobrist.pieces[piece_idx][fr][ff];

        // Handle en passant capture
        if m.is_en_passant {
            let cap_rank = fr; // Captured pawn is on same rank as moving pawn
            let cap_idx = ZobristKeys::piece_index(m.captured);
            self.current_hash ^= self.zobrist.pieces[cap_idx][cap_rank][tf];
            self.board[cap_rank][tf] = EMPTY;
        } else if m.captured != EMPTY {
            let cap_idx = ZobristKeys::piece_index(m.captured);
            self.current_hash ^= self.zobrist.pieces[cap_idx][tr][tf];
        }

        // Move piece
        self.board[tr][tf] = m.piece;
        self.board[fr][ff] = EMPTY;

        // Handle promotion
        if m.promotion != 0 {
            self.board[tr][tf] = m.promotion;
            let promo_idx = ZobristKeys::piece_index(m.promotion);
            self.current_hash ^= self.zobrist.pieces[promo_idx][tr][tf];
        } else {
            self.current_hash ^= self.zobrist.pieces[piece_idx][tr][tf];
        }

        // Handle castling rook movement
        if m.is_castling {
            let rank = fr;
            if tf == 6 {
                // Kingside
                let rook = self.board[rank][7];
                let rook_idx = ZobristKeys::piece_index(rook);
                self.current_hash ^= self.zobrist.pieces[rook_idx][rank][7];
                self.current_hash ^= self.zobrist.pieces[rook_idx][rank][5];
                self.board[rank][5] = rook;
                self.board[rank][7] = EMPTY;
            } else if tf == 2 {
                // Queenside
                let rook = self.board[rank][0];
                let rook_idx = ZobristKeys::piece_index(rook);
                self.current_hash ^= self.zobrist.pieces[rook_idx][rank][0];
                self.current_hash ^= self.zobrist.pieces[rook_idx][rank][3];
                self.board[rank][3] = rook;
                self.board[rank][0] = EMPTY;
            }
        }

        // Update castling hash (remove old)
        if self.castling.white_king {
            self.current_hash ^= self.zobrist.castling[0];
        }
        if self.castling.white_queen {
            self.current_hash ^= self.zobrist.castling[1];
        }
        if self.castling.black_king {
            self.current_hash ^= self.zobrist.castling[2];
        }
        if self.castling.black_queen {
            self.current_hash ^= self.zobrist.castling[3];
        }

        // Update castling rights
        if m.piece == W_KING {
            self.castling.white_king = false;
            self.castling.white_queen = false;
        } else if m.piece == B_KING {
            self.castling.black_king = false;
            self.castling.black_queen = false;
        } else if m.piece == W_ROOK {
            if ff == 0 && fr == 0 {
                self.castling.white_queen = false;
            } else if ff == 7 && fr == 0 {
                self.castling.white_king = false;
            }
        } else if m.piece == B_ROOK {
            if ff == 0 && fr == 7 {
                self.castling.black_queen = false;
            } else if ff == 7 && fr == 7 {
                self.castling.black_king = false;
            }
        }
        // If a rook is captured
        if tf == 0 && tr == 0 {
            self.castling.white_queen = false;
        } else if tf == 7 && tr == 0 {
            self.castling.white_king = false;
        } else if tf == 0 && tr == 7 {
            self.castling.black_queen = false;
        } else if tf == 7 && tr == 7 {
            self.castling.black_king = false;
        }

        // Add new castling hash
        if self.castling.white_king {
            self.current_hash ^= self.zobrist.castling[0];
        }
        if self.castling.white_queen {
            self.current_hash ^= self.zobrist.castling[1];
        }
        if self.castling.black_king {
            self.current_hash ^= self.zobrist.castling[2];
        }
        if self.castling.black_queen {
            self.current_hash ^= self.zobrist.castling[3];
        }

        // Update en passant hash
        if self.ep_file >= 0 {
            self.current_hash ^= self.zobrist.en_passant[self.ep_file as usize];
        }
        if m.piece.unsigned_abs() == 1 && (m.to_rank as i8 - m.from_rank as i8).unsigned_abs() == 2
        {
            self.ep_file = m.from_file as i8;
            self.ep_rank = ((m.from_rank as i8 + m.to_rank as i8) / 2) as i8;
            self.current_hash ^= self.zobrist.en_passant[self.ep_file as usize];
        } else {
            self.ep_file = -1;
            self.ep_rank = -1;
        }

        // Halfmove clock
        if m.piece.unsigned_abs() == 1 || m.captured != EMPTY {
            self.halfmove_clock = 0;
        } else {
            self.halfmove_clock += 1;
        }

        // Fullmove number
        if !self.white_to_move {
            self.fullmove_number += 1;
        }

        // Switch side
        self.current_hash ^= self.zobrist.side;
        self.white_to_move = !self.white_to_move;

        // Store history
        self.move_history.push(*m);
        self.hash_history.push(self.current_hash);
    }

    pub fn unmake_move(&mut self) {
        let m = match self.move_history.pop() {
            Some(m) => m,
            None => return,
        };
        self.hash_history.pop();

        // Switch side back
        self.white_to_move = !self.white_to_move;

        let ff = m.from_file as usize;
        let fr = m.from_rank as usize;
        let tf = m.to_file as usize;
        let tr = m.to_rank as usize;

        // Restore piece to original square
        self.board[fr][ff] = m.piece;

        // Restore captured piece
        if m.is_en_passant {
            self.board[tr][tf] = EMPTY;
            self.board[fr][tf] = m.captured; // Captured pawn was beside us
        } else {
            self.board[tr][tf] = m.captured;
        }

        // Undo castling rook
        if m.is_castling {
            let rank = fr;
            if tf == 6 {
                self.board[rank][7] = self.board[rank][5];
                self.board[rank][5] = EMPTY;
            } else if tf == 2 {
                self.board[rank][0] = self.board[rank][3];
                self.board[rank][3] = EMPTY;
            }
        }

        // Restore state
        self.castling = m.prev_castling;
        self.ep_file = m.prev_ep_file;
        self.ep_rank = m.prev_ep_rank;
        self.halfmove_clock = m.prev_halfmove;
        if !self.white_to_move {
            self.fullmove_number -= 1;
        }

        // Restore hash from history
        self.current_hash = *self.hash_history.last().unwrap_or(&0);
    }

    /// Check threefold repetition
    pub fn is_threefold_repetition(&self) -> bool {
        if self.hash_history.len() < 5 {
            return false;
        }
        let current = self.current_hash;
        let mut count = 0u32;
        for &h in &self.hash_history {
            if h == current {
                count += 1;
                if count >= 3 {
                    return true;
                }
            }
        }
        false
    }

    /// Check insufficient material
    pub fn is_insufficient_material(&self) -> bool {
        let mut white_pieces: Vec<i8> = Vec::new();
        let mut black_pieces: Vec<i8> = Vec::new();
        for r in 0..8 {
            for f in 0..8 {
                let p = self.board[r][f];
                if p > 0 && p != W_KING {
                    white_pieces.push(p);
                } else if p < 0 && p != B_KING {
                    black_pieces.push(p);
                }
            }
        }
        // K vs K
        if white_pieces.is_empty() && black_pieces.is_empty() {
            return true;
        }
        // K+B vs K or K+N vs K
        if white_pieces.is_empty() && black_pieces.len() == 1 {
            if black_pieces[0] == B_BISHOP || black_pieces[0] == B_KNIGHT {
                return true;
            }
        }
        if black_pieces.is_empty() && white_pieces.len() == 1 {
            if white_pieces[0] == W_BISHOP || white_pieces[0] == W_KNIGHT {
                return true;
            }
        }
        // K+B vs K+B same color
        if white_pieces.len() == 1 && black_pieces.len() == 1 {
            if white_pieces[0] == W_BISHOP && black_pieces[0] == B_BISHOP {
                let mut wb_color = 0u8;
                let mut bb_color = 0u8;
                for r in 0..8u8 {
                    for f in 0..8u8 {
                        if self.board[r as usize][f as usize] == W_BISHOP {
                            wb_color = (f + r) % 2;
                        } else if self.board[r as usize][f as usize] == B_BISHOP {
                            bb_color = (f + r) % 2;
                        }
                    }
                }
                if wb_color == bb_color {
                    return true;
                }
            }
        }
        false
    }

    /// Get game result
    pub fn get_result(&mut self) -> GameResult {
        let legal = self.generate_legal_moves();
        if legal.is_empty() {
            if self.is_in_check(self.white_to_move) {
                return if self.white_to_move {
                    GameResult::BlackWins
                } else {
                    GameResult::WhiteWins
                };
            } else {
                return GameResult::Draw; // Stalemate
            }
        }
        if self.halfmove_clock >= 100 {
            return GameResult::Draw;
        }
        if self.is_threefold_repetition() {
            return GameResult::Draw;
        }
        if self.is_insufficient_material() {
            return GameResult::Draw;
        }
        GameResult::Ongoing
    }

    pub fn clone_engine(&self) -> Self {
        ChessEngine {
            board: self.board,
            white_to_move: self.white_to_move,
            castling: self.castling,
            ep_file: self.ep_file,
            ep_rank: self.ep_rank,
            halfmove_clock: self.halfmove_clock,
            fullmove_number: self.fullmove_number,
            move_history: self.move_history.clone(),
            hash_history: self.hash_history.clone(),
            zobrist: self.zobrist,
            current_hash: self.current_hash,
        }
    }

    /// Count total pieces on board
    pub fn piece_count(&self) -> u32 {
        let mut count = 0u32;
        for r in 0..8 {
            for f in 0..8 {
                if self.board[r][f] != EMPTY {
                    count += 1;
                }
            }
        }
        count
    }

    pub fn print_board(&self) {
        let piece_char = |p: i8| -> char {
            match p {
                W_KING => 'K',
                W_QUEEN => 'Q',
                W_ROOK => 'R',
                W_BISHOP => 'B',
                W_KNIGHT => 'N',
                W_PAWN => 'P',
                B_KING => 'k',
                B_QUEEN => 'q',
                B_ROOK => 'r',
                B_BISHOP => 'b',
                B_KNIGHT => 'n',
                B_PAWN => 'p',
                _ => '.',
            }
        };
        println!("  a b c d e f g h");
        for r in (0..8).rev() {
            print!("{} ", r + 1);
            for f in 0..8 {
                print!("{} ", piece_char(self.board[r][f]));
            }
            println!("{}", r + 1);
        }
        println!("  a b c d e f g h");
        println!(
            "{} to move | Move {}",
            if self.white_to_move { "White" } else { "Black" },
            self.fullmove_number
        );
    }
}
