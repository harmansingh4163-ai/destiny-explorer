# Tic-Tac-Toe Destiny Explorer

Proof that the algorithm works. This program solves tic-tac-toe COMPLETELY in under a second, then lets you play while seeing the destiny of every possible move.

## Run It

```bash
cd tictactoe_destiny
cargo run --release
```

## What You'll See

When the window opens, the entire game has already been solved. Every empty cell is colored:

- **Green** = this move leads to a WIN for the current player
- **Yellow** = this move leads to a DRAW with perfect play  
- **Red** = this move leads to a LOSS if the opponent plays perfectly

The opening verdict will show **Draw** — confirming that tic-tac-toe is a draw with perfect play from both sides.

## Controls

- Click any cell to play
- **R** = new game
- **U** = undo

## The Point

This is the same algorithm as the chess and checkers versions — exhaustive forward search with duplicate board elimination via hashing. The only difference is the game is small enough to solve completely. The stats panel shows how many positions were explored, how many duplicates were skipped, and the cache hit rate.

This proves the algorithm produces correct, complete results. The same code, applied to larger games, would produce the same quality of results — it would just take longer.
