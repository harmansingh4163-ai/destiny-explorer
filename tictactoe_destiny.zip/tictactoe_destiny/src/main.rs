use macroquad::prelude::*;
use std::collections::HashMap;

// =====================================================
// GAME ENGINE
// =====================================================

const EMPTY: i8 = 0;
const X_PIECE: i8 = 1;   // X goes first
const O_PIECE: i8 = -1;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
enum GameResult {
    Ongoing,
    XWins,
    OWins,
    Draw,
}

impl GameResult {
    fn name(&self) -> &str {
        match self {
            GameResult::Ongoing => "Ongoing",
            GameResult::XWins => "X Wins",
            GameResult::OWins => "O Wins",
            GameResult::Draw => "Draw",
        }
    }
}

#[derive(Clone)]
struct TicTacToe {
    board: [i8; 9],       // 0-8, row-major: [0,1,2 / 3,4,5 / 6,7,8]
    x_to_move: bool,
    move_history: Vec<usize>,
}

impl TicTacToe {
    fn new() -> Self {
        TicTacToe {
            board: [EMPTY; 9],
            x_to_move: true,
            move_history: Vec::with_capacity(9),
        }
    }

    /// Encode board as a unique hash (base-3 encoding + side to move)
    fn hash(&self) -> u32 {
        let mut h: u32 = 0;
        for i in 0..9 {
            let val = match self.board[i] {
                X_PIECE => 1u32,
                O_PIECE => 2u32,
                _ => 0u32,
            };
            h = h * 3 + val;
        }
        if self.x_to_move {
            h |= 1 << 16;
        }
        h
    }

    fn check_winner(&self) -> Option<i8> {
        const LINES: [[usize; 3]; 8] = [
            [0, 1, 2], [3, 4, 5], [6, 7, 8], // rows
            [0, 3, 6], [1, 4, 7], [2, 5, 8], // cols
            [0, 4, 8], [2, 4, 6],             // diags
        ];
        for line in &LINES {
            let a = self.board[line[0]];
            if a != EMPTY && a == self.board[line[1]] && a == self.board[line[2]] {
                return Some(a);
            }
        }
        None
    }

    fn is_full(&self) -> bool {
        self.board.iter().all(|&c| c != EMPTY)
    }

    fn get_result(&self) -> GameResult {
        if let Some(winner) = self.check_winner() {
            if winner == X_PIECE {
                GameResult::XWins
            } else {
                GameResult::OWins
            }
        } else if self.is_full() {
            GameResult::Draw
        } else {
            GameResult::Ongoing
        }
    }

    fn legal_moves(&self) -> Vec<usize> {
        if self.check_winner().is_some() {
            return Vec::new();
        }
        (0..9).filter(|&i| self.board[i] == EMPTY).collect()
    }

    fn make_move(&mut self, pos: usize) {
        let piece = if self.x_to_move { X_PIECE } else { O_PIECE };
        self.board[pos] = piece;
        self.x_to_move = !self.x_to_move;
        self.move_history.push(pos);
    }

    fn unmake_move(&mut self) {
        if let Some(pos) = self.move_history.pop() {
            self.board[pos] = EMPTY;
            self.x_to_move = !self.x_to_move;
        }
    }
}

// =====================================================
// DESTINY EXPLORER
// =====================================================

struct Explorer {
    table: HashMap<u32, GameResult>,
    engine: TicTacToe,
    games_completed: u64,
    positions_explored: u64,
    positions_cached: u64,
    is_complete: bool,
}

impl Explorer {
    fn new() -> Self {
        Explorer {
            table: HashMap::with_capacity(10000),
            engine: TicTacToe::new(),
            games_completed: 0,
            positions_explored: 0,
            positions_cached: 0,
            is_complete: false,
        }
    }

    /// Solve the entire game tree recursively. For tic-tac-toe this is instant.
    fn solve_completely(&mut self) {
        let engine = TicTacToe::new();
        self.solve_position(&engine);
        self.is_complete = true;
    }

    fn solve_position(&mut self, engine: &TicTacToe) -> GameResult {
        let hash = engine.hash();
        self.positions_explored += 1;

        // Check transposition table (duplicate elimination!)
        if let Some(&cached) = self.table.get(&hash) {
            self.positions_cached += 1;
            return cached;
        }

        // Check if terminal
        let result = engine.get_result();
        if result != GameResult::Ongoing {
            self.table.insert(hash, result);
            self.games_completed += 1;
            return result;
        }

        // Try all moves
        let moves = engine.legal_moves();
        let is_x = engine.x_to_move;

        let mut best = if is_x {
            GameResult::OWins // Worst for X
        } else {
            GameResult::XWins // Worst for O
        };

        for &m in &moves {
            let mut child = engine.clone();
            child.make_move(m);
            let child_result = self.solve_position(&child);

            // X maximizes, O minimizes
            if is_x {
                best = better_for_x(best, child_result);
            } else {
                best = better_for_o(best, child_result);
            }
        }

        self.table.insert(hash, best);
        best
    }

    fn get_move_destiny(&self, engine: &TicTacToe, pos: usize) -> Option<GameResult> {
        let mut test = engine.clone();
        test.make_move(pos);
        let hash = test.hash();
        self.table.get(&hash).copied()
    }
}

fn better_for_x(a: GameResult, b: GameResult) -> GameResult {
    let score = |r: GameResult| -> i8 {
        match r {
            GameResult::XWins => 1,
            GameResult::Draw => 0,
            GameResult::OWins => -1,
            GameResult::Ongoing => 0,
        }
    };
    if score(b) > score(a) { b } else { a }
}

fn better_for_o(a: GameResult, b: GameResult) -> GameResult {
    let score = |r: GameResult| -> i8 {
        match r {
            GameResult::XWins => -1,
            GameResult::Draw => 0,
            GameResult::OWins => 1,
            GameResult::Ongoing => 0,
        }
    };
    if score(b) > score(a) { b } else { a }
}

// =====================================================
// GUI
// =====================================================

const CELL: f32 = 150.0;
const GAP: f32 = 8.0;
const BOARD_OFF_X: f32 = 60.0;
const BOARD_OFF_Y: f32 = 60.0;
const BOARD_TOTAL: f32 = CELL * 3.0 + GAP * 2.0;
const PANEL_X: f32 = BOARD_OFF_X + BOARD_TOTAL + 50.0;

const BG: Color = Color::new(0.10, 0.10, 0.14, 1.0);
const CELL_BG: Color = Color::new(0.16, 0.18, 0.22, 1.0);
const CELL_HOVER: Color = Color::new(0.22, 0.24, 0.30, 1.0);
const X_COLOR: Color = Color::new(0.35, 0.65, 1.0, 1.0);
const O_COLOR: Color = Color::new(1.0, 0.45, 0.40, 1.0);
const WIN_COL: Color = Color::new(0.2, 0.85, 0.3, 0.45);
const DRAW_COL: Color = Color::new(0.9, 0.85, 0.2, 0.45);
const LOSS_COL: Color = Color::new(0.9, 0.25, 0.2, 0.45);

struct App {
    engine: TicTacToe,
    explorer: Explorer,
    game_result: GameResult,
    move_log: Vec<String>,
    hover_cell: Option<usize>,
    game_count: u32,
}

impl App {
    fn new() -> Self {
        let mut explorer = Explorer::new();
        // Solve the ENTIRE game tree immediately
        explorer.solve_completely();

        App {
            engine: TicTacToe::new(),
            explorer,
            game_result: GameResult::Ongoing,
            move_log: Vec::new(),
            hover_cell: None,
            game_count: 1,
        }
    }

    fn update(&mut self) {
        // Track hover
        let (mx, my) = mouse_position();
        self.hover_cell = self.get_cell(mx, my);

        // Click to make a move
        if is_mouse_button_pressed(MouseButton::Left) && self.game_result == GameResult::Ongoing {
            if let Some(cell) = self.get_cell(mx, my) {
                if self.engine.board[cell] == EMPTY && self.engine.check_winner().is_none() {
                    let side = if self.engine.x_to_move { "X" } else { "O" };
                    let row = cell / 3;
                    let col = cell % 3;
                    self.move_log.push(format!("{}: ({},{})", side, row + 1, col + 1));
                    self.engine.make_move(cell);
                    self.game_result = self.engine.get_result();
                }
            }
        }

        // Keyboard
        if is_key_pressed(KeyCode::R) {
            self.engine = TicTacToe::new();
            self.game_result = GameResult::Ongoing;
            self.move_log.clear();
            self.game_count += 1;
        }
        if is_key_pressed(KeyCode::U) {
            self.engine.unmake_move();
            self.move_log.pop();
            self.game_result = self.engine.get_result();
        }
    }

    fn get_cell(&self, mx: f32, my: f32) -> Option<usize> {
        for row in 0..3 {
            for col in 0..3 {
                let x = BOARD_OFF_X + col as f32 * (CELL + GAP);
                let y = BOARD_OFF_Y + row as f32 * (CELL + GAP);
                if mx >= x && mx < x + CELL && my >= y && my < y + CELL {
                    return Some(row * 3 + col);
                }
            }
        }
        None
    }

    fn draw(&self) {
        clear_background(BG);
        self.draw_board();
        self.draw_panel();
    }

    fn draw_board(&self) {
        let is_game_over = self.game_result != GameResult::Ongoing;
        let is_x = self.engine.x_to_move;

        for row in 0..3usize {
            for col in 0..3usize {
                let idx = row * 3 + col;
                let x = BOARD_OFF_X + col as f32 * (CELL + GAP);
                let y = BOARD_OFF_Y + row as f32 * (CELL + GAP);

                // Cell background
                let mut bg = CELL_BG;
                if self.hover_cell == Some(idx) && self.engine.board[idx] == EMPTY && !is_game_over {
                    bg = CELL_HOVER;
                }
                draw_rectangle(x, y, CELL, CELL, bg);

                // Destiny overlay for empty cells
                if self.engine.board[idx] == EMPTY && !is_game_over {
                    if let Some(destiny) = self.explorer.get_move_destiny(&self.engine, idx) {
                        let col_overlay = if is_x {
                            match destiny {
                                GameResult::XWins => WIN_COL,
                                GameResult::Draw => DRAW_COL,
                                GameResult::OWins => LOSS_COL,
                                _ => DRAW_COL,
                            }
                        } else {
                            match destiny {
                                GameResult::OWins => WIN_COL,
                                GameResult::Draw => DRAW_COL,
                                GameResult::XWins => LOSS_COL,
                                _ => DRAW_COL,
                            }
                        };
                        draw_rectangle(x, y, CELL, CELL, col_overlay);

                        // Small label
                        let label = match destiny {
                            GameResult::XWins => "X wins",
                            GameResult::OWins => "O wins",
                            GameResult::Draw => "Draw",
                            _ => "?",
                        };
                        let dim = measure_text(label, None, 16, 1.0);
                        draw_text(label, x + CELL / 2.0 - dim.width / 2.0, y + CELL - 10.0, 16.0, WHITE);
                    }
                }

                // Draw piece
                let piece = self.engine.board[idx];
                if piece == X_PIECE {
                    self.draw_x(x, y);
                } else if piece == O_PIECE {
                    self.draw_o(x, y);
                }

                // Winning line highlight
                if is_game_over && self.game_result != GameResult::Draw {
                    if self.is_winning_cell(idx) {
                        draw_rectangle(x, y, CELL, CELL, Color::new(1.0, 1.0, 1.0, 0.15));
                    }
                }
            }
        }

        // Game over banner
        if is_game_over {
            let banner_y = BOARD_OFF_Y + BOARD_TOTAL + 15.0;
            let text = match self.game_result {
                GameResult::XWins => "X WINS!",
                GameResult::OWins => "O WINS!",
                GameResult::Draw => "DRAW!",
                _ => "",
            };
            let color = match self.game_result {
                GameResult::XWins => X_COLOR,
                GameResult::OWins => O_COLOR,
                _ => Color::new(0.9, 0.85, 0.2, 1.0),
            };
            let dim = measure_text(text, None, 36, 1.0);
            draw_text(text, BOARD_OFF_X + BOARD_TOTAL / 2.0 - dim.width / 2.0, banner_y, 36.0, color);
        }
    }

    fn draw_x(&self, x: f32, y: f32) {
        let pad = 30.0;
        let thick = 6.0;
        // Draw two crossing lines
        for offset in [-1.0f32, 0.0, 1.0] {
            draw_line(
                x + pad + offset, y + pad,
                x + CELL - pad + offset, y + CELL - pad,
                thick, X_COLOR,
            );
            draw_line(
                x + CELL - pad + offset, y + pad,
                x + pad + offset, y + CELL - pad,
                thick, X_COLOR,
            );
        }
    }

    fn draw_o(&self, x: f32, y: f32) {
        let cx = x + CELL / 2.0;
        let cy = y + CELL / 2.0;
        let radius = CELL / 2.0 - 30.0;
        draw_circle_lines(cx, cy, radius, 6.0, O_COLOR);
    }

    fn is_winning_cell(&self, idx: usize) -> bool {
        const LINES: [[usize; 3]; 8] = [
            [0, 1, 2], [3, 4, 5], [6, 7, 8],
            [0, 3, 6], [1, 4, 7], [2, 5, 8],
            [0, 4, 8], [2, 4, 6],
        ];
        for line in &LINES {
            let a = self.engine.board[line[0]];
            if a != EMPTY && a == self.engine.board[line[1]] && a == self.engine.board[line[2]] {
                if line.contains(&idx) {
                    return true;
                }
            }
        }
        false
    }

    fn draw_panel(&self) {
        let x = PANEL_X;
        let mut y = BOARD_OFF_Y;

        draw_text("TIC-TAC-TOE", x, y + 22.0, 26.0, Color::new(0.9, 0.85, 0.7, 1.0));
        y += 30.0;
        draw_text("DESTINY EXPLORER", x, y, 26.0, Color::new(0.9, 0.85, 0.7, 1.0));

        y += 40.0;
        let turn = match self.game_result {
            GameResult::XWins => "X Wins!",
            GameResult::OWins => "O Wins!",
            GameResult::Draw => "Draw!",
            GameResult::Ongoing => if self.engine.x_to_move { "X to move" } else { "O to move" },
        };
        let turn_col = match self.game_result {
            GameResult::XWins => X_COLOR,
            GameResult::OWins => O_COLOR,
            _ => WHITE,
        };
        draw_text(turn, x, y, 20.0, turn_col);

        y += 30.0;
        draw_text(&format!("Game #{}", self.game_count), x, y, 15.0, GRAY);

        // Explorer stats
        y += 35.0;
        draw_text("--- Explorer Stats ---", x, y, 16.0, Color::new(0.5, 0.85, 0.5, 1.0));

        y += 25.0;
        let status_col = Color::new(1.0, 0.85, 0.0, 1.0);
        draw_text("Status: SOLVED!", x, y, 15.0, status_col);

        y += 20.0;
        draw_text(
            &format!("Positions explored: {}", self.explorer.positions_explored),
            x, y, 14.0, GRAY,
        );
        y += 20.0;
        draw_text(
            &format!("Duplicates skipped: {}", self.explorer.positions_cached),
            x, y, 14.0, GRAY,
        );
        y += 20.0;
        draw_text(
            &format!("Unique positions: {}", self.explorer.table.len()),
            x, y, 14.0, GRAY,
        );
        y += 20.0;
        draw_text(
            &format!("Games completed: {}", self.explorer.games_completed),
            x, y, 14.0, GRAY,
        );
        y += 20.0;
        let hit_rate = if self.explorer.positions_explored > 0 {
            (self.explorer.positions_cached as f64 / self.explorer.positions_explored as f64) * 100.0
        } else {
            0.0
        };
        draw_text(&format!("Cache hit rate: {:.1}%", hit_rate), x, y, 14.0, GRAY);

        // Opening result
        y += 30.0;
        if let Some(&opening_result) = self.explorer.table.get(&TicTacToe::new().hash()) {
            draw_text("Opening verdict:", x, y, 16.0, Color::new(0.5, 0.85, 0.5, 1.0));
            y += 22.0;
            let verdict_col = match opening_result {
                GameResult::Draw => Color::new(0.9, 0.85, 0.2, 1.0),
                GameResult::XWins => X_COLOR,
                GameResult::OWins => O_COLOR,
                _ => WHITE,
            };
            draw_text(opening_result.name(), x, y, 22.0, verdict_col);
            y += 20.0;
            draw_text("(with perfect play from both sides)", x, y, 12.0, GRAY);
        }

        // Legend
        y += 40.0;
        draw_text("--- Destiny Colors ---", x, y, 16.0, Color::new(0.5, 0.85, 0.5, 1.0));
        y += 25.0;
        draw_rectangle(x, y - 10.0, 18.0, 18.0, WIN_COL);
        draw_text("Win (for current player)", x + 25.0, y + 3.0, 14.0, GRAY);
        y += 25.0;
        draw_rectangle(x, y - 10.0, 18.0, 18.0, DRAW_COL);
        draw_text("Draw", x + 25.0, y + 3.0, 14.0, GRAY);
        y += 25.0;
        draw_rectangle(x, y - 10.0, 18.0, 18.0, LOSS_COL);
        draw_text("Loss (for current player)", x + 25.0, y + 3.0, 14.0, GRAY);

        // Controls
        y += 40.0;
        draw_text("--- Controls ---", x, y, 16.0, Color::new(0.5, 0.85, 0.5, 1.0));
        y += 25.0;
        draw_text("Click a cell to play", x, y, 14.0, GRAY);
        y += 20.0;
        draw_text("[R] New game", x, y, 14.0, GRAY);
        y += 20.0;
        draw_text("[U] Undo", x, y, 14.0, GRAY);

        // Move log
        y += 35.0;
        draw_text("Moves:", x, y, 14.0, GRAY);
        y += 18.0;
        for entry in self.move_log.iter().rev().take(9) {
            draw_text(entry, x, y, 13.0, Color::new(0.45, 0.45, 0.5, 1.0));
            y += 16.0;
        }
    }
}

fn window_conf() -> Conf {
    Conf {
        window_title: "Tic-Tac-Toe Destiny Explorer".to_owned(),
        window_width: 900,
        window_height: 600,
        window_resizable: false,
        ..Default::default()
    }
}

#[macroquad::main(window_conf)]
async fn main() {
    let mut app = App::new();
    loop {
        app.update();
        app.draw();
        next_frame().await;
    }
}
